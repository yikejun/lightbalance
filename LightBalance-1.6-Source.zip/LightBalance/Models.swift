import Foundation

enum DayMode: String, Codable, CaseIterable, Identifiable {
    case high, medium, low, flexible
    var id: String { rawValue }
    var title: String { switch self { case .high: "高碳日"; case .medium: "中碳日"; case .low: "低碳日"; case .flexible: "机动日" } }
    var subtitle: String { switch self { case .high: "力量训练"; case .medium: "有氧 / 高活动量"; case .low: "休息 / 久坐"; case .flexible: "聚餐 / 出差" } }
    var symbol: String { switch self { case .high: "dumbbell.fill"; case .medium: "figure.walk"; case .low: "leaf.fill"; case .flexible: "fork.knife" } }
    // Each point target lies within the ranges in the supplied plan.
    var target: Nutrition { switch self {
    case .high: Nutrition(calories: 1700, protein: 108, fat: 48, carbs: 218)
    case .medium: Nutrition(calories: 1600, protein: 108, fat: 50, carbs: 183)
    case .low: Nutrition(calories: 1500, protein: 108, fat: 58, carbs: 130)
    case .flexible: Nutrition(calories: 1900, protein: 105, fat: 0, carbs: 0)
    } }
    var range: String { switch self { case .high: "1700 kcal · 碳水 210–225 g"; case .medium: "1600 kcal · 碳水 175–190 g"; case .low: "1450–1500 kcal · 碳水 120–140 g"; case .flexible: "参考 1800–2000 kcal · 蛋白质 ≥100 g" } }
}
struct Nutrition: Codable, Equatable {
    var calories: Double = 0
    var protein: Double = 0
    var fat: Double = 0
    var carbs: Double = 0
    static func + (lhs: Self, rhs: Self) -> Self {
        Self(calories: lhs.calories + rhs.calories, protein: lhs.protein + rhs.protein, fat: lhs.fat + rhs.fat, carbs: lhs.carbs + rhs.carbs)
    }
}
struct Meal: Codable, Identifiable {
    var id = UUID()
    var kind: String
    var name: String
    var nutrition: Nutrition
    var lower: Double?
    var upper: Double?
    var note: String = ""
    var photo: Data?
    var extraPhotos: [Data]? = nil
    var extraPhotoRoles: [String]? = nil
}
struct ExerciseSet: Codable, Identifiable {
    var id = UUID()
    var exercise: String
    var weight: Double
    var reps: Int
    var seconds: Int? = nil
    var rir: Int? = nil
    var warmup: Bool? = nil
    var loadMode: String? = nil
    var working: Bool { warmup != true }
}
struct Workout: Codable, Identifiable {
    var id = UUID()
    var kind: String
    var minutes: Int
    var sets: [ExerciseSet] = []
    var note: String = ""
    var trainingType: String? = nil
    var healthWorkoutID: UUID? = nil
    var healthSource: String? = nil
    var startedAt: Date? = nil
    var endedAt: Date? = nil
    var healthDuplicateOf: UUID? = nil
    var healthIndependent: Bool? = nil
    var healthNameEdited: Bool? = nil
    var healthCategoryEdited: Bool? = nil
    var countsForSummary: Bool { healthDuplicateOf == nil }
    var category: String { trainingType ?? WorkoutSemantic.category(kind) ?? (healthWorkoutID == nil ? "力量" : "其他") }
    var isStrength: Bool { category == "力量" }
    var isCardio: Bool { category == "有氧" }

}
struct DayRecord: Codable, Identifiable {
    var date: Date
    var mode: DayMode
    var meals: [Meal] = []
    var workouts: [Workout] = []
    var weight: Double?
    var waist: Double?
    var bodyFat: Double? = nil
    var healthImportedFields: [String]? = nil
    var steps: Int?
    var performance: String = "未评估"
    var recovery: RecoveryRecord? = nil
    var id: Date { date }
    var total: Nutrition { meals.reduce(Nutrition()) { $0 + $1.nutrition } }
    var hasData: Bool { !meals.isEmpty || !workouts.isEmpty || weight != nil || waist != nil || steps != nil || recovery != nil }
}
struct AppData: Codable {
    var startDate: Date = Calendar.current.startOfDay(for: Date())
    var initialWeight: Double = 0
    var initialBodyFat: Double = 0
    var initialWaist: Double?
    var mealsPerDay: Int? = nil
    var healthAutoFill: Bool? = nil
    var weeklyBudget: Double = 0
    var records: [DayRecord] = []
    var trainingPlans: [TrainingPlan]? = nil
    var coachProfile: CoachProfile? = nil
    var coachDecisions: [CoachDecision]? = nil
    var professionalReviews: [ProfessionalReviewRecord]? = nil
    var weeklyCoachEnabled: Bool? = nil
    var weeklyAcceptedReport: String? = nil
    var weeklyAPIReports: [WeeklyReport]? = nil
    var healthCache: HealthCache? = nil
    var healthSleepSource: String? = nil
    var healthAccessRequested: Bool? = nil
    var personalProfile: PersonalProfile? = nil
    var onboardingCompleted: Bool? = nil
    var nutritionTargets: [String: Nutrition]? = nil
    var personalProposal: PersonalProposal? = nil
    var personalSchedule: [String]? = nil
    var personalAcceptedHash: String? = nil
    var healthWorkoutSync: Bool? = nil
    var activeDiet: DietRecommendation? = nil
    var activeWeekModes: [String]? = nil

}
enum Plan {
    static let strengthA = ["腿举 / 深蹲", "卧推 / 推胸", "高位下拉", "划船", "侧平举", "核心"]
    static let strengthB = ["罗马尼亚硬拉", "弓步 / 腿屈伸", "上斜推胸", "划船", "肩推", "二头 / 三头"]
    static func defaultMode(for date: Date) -> DayMode {
        switch Calendar.current.component(.weekday, from: date) {
        case 2, 4, 6: .high
        case 3, 7: .medium
        default: .low
        }
    }
    static func cycleDay(_ date: Date, start: Date) -> Int {
        (Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: start), to: Calendar.current.startOfDay(for: date)).day ?? 0) + 1
    }
    // Weeks are anchored to Day 1, rather than Monday, for consistent 7-day reports.
    static func weekDates(containing date: Date, start: Date) -> [Date] {
        let day = max(0, cycleDay(date, start: start) - 1)
        let first = Calendar.current.date(byAdding: .day, value: (day / 7) * 7, to: Calendar.current.startOfDay(for: start))!
        return (0..<7).compactMap { Calendar.current.date(byAdding: .day, value: $0, to: first) }
    }
    static func mean(_ values: [Double]) -> Double? {
        values.isEmpty ? nil : values.reduce(0, +) / Double(values.count)
    }
    static func remaining(_ target: Double, eaten: Double) -> Double { max(0, target - eaten) }
}

struct PersonalProfile: Codable, Equatable {
    var fields: [String: String] = [:]
    var missingBasics: [String] {
        var result:[String]=[]
        if Int(fields["age"] ?? "").map({(18...100).contains($0)}) != true { result.append("年龄（18–100岁）") }
        if Double(fields["height"] ?? "").map({$0.isFinite && (100...230).contains($0)}) != true { result.append("身高（100–230cm）") }
        if Double(fields["weight"] ?? "").map({$0.isFinite && (30...300).contains($0)}) != true { result.append("当前体重（30–300kg）") }
        if (fields["goal"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { result.append("健身期望") }
        return result
    }
    var missingForPlan: [String] {
        var result=missingBasics
        for (key,label) in [("activity","目前活动水平"),("experience","训练经验"),("equipment","可用器械 / 场地（可填自重）"),("restriction","伤病 / 医疗限制"),("pregnancy","孕期或哺乳期")] {
            if ["","待确认","未提供"].contains((fields[key] ?? "").trimmingCharacters(in:.whitespacesAndNewlines)){result.append(label)}
        }
        if Int(fields["days"] ?? "").map({(1...7).contains($0)}) != true {result.append("每周可训练天数（1–7天）")}
        if Int(fields["minutes"] ?? "").map({(1...360).contains($0)}) != true {result.append("每次可用时长（1–360分钟）")}
        return result
    }
    var complete: Bool {
        guard let age = Int(fields["age"] ?? ""), (18...100).contains(age),
              let height = Double(fields["height"] ?? ""), (100...230).contains(height),
              let weight = Double(fields["weight"] ?? ""), (30...300).contains(weight) else { return false }
        for (key, bounds) in [("bodyFat",1.0...75.0),("waist",1.0...300.0),("hip",1.0...300.0),("targetWeight",30.0...300.0),("days",1.0...7.0),("minutes",1.0...360.0)] {
            if let text=fields[key],!text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { guard let value=Double(text),value.isFinite,bounds.contains(value) else{return false} }
        }
        return !(fields["goal"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}
struct PersonalProposal: Codable {
    var status: String
    var explanation: String
    var questions: [String]
    var sourceIDs: [String]
    var plans: [TrainingPlan]
    var targets: [String: Nutrition]
    var weeklyBudget: Double
    var schedule: [String]
    var assumptions: String
    var diet: DietRecommendation? = nil
    var weekModes: [String]? = nil
    var baseHash: String? = nil
    var createdAt: Date? = nil
    func validated(profile: PersonalProfile) throws -> Self {
        let known = Set(GuideLibrary.ids)
        guard ["ready","needs_info","professional_review"].contains(status), !explanation.isEmpty,
              !sourceIDs.isEmpty, Set(sourceIDs).isSubset(of: known), schedule.count <= 7 else { throw NSError(domain: "Plan", code: 1, userInfo: [NSLocalizedDescriptionKey:"计划依据或格式无效，请重新生成。"] ) }
        if status == "ready" {
            if let h=Double(profile.fields["height"] ?? ""), let w=Double(profile.fields["weight"] ?? ""), (profile.fields["goal"] ?? "").contains("减脂"), w/pow(h/100,2) < 18.5 { throw NSError(domain:"Plan",code:4,userInfo:[NSLocalizedDescriptionKey:"当前身体情况不适用自动减脂计划。"]) }
            if let h=Double(profile.fields["height"] ?? ""),let goal=Double(profile.fields["targetWeight"] ?? ""), goal/pow(h/100,2)<18.5 { throw NSError(domain:"Plan",code:4,userInfo:[NSLocalizedDescriptionKey:"期望体重需要专业评估。"]) }
            guard profile.complete, profile.fields["restriction"] == "无", profile.fields["pregnancy"] == "否",
                  !plans.isEmpty, plans.count <= 7, Set(plans.map(\.id)).count == plans.count,
                  plans.allSatisfy({ !$0.name.isEmpty && !$0.exercises.isEmpty && $0.exercises.count <= 20 && Set($0.exercises.map(\.id)).count == $0.exercises.count && $0.exercises.allSatisfy { !$0.name.isEmpty && (1...12).contains($0.sets) && (1...300).contains($0.reps) } }),
                  Set(targets.keys) == Set(DayMode.allCases.map(\.rawValue)), schedule.count == 7,
                  weeklyBudget.isFinite, (7000...35000).contains(weeklyBudget),
                  targets.values.allSatisfy({ n in (1000...5000).contains(n.calories) && [n.protein,n.carbs,n.fat].allSatisfy { $0.isFinite && (0...800).contains($0) } }) else { throw NSError(domain:"Plan",code:2,userInfo:[NSLocalizedDescriptionKey:"计划尚不满足适用范围或数据校验，不能应用。"] ) }
            if let diet { guard diet.valid,let modes=weekModes,modes.count==7,modes.allSatisfy({targets[$0] != nil}),abs(modes.reduce(0){$0+(targets[$1]?.calories ?? 0)}-weeklyBudget)<=1 else {throw NSError(domain:"Plan",code:5,userInfo:[NSLocalizedDescriptionKey:"饮食方案或周预算与七日安排不一致。"]) } }
        } else if !plans.isEmpty || !targets.isEmpty || !schedule.isEmpty || weeklyBudget != 0 { throw NSError(domain:"Plan",code:3,userInfo:[NSLocalizedDescriptionKey:"资料不足时不应生成可执行计划。"] ) }
        return self
    }
}
// Draft files never contain account credentials. Each write is atomic and protected on iOS.
enum DraftStorage {
    static var customRoot: URL? = nil
    static var root: URL { customRoot ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("LightBalance/Drafts", isDirectory: true) }
    static func url(_ key: String) -> URL { root.appendingPathComponent(Data(key.utf8).base64EncodedString().replacingOccurrences(of:"/",with:"_") + ".json") }
    static func load<T: Decodable>(_ type: T.Type, key: String) -> T? { guard let bytes = try? Data(contentsOf: url(key)) else { return nil }; return try? JSONDecoder().decode(type, from: bytes) }
    static func save<T: Encodable>(_ value: T, key: String) throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var directory = root; var flags = URLResourceValues(); flags.isExcludedFromBackup = true; try directory.setResourceValues(flags)
        #if os(iOS)
        try JSONEncoder().encode(value).write(to: url(key), options: [.atomic, .completeFileProtection])
        #else
        try JSONEncoder().encode(value).write(to: url(key), options: .atomic)
        #endif
    }
    static func remove(_ key: String) { try? FileManager.default.removeItem(at: url(key)) }
    static func encoded<T: Encodable>(_ value: T) -> Data { let encoder = JSONEncoder(); encoder.outputFormatting = .sortedKeys; return (try? encoder.encode(value)) ?? Data() }
    static func dayKey(_ date: Date) -> String { String(Calendar.current.startOfDay(for:date).timeIntervalSince1970) }
}
enum IntakeRange {
    static func valid(lower: String, upper: String, calories: Double) -> Bool {
        let l = lower.trimmingCharacters(in:.whitespacesAndNewlines), u = upper.trimmingCharacters(in:.whitespacesAndNewlines)
        if !l.isEmpty { guard let v = Double(l), v.isFinite, v >= 0, v <= calories else { return false } }
        if !u.isEmpty { guard let v = Double(u), v.isFinite, v >= calories else { return false } }
        return true
    }
}

struct DietRecommendation: Codable {
    var style: String
    var name: String
    var rationale: String
    var meals: [String]
    var tips: [String]
    var sourceIDs: [String]
    var carbCycling: Bool
    var valid: Bool { ["balanced","mediterranean","dash","vegetarian","performance","carb_cycling"].contains(style) && !name.isEmpty && !rationale.isEmpty && !meals.isEmpty && meals.count<=12 && tips.count<=15 && !sourceIDs.isEmpty && Set(sourceIDs).isSubset(of:Set(GuideLibrary.ids)) && carbCycling == (style == "carb_cycling") }
}
extension DayMode {
    var activityTitle: String { switch self { case .high:"力量日";case .medium:"活动日";case .low:"休息日";case .flexible:"弹性日" } }
}
extension AppData {
    func modeTitle(_ mode:DayMode)->String { activeDiet?.carbCycling == true || personalProfile == nil && activeDiet == nil ? mode.title : mode.activityTitle }
}

enum GuideLibrary {
 static let ids: [String] = ["WHO2020", "ACSM2026", "NIDDK", "NIDDK-diet", "DASH", "AHA-patterns", "ISSN-protein", "spot-reduction"]
 static func url(_ id:String) -> URL? { let links: [String:String] = [
"WHO2020": "https://www.who.int/publications/i/item/9789240015128",
"ACSM2026": "https://acsm.org/resistance-training-guidelines-update-2026/",
"NIDDK": "https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner",
"NIDDK-diet": "https://www.niddk.nih.gov/health-information/weight-management/choosing-a-safe-successful-weight-loss-program",
"DASH": "https://www.nhlbi.nih.gov/health/dash-eating-plan",
"AHA-patterns": "https://professional.heart.org/en/science-news/popular-dietary-patterns-alignment-with-american-heart-association-2021-dietary-guidance/top-things-to-know",
"ISSN-protein": "https://link.springer.com/article/10.1186/s12970-017-0177-8",
"spot-reduction": "https://hummov.awf.wroc.pl/A-proposed-model-to-test-the-hypothesis-of-exercise-induced-localized-fat-reduction,143162,0,2.html"
 ]; return links[id].flatMap(URL.init(string:)) }
}

enum WorkoutSemantic {
    static let cardioNames=["HIIT 高强度间歇训练","跑步","步行","骑行","游泳","椭圆机","划船机","爬楼","跳绳","舞蹈有氧","混合有氧"]
    static func category(_ name:String)->String? {
        let s=name.lowercased()
        if ["hiit","间歇","跑步","running","步行","walking","骑行","cycling","游泳","swim","椭圆","划船","rowing","爬楼","跳绳","有氧","cardio","kickbox","搏击","dance","舞蹈","hiking","徒步"].contains(where:s.contains){return "有氧"}
        if ["力量","strength","核心训练"].contains(where:s.contains){return "力量"}
        if ["yoga","瑜伽","pilates","普拉提","拉伸","柔韧","太极"].contains(where:s.contains){return "柔韧"}
        return nil
    }
    static func displayName(_ name:String)->String {
        let s=name.lowercased()
        if s.contains("hiit") || s.contains("间歇训练") || s.contains("high intensity interval"){return "HIIT 高强度间歇训练"}
        return name
    }
    static func generic(_ name:String)->Bool { ["有氧","其他","其他训练","训练"].contains(name) || name.hasPrefix("其他训练（") }
}
struct TrainingTotals {
    var strength=0,cardio=0,mobility=0,other=0,cardioMinutes=0,pending=0
    init(_ days:[DayRecord]) {
        for w in days.flatMap(\.workouts) {
            if !w.countsForSummary{pending+=1;continue}
            switch w.category{case "力量":strength+=1;case "有氧":cardio+=1;cardioMinutes+=w.minutes;case "柔韧":mobility+=1;default:other+=1}
        }
    }
}
