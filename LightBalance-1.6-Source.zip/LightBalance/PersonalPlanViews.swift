import SwiftUI
import CryptoKit

enum PersonalPlanService {
    static func body(_ data: AppData, note: String) throws -> [String: Any] {
        guard let profile = data.personalProfile else { throw VisionError.message("请先保存身体数据和目标。") }
        return ["profile":try WeeklySnapshot.object(profile), "history":try JSONSerialization.jsonObject(with:WeeklySnapshot.body(data)), "request":String(note.prefix(2000)), "exerciseCatalog":ExerciseLibrary.all.map { ["name":$0.name,"equipment":$0.equipment,"timed":$0.timed ? "秒" : "次"] }]
    }
    static func hash(_ data: AppData) -> String {
        PersonalPlanFingerprint.hash(data)
    }
    static func generate(data: AppData, note: String) async throws -> PersonalProposal {
        let input = try body(data,note:note)
        #if LIGHTBALANCE_USER_API
        let content = String(data:try JSONSerialization.data(withJSONObject:["userData":input,"authoritativeSources":try FoodService.object(PersonalPlanResources.sources)]),encoding:.utf8)!
        var payload = try FoodService.payload(prompt:PersonalPlanResources.prompt,schema:PersonalPlanResources.schema,name:"personal_plan",input:[["role":"user","content":content]])
        payload["max_output_tokens"] = 12000
        let raw = try await UserAPIClient.complete(payload:payload)
        #else
        let raw = try await FoodService.gateway(path:"plans/generate",body:input)
        #endif
        var proposal = try JSONDecoder().decode(PersonalProposal.self,from:raw).validated(profile:data.personalProfile!)
        proposal.baseHash = hash(data); proposal.createdAt = Date(); return proposal
    }
}
struct ActionButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.fontWeight(.semibold).foregroundStyle(enabled ? configuration.role == .destructive ? Color.red : Color.forest : Color.secondary)
            .opacity(configuration.isPressed ? 0.65 : 1)

    }
}
struct PersonalPlanView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var onboarding = false
    @State private var fields: [String:String] = [:]
    @State private var page = 0
    @State private var loaded = false
    @State private var note = ""
    @State private var busy = false
    @State private var error: String?
    @State private var sendConsent = false
    @State private var applyConsent = false
    @State private var saved = false
    var profile: PersonalProfile { .init(fields:fields) }
    var cache: [String:String] { var value=fields;value["_page"]=String(page);value["_note"]=note;return value }
    var current: Bool { store.data.personalProfile == profile }
    var body: some View {
        Form {
            Section(onboarding ? "欢迎使用轻衡 · 第 \(page+1) / 3 步" : "身体资料与健身期望") {
                Text("资料只保存在本机。没有配置模型也能先完成设置，之后再建立计划。已有用户的历史记录保留。")
                    .font(.caption).foregroundStyle(.secondary)
                if onboarding { ProgressView(value:Double(page+1),total:3) }
            }
            if !onboarding || page == 0 {
                Section("身体数据 · 年龄、身高、体重必填") {
                    field("年龄",key:"age",numeric:true);field("身高 cm",key:"height",numeric:true);field("当前体重 kg",key:"weight",numeric:true)
                    choice("能量估计使用的性别",key:"sex",values:["未提供","男性","女性"])
                    field("体脂 % · 可选",key:"bodyFat",numeric:true);field("腰围 cm · 可选",key:"waist",numeric:true)
                    field("臀围 cm · 可选",key:"hip",numeric:true)
                    choice("自述体型 · 可选",key:"bodyShape",values:["未选择 / 不确定","梨形（下身较宽）","苹果形（腹部较集中）","沙漏形","矩形 / 直筒","倒三角","其他"])
                    field("身材与比例侧重 · 可选",key:"shapeGoal")
                    Text("体型是外观描述，不是诊断。可表达上身比例、臀腿力量等偏好；结合测量和实际能力调整训练，不承诺局部减脂。").font(.caption).foregroundStyle(.secondary)
                }
            }
            if !onboarding || page == 1 {
                Section("你的目标") {
                    field("健身期望 · 必填",key:"goal")
                    field("期望体重 kg · 可选",key:"targetWeight",numeric:true)
                    field("期望时间 / 其他想法",key:"timeline")
                    choice("目前活动水平",key:"activity",values:["待确认","久坐","轻度活动","中度活动","高活动量"])
                    choice("训练经验",key:"experience",values:["待确认","新手","有规律训练经验","近期恢复训练"])
                    field("每周可训练几天",key:"days",numeric:true);field("每次可用分钟",key:"minutes",numeric:true)
                    field("可用器械 / 场地 · 必填",key:"equipment")
                    DisclosureGroup("实际可用器械 · 用于动作优先推荐") {
                        ForEach(ExerciseLibrary.equipment,id:\.self){item in Toggle(item,isOn:Binding(get:{TrainingPreferences.equipment(profile).contains(item)},set:{on in var selected=Set(TrainingPreferences.equipment(profile));if on{selected.insert(item)}else{selected.remove(item)};fields["equipmentChoices"]=selected.sorted().joined(separator:"|");fields["equipment"]=selected.sorted().joined(separator:"、");saved=false}))}
                    }
                    Text("这些条件供计划生成、训练评估与动作库共同使用，不需要重复填写。").font(.caption).foregroundStyle(.secondary)
                    field("饮食偏好、过敏 · 可选",key:"diet")
                    choice("饮食方案偏好 · 可选",key:"dietStyle",values:["让 AI 根据情况推荐","均衡家常饮食","地中海式","DASH","蛋奶素食","偏运动表现","碳循环（可选）"])
                    field("做饭条件、预算和常见食物 · 可选",key:"foodPracticality")
                    Stepper("每日计划 \(Int(fields["meals"] ?? "2") ?? 2) 餐",value:Binding(get:{Int(fields["meals"] ?? "2") ?? 2},set:{fields["meals"]=String($0)}),in:1...8)
                }
            }
            if !onboarding || page == 2 {
                Section("计划适用范围") {
                    choice("伤病 / 医疗限制",key:"restriction",values:["待确认","无","有"])
                    choice("孕期或哺乳期",key:"pregnancy",values:["待确认","否","是"])
                    field("限制或待补充情况",key:"healthNote")
                    Text("本功能面向18岁以上成人。未知情况可先保存；模型会要求补充或建议专业评估。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section {
                    if !profile.missingBasics.isEmpty { Text("资料必填项："+profile.missingBasics.joined(separator:"、")).font(.caption).foregroundStyle(.orange) }
                    if !profile.missingForPlan.isEmpty { Text("生成完整计划前还需填写："+profile.missingForPlan.joined(separator:"、")).font(.caption).foregroundStyle(.orange) }
                    Button(onboarding ? "保存资料，稍后建立计划" : "保存资料") { saveProfile(); if onboarding && saved { dismiss() } }.disabled(!profile.complete || busy)
                    if !profile.complete { Text("请填写18岁以上年龄、身高、当前体重和健身期望。其他资料可稍后补充。").font(.caption).foregroundStyle(.secondary) }
                    if saved { Text("资料已保存。可以随时生成或更新计划。").foregroundStyle(Color.forest) }
                    Group {
                        TextField("这次建立计划的想法 · 可选",text:$note,axis:.vertical)
                        Button { if !profile.missingForPlan.isEmpty { error="请补齐生成计划的必填项："+profile.missingForPlan.joined(separator:"、") } else { saveProfile();if saved {sendConsent=true} } } label:{Label(busy ? "正在建立计划…" : "让 AI 建立 / 更新计划",systemImage:"sparkles")}.disabled(busy)
                        NavigationLink("配置模型与授权") { VisionSettingsView() }
                        Text("此入口调用独立的计划生成接口；资料、近28天身体与训练/健康摘要会在确认后发送。生成不会直接覆盖计划。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            if onboarding {
                Section { HStack { if page>0 { Button("上一步"){page-=1} };Spacer();if page<2 { Button("下一步"){let missing = page == 0 ? profile.missingBasics.filter{!$0.contains("健身期望")} : ((fields["goal"] ?? "").trimmingCharacters(in:.whitespacesAndNewlines).isEmpty ? ["健身期望"] : []);if missing.isEmpty{error=nil;page+=1}else{error="请填写："+missing.joined(separator:"、")} } } } }
            }
            if let proposal=store.data.personalProposal {
                Section("最近生成的方案 · 已保存") {
                    Text("当前周参考预算：\(number(store.data.weeklyBudget)) kcal")
                    if let diet=proposal.diet {
                        Text(diet.name).font(.headline);Text(diet.rationale)
                        ForEach(diet.meals,id:\.self){Text($0)}
                        ForEach(diet.tips,id:\.self){Text($0).font(.caption)}
                    }
                    Text(proposal.status == "ready" ? "可预览，待你确认" : proposal.status == "needs_info" ? "需要补充信息" : "需要专业评估").font(.headline)
                    if let date=proposal.createdAt { Text(date.formatted(date:.abbreviated,time:.shortened)).font(.caption) }
                    Text(proposal.explanation);Text(proposal.assumptions).font(.caption)
                    ForEach(proposal.questions,id:\.self){Text("• "+$0)}
                    ForEach(proposal.schedule.indices,id:\.self){Text(["周一","周二","周三","周四","周五","周六","周日"][$0]+"："+proposal.schedule[$0])}
                    ForEach(proposal.plans){plan in VStack(alignment:.leading){Text(plan.name).font(.headline);ForEach(plan.exercises){item in Text("\(item.name) · \(item.sets)组 × \(item.reps)\(ExerciseLibrary.find(item.name)?.timed == true ? "秒" : "次")")}} }
                    ForEach(DayMode.allCases){mode in if let n=proposal.targets[mode.rawValue]{Text("\(proposal.diet?.carbCycling == false ? mode.activityTitle : mode.title)：\(number(n.calories)) kcal · 蛋白质\(number(n.protein))g / 脂肪\(number(n.fat))g / 碳水\(number(n.carbs))g")} }
                    if proposal.status == "ready" && store.data.personalAcceptedHash == proposal.baseHash { Text("此方案已采用，当前训练与饮食目标已更新。").foregroundStyle(Color.forest) }
                    else if proposal.status == "ready" {
                        Text("周参考预算：\(number(proposal.weeklyBudget)) kcal")
                        Button("确认采用此方案"){applyConsent=true}.disabled(!current || proposal.baseHash != PersonalPlanService.hash(store.data) || busy)
                        if !current || proposal.baseHash != PersonalPlanService.hash(store.data){Text("资料或训练计划已改变，请保存资料并重新生成。").font(.caption).foregroundStyle(.orange)}
                    }
                    ForEach(proposal.sourceIDs,id:\.self){id in Link(id,destination:sourceURL(id))}
                }
            }
            if let error { Section { Text(error).foregroundStyle(.red) } }
        }.navigationTitle(onboarding ? "首次设置" : "AI 个人计划").navigationBarTitleDisplayMode(.inline)
            .buttonStyle(ActionButtonStyle()).keyboardDone()
            .onAppear { guard !loaded else{return};loaded=true;let cached=DraftStorage.load([String:String].self,key:"personal-profile");fields=cached ?? store.data.personalProfile?.fields ?? ["meals":String(store.data.mealsPerDay ?? 2)]
                if (fields["equipment"] ?? "").isEmpty,let old=store.data.coachProfile {fields["equipment"]=old.equipment.joined(separator:"、");fields["equipmentChoices"]=old.equipment.joined(separator:"|");if fields["minutes"] == nil {fields["minutes"]=old.availableMinutes.map(String.init)};if fields["goal"] == nil{fields["goal"]=old.goal}}
                page=Int(fields.removeValue(forKey:"_page") ?? "0") ?? 0;page=min(2,max(0,page));note=fields.removeValue(forKey:"_note") ?? "" }
            .onChange(of:DraftStorage.encoded(cache)){_,_ in persistDraft()}
            .onDisappear { persistDraft() }
            .alert("将资料交给模型建立计划？",isPresented:$sendConsent){Button("取消",role:.cancel){};Button("发送并生成"){generate()}}message:{Text(FoodService.destinationNotice+"发送你填写的身体数据、目标与限制、近28天健康和训练摘要、现有计划。不发送餐食照片。生成结果仅作为待确认方案。")}
            .alert("替换当前训练和饮食目标？",isPresented:$applyConsent){Button("取消",role:.cancel){};Button("确认更新"){if let proposal=store.data.personalProposal { if store.applyPersonalProposal(proposal,currentHash:PersonalPlanService.hash(store.data)){error=nil;saved=true;if onboarding{dismiss()}}else{error="数据已改变或保存失败，请重新生成。"} }}}message:{Text("将采用上方训练动作、每日营养目标与周预算。保留所有历史摄入、身体与训练记录。")}
    }
    func sourceURL(_ id:String)->URL { GuideLibrary.url(id) ?? URL(string:"https://www.who.int/publications/i/item/9789240015128")! }
    func field(_ label:String,key:String,numeric:Bool=false)->some View { VStack(alignment:.leading,spacing:6){Text(label).font(.subheadline);TextField(label.contains("可选") ? "可留空" : "待填写",text:Binding(get:{fields[key] ?? ""},set:{fields[key]=$0;saved=false}),axis:numeric ? .horizontal : .vertical).keyboardType(numeric ? .decimalPad : .default).accessibilityLabel(label).accessibilityIdentifier("personal-"+key)} }
    func choice(_ label:String,key:String,values:[String])->some View { Picker(label,selection:Binding(get:{fields[key] ?? values[0]},set:{fields[key]=$0;saved=false})){ForEach(values,id:\.self){Text($0)}} }
    func persistDraft(){guard loaded else{return};do{try DraftStorage.save(cache,key:"personal-profile")}catch{self.error="资料草稿未保存："+error.localizedDescription}}
    func saveProfile(){guard profile.complete else {error="请核对必填项和已填写的数字："+profile.missingBasics.joined(separator:"、");return};store.savePersonalProfile(profile);saved=store.storageError==nil && store.data.personalProfile==profile;if saved{persistDraft()}}
    func generate(){let snapshot=store.data;let request=note;busy=true;error=nil;Task{@MainActor in defer{busy=false};do{let proposal=try await PersonalPlanService.generate(data:snapshot,note:request);store.savePersonalProposal(proposal);error=store.storageError}catch{self.error=error.localizedDescription}}}
}

struct KeyboardDoneModifier: ViewModifier {
    func body(content: Content) -> some View {
        content.scrollDismissesKeyboard(.interactively).toolbar {
            ToolbarItemGroup(placement:.keyboard) { Spacer();Button("完成输入"){UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),to:nil,from:nil,for:nil)} }
        }
    }
}
extension View { func keyboardDone() -> some View { modifier(KeyboardDoneModifier()) } }
