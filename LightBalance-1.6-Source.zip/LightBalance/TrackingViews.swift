import SwiftUI
import Charts

struct BodyEditor: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var weight = ""
    @State private var bodyFat = ""
    @State private var waist = ""
    @State private var steps = ""
    @State private var performance = "未评估"
    @State private var sleep = ""
    @State private var fatigue = 0
    @State private var pain = 0
    @State private var persistent = 0
    @State private var initialized = false
    @State private var finished = false
    var draftKey: String { "body-"+DraftStorage.dayKey(store.selectedDate) }
    var draftValues: [String:String] { ["weight":weight,"bodyFat":bodyFat,"waist":waist,"steps":steps,"performance":performance,"sleep":sleep,"fatigue":String(fatigue),"pain":String(pain),"persistent":String(persistent)] }
    func cacheDraft(){guard initialized,!finished else{return};do{try DraftStorage.save(draftValues,key:draftKey)}catch{store.storageError="草稿未保存："+error.localizedDescription}}

    var valid: Bool {
        (bodyFat.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || validNumber(bodyFat).map { $0 > 0 && $0 <= 75 } == true) && (sleep.isEmpty || validNumber(sleep).map { $0 <= 24 } == true) && !(persistent == 1 && pain == 2) && (weight.isEmpty || validNumber(weight).map { $0 > 0 && $0 <= 500 } == true) && (waist.isEmpty || validNumber(waist).map { $0 > 0 && $0 <= 300 } == true) && (steps.isEmpty || Int(steps).map { $0 >= 0 && $0 <= 200000 } == true)
    }
    var body: some View {
        NavigationStack { Form {
            Section("身体与活动") {
                field("晨起体重 kg", text: $weight, keyboard: .decimalPad)
                field("体脂 %", text: $bodyFat, keyboard: .decimalPad)
                field("肚脐腰围 cm", text: $waist, keyboard: .decimalPad)
                field("当日步数", text: $steps, keyboard: .numberPad)
                Picker("力量表现", selection: $performance) { ForEach(["未评估", "稳定", "提升", "下降"], id: \.self) { Text($0) } }
            }
            if let fields = store.day.healthImportedFields, !fields.isEmpty { Section { Text("部分数据采用 Apple 健康：" + fields.map { ["weight":"体重","bodyFat":"体脂","waist":"腰围","steps":"步数","sleep":"睡眠"][$0] ?? $0 }.joined(separator:"、")).font(.caption); Text("修改某项后，该项以手动值为准。来源详情可在 Apple 健康页面查看。").font(.caption) } }
            Section("恢复情况 · 可留空") {
                field("昨晚睡眠小时", text: $sleep, keyboard: .decimalPad)
                Picker("疲劳程度", selection: $fatigue) { Text("未记录").tag(0); ForEach(1...5, id: \.self) { Text("\($0) / 5").tag($0) } }
                Picker("今天有疼痛", selection: $pain) { Text("未记录").tag(0); Text("有").tag(1); Text("无").tag(2) }
                Picker("疼痛持续或反复", selection: $persistent) { Text("未记录").tag(0); Text("是").tag(1); Text("否").tag(2) }
                Text("疲劳 1 表示轻、5 表示很重；疼痛与普通训练酸感分开记录。未知保持未记录。").font(.caption)
            }
            Section {
                Text("体重：起床、上厕所后，不吃不喝，在相同条件下记录。\n\n腰围：肚脐水平，正常呼气，不吸肚子。\n\n未知项留空，周报只计算已记录的数据。").font(.subheadline).foregroundStyle(.secondary)
            }
        }.navigationTitle("身体记录").navigationBarTitleDisplayMode(.inline).toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") {
                store.update {
                    var sources = Set($0.healthImportedFields ?? [])
                    if $0.weight != Double(weight) { sources.remove("weight") }
                    if $0.bodyFat != Double(bodyFat) { sources.remove("bodyFat") }
                    if $0.waist != Double(waist) { sources.remove("waist") }
                    if $0.steps != Int(steps) { sources.remove("steps") }
                    if $0.recovery?.sleepHours != Double(sleep) { sources.remove("sleep") }
                    $0.healthImportedFields = sources.isEmpty ? nil : sources.sorted()
                    $0.weight = Double(weight); $0.bodyFat = Double(bodyFat); $0.waist = Double(waist); $0.steps = Int(steps); $0.performance = performance; $0.recovery = sleep.isEmpty && fatigue == 0 && pain == 0 && persistent == 0 ? nil : RecoveryRecord(sleepHours: Double(sleep), fatigue: fatigue == 0 ? nil : fatigue, pain: pain == 0 ? nil : pain == 1, persistentPain: persistent == 0 ? nil : persistent == 1) }
                if store.storageError == nil { finished=true;DraftStorage.remove(draftKey);dismiss() }
            }.disabled(!valid) }
        }.onAppear { guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:draftKey){weight=f["weight"] ?? "";bodyFat=f["bodyFat"] ?? "";waist=f["waist"] ?? "";steps=f["steps"] ?? "";performance=f["performance"] ?? "未评估";sleep=f["sleep"] ?? "";fatigue=Int(f["fatigue"] ?? "0") ?? 0;pain=Int(f["pain"] ?? "0") ?? 0;persistent=Int(f["persistent"] ?? "0") ?? 0;return}; weight = store.day.weight.map(number) ?? ""; bodyFat = store.day.bodyFat.map(number) ?? ""; waist = store.day.waist.map(number) ?? ""; steps = store.day.steps.map(String.init) ?? ""; performance = store.day.performance; sleep = store.day.recovery?.sleepHours.map(number) ?? ""; fatigue = store.day.recovery?.fatigue ?? 0; pain = store.day.recovery?.pain.map { $0 ? 1 : 2 } ?? 0; persistent = store.day.recovery?.persistentPain.map { $0 ? 1 : 2 } ?? 0 }
        }.tint(.forest).keyboardDone().onChange(of:DraftStorage.encoded(draftValues)){_,_ in cacheDraft()}.onDisappear{cacheDraft()}
    }
    func field(_ label: String, text: Binding<String>, keyboard: UIKeyboardType) -> some View { HStack { Text(label); TextField("待记录", text: text).multilineTextAlignment(.trailing).keyboardType(keyboard) } }
}
struct TrendsView: View {
    @EnvironmentObject var store: AppStore
    @State private var bodySheet = false
    @State private var refreshing=false
    @State private var healthMessage:String?
    var dates: [Date] { Plan.weekDates(containing: store.selectedDate, start: store.data.startDate) }
    var week: [DayRecord] { dates.map { store.record(for: $0) } }
    var body: some View {
        let weights = store.data.records.filter { $0.weight != nil && $0.date <= store.selectedDate }.sorted { $0.date < $1.date }
        let totals=TrainingTotals(week)
        let loggedMeals = week.filter { !$0.meals.isEmpty }
        VStack(spacing: 20) {
            Panel {
                SectionLabel(title: "体重趋势", subtitle: "起点 \(number(store.data.initialWeight)) kg")
                if weights.isEmpty { EmptyHint(icon: "chart.xyaxis.line", title: "你的趋势，等待第一笔记录", detail: "关注 7 日均重，而非一天的波动") }
                else {
                    Chart {
                        ForEach(weights) { record in
                            LineMark(x: .value("日期", record.date), y: .value("体重", record.weight!)).foregroundStyle(Color.forest).interpolationMethod(.linear)
                            PointMark(x: .value("日期", record.date), y: .value("体重", record.weight!)).foregroundStyle(Color.forest)
                        }
                    }.chartYScale(domain: weightDomain(weights)).chartXAxis { AxisMarks(values: .stride(by: .day, count: 7)) { AxisValueLabel(format: .dateTime.month().day()); AxisGridLine() } }.frame(height: 180)
                }
                Button { bodySheet = true } label: { Label("记录体重 / 腰围", systemImage: "plus.circle").font(.subheadline.bold()) }
            }
            Panel {
                SectionLabel(title: "本周期周报 · 实时统计", subtitle: "\(dates[0].formatted(.dateTime.month().day())) – \(dates[6].formatted(.dateTime.month().day()))")
                Button(refreshing ? "正在同步健康训练…" : "刷新健康数据并更新统计") {refreshHealth()}.disabled(refreshing || store.data.healthAccessRequested != true)
                if let healthMessage{Text(healthMessage).font(.caption).foregroundStyle(.secondary)}
                Text("以 Day 1 起算每7天；当前查看的是所选日期所在周。健康数据先同步，本机统计随编辑即时重算。").font(.caption).foregroundStyle(.secondary)
                metric("平均体重", value: Plan.mean(week.compactMap(\.weight)).map { number($0) + " kg" } ?? "待记录", detail: "\(week.compactMap(\.weight).count) / 7 天")
                metric("最新腰围", value: week.sorted { $0.date < $1.date }.compactMap(\.waist).last.map { number($0) + " cm" } ?? "待记录", detail: "肚脐水平")
                metric("平均热量", value: Plan.mean(loggedMeals.map { $0.total.calories }).map { number($0) + " kcal" } ?? "待记录", detail: "\(loggedMeals.count) 天有餐食")
                metric("平均蛋白质", value: Plan.mean(loggedMeals.map { $0.total.protein }).map { number($0) + " g" } ?? "待记录", detail: "餐食需记录完整")
                metric("平均步数", value: Plan.mean(week.compactMap { $0.steps.map(Double.init) }).map(number) ?? "待记录", detail: "\(week.compactMap(\.steps).count) 天已记录")
                metric("力量训练",value:"\(totals.strength) 次",detail:"来自当前记录，修改后即更新")
                metric("有氧 / HIIT",value:"\(totals.cardio) 次 · \(totals.cardioMinutes) 分钟",detail:"包括已导入的健康训练")
                metric("柔韧 / 其他",value:"\(totals.mobility) / \(totals.other) 次",detail:"分别统计，不计作有氧")
                if totals.pending>0 {Text("\(totals.pending) 条疑似重复训练待确认，暂未累计。").font(.caption).foregroundStyle(.orange)}
                metric("主观力量感受", value: week.filter { $0.performance != "未评估" }.last?.performance ?? "待评估", detail: "训练页另有实际记录评估")
            }
            Panel {
                Label("本周观察", systemImage: "leaf").font(.headline).foregroundStyle(Color.forest)
                Text(weeklyObservation()).font(.subheadline).lineSpacing(5)
                Text("只提示趋势，不自动调整热量目标。需要完整记录和你的状态判断。").font(.caption).foregroundStyle(.secondary)
            }
            Panel {
                SectionLabel(title: "28 天的方向")
                Text(store.data.personalProfile == nil ? "保住四肢肌肉，缩小腰围。" : "按你的目标观察身体与力量趋势。").font(.headline)
                Text(store.data.personalProfile?.fields["goal"] ?? "先建立自己的个人计划，再按身体与实际训练记录观察趋势。").font(.subheadline).foregroundStyle(.secondary)
            }
            Panel {
                NavigationLink { HealthConnectionView() } label: { Label("连接 Apple 健康", systemImage: "heart.text.clipboard") }
                Text("先收集睡眠、活动与身体数据，再与实际训练记录一起交给模型依据指南评估。在个人计划与每周 Agent 页面确认发送后生成模型评估。").font(.caption).foregroundStyle(.secondary)
            }
            WeekBudgetView()
        }.sheet(isPresented: $bodySheet) { BodyEditor() }
    }
    func refreshHealth(){refreshing=true;healthMessage=nil;Task{@MainActor in defer{refreshing=false};do{let cache=try await HealthKitReader().fetch(sleepSource:store.data.healthSleepSource);store.saveHealthCache(cache);healthMessage=store.storageError ?? "已同步，统计已重算。"}catch{healthMessage=error.localizedDescription}}}
    func metric(_ label: String, value: String, detail: String) -> some View {
        HStack { Text(label).font(.subheadline); Spacer(); VStack(alignment: .trailing, spacing: 4) { Text(value).font(.headline); Text(detail).font(.caption2).foregroundStyle(.secondary) } }.padding(.vertical, 4)
    }
    func weightDomain(_ records: [DayRecord]) -> ClosedRange<Double> {
        let values = records.compactMap(\.weight)
        return ((values.min() ?? 58) - 0.5)...((values.max() ?? 58) + 0.5)
    }
    func weeklyObservation() -> String {
        guard dates.last! < Calendar.current.startOfDay(for: Date()) else { return "本周还在进行中。先按实际情况记录，周结束后再比较均重、腰围和训练表现。" }
        guard week.compactMap(\.weight).count >= 5 else { return "本周体重数据不足 5 天，暂不判断变化。继续在相同条件下记录，避免用单日体重调整饮食。" }
        let previousDates = dates.map { Calendar.current.date(byAdding: .day, value: -7, to: $0)! }
        let previous = previousDates.map { store.record(for: $0) }
        guard previous.compactMap(\.weight).count >= 5, let currentMean = Plan.mean(week.compactMap(\.weight)), let lastMean = Plan.mean(previous.compactMap(\.weight)) else { return "已建立本周均重。等待上一周至少 5 天的体重记录，再进行可靠的周间比较。" }
        let loss = lastMean - currentMean
        let fallingStrength = week.contains { $0.performance == "下降" }
        if loss > 0.5 && fallingStrength { return "周均重下降 \(number(loss)) kg，且有力量下降记录。原计划建议评估是否增加约 100 kcal；先核对饥饿感和训练状态，再决定调整。" }
        if let waist = week.compactMap(\.waist).last, let previousWaist = previous.compactMap(\.waist).last, waist < previousWaist && loss < 0.15 { return "体重变化不大，但腰围有下降。原计划建议保持安排，继续观察力量表现，不急着减少热量。" }
        if (0.15...0.3).contains(loss) && !fallingStrength { return "周均重下降 \(number(loss)) kg，在原计划的参考区间内。若力量和饥饿感稳定，可以继续当前安排。" }
        return "本周较上一周均重变化 \(number(currentMean - lastMean)) kg。结合腰围和力量继续观察；只有连续两周体重与腰围都停滞时，才评估增加步数或调整热量。"
    }
}
struct SettingsView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var start = Date()
    @State private var waist = ""
    @State private var budget = "11000"
    @State private var baselineWeight = ""
    @State private var baselineFat = ""
    @State private var mealsPerDay = 2
    @State private var initialized = false
    @State private var finished = false
    var draftKey: String { "settings" }
    var draftValues: [String:String] { ["weight":baselineWeight,"fat":baselineFat,"waist":waist,"budget":budget,"meals":String(mealsPerDay),"start":String(start.timeIntervalSince1970),"budgetBase":String(store.data.weeklyBudget)] }
    func cacheDraft(){guard initialized,!finished else{return};do{try DraftStorage.save(draftValues,key:draftKey)}catch{store.storageError="草稿未保存："+error.localizedDescription}}

    @State private var exportURL: URL?
    @State private var error: String?
    var valid: Bool { validNumber(baselineWeight).map { $0 > 0 && $0 <= 500 } == true && (baselineFat.isEmpty || validNumber(baselineFat).map { $0 > 0 && $0 <= 75 } == true) && validNumber(budget).map { $0 >= 0 } == true && (waist.isEmpty || validNumber(waist).map { $0 > 0 } == true) }
    var body: some View {
        NavigationStack { Form {
            Section("第一阶段 · 28 天") {
                DatePicker("Day 1", selection: $start, in: ...Date(), displayedComponents: .date)
                HStack { Text("基准体重 kg"); TextField("体重", text: $baselineWeight).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                HStack { Text("基准体脂 %"); TextField("体脂", text: $baselineFat).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                Text("修正基准只影响趋势起点，保留每天的实际记录和已有目标。").font(.caption).foregroundStyle(.secondary)
                HStack { Text("基准腰围 cm"); TextField("待补充", text: $waist).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                HStack { Text("周参考预算 kcal"); TextField("11000", text: $budget).keyboardType(.numberPad).multilineTextAlignment(.trailing) }
            }
            Section("饮食方案与每日参考目标") {
                ForEach(DayMode.allCases) { mode in VStack(alignment: .leading, spacing: 6) { Label(store.data.modeTitle(mode), systemImage: mode.symbol).font(.headline); Text(store.targetText(mode)).font(.caption).foregroundStyle(.secondary) } }
                if let diet=store.data.activeDiet { Text(diet.name).font(.headline);Text(diet.rationale).font(.caption);ForEach(diet.tips,id:\.self){Text($0).font(.caption)} }
                Text("可根据目标、活动、饮食偏好和生活条件选择均衡、地中海式、DASH、素食或运动营养等安排。碳循环只是一个可选安排，不强制采用。").font(.caption).foregroundStyle(.secondary)
            }
            Section("执行方式") {
                Stepper("每日计划餐数：\(mealsPerDay) 餐", value: $mealsPerDay, in: 1...8)
                Text("餐数由你决定，也可以记录加餐。原计划为两餐；修改餐数只重新分配参考余额，不改变全天目标。训练安排与日型以实际活动为准。")
                Text("已经吃下的餐食不反悔。聚餐后不极端节食，结合实际趋势与当前周参考预算观察。")
            }.font(.subheadline)
            Section("Apple 健康") { NavigationLink("健康授权与数据") { HealthConnectionView() } }
            Section("个人资料与计划") { NavigationLink("身体数据、目标与 AI 建立计划") { PersonalPlanView() } }
            Section("每周 Agent") { NavigationLink("总结与计划调整") { WeeklyCoachView() } }
            Section("训练评估") { NavigationLink("核实资料与适用范围") { CoachEvidenceList() } }
            Section("照片自动识别") { NavigationLink("识别与授权") { VisionSettingsView() } }
            Section("数据") {
                Button { do { exportURL = try store.export() } catch { self.error = error.localizedDescription } } label: { Label("准备导出全部记录", systemImage: "square.and.arrow.up") }
                if let exportURL { ShareLink(item: exportURL) { Label("分享 JSON 备份", systemImage: "doc") } }
                Text("记录存储在本机；只有确认识别时，所选照片与备注会上传。导出包含餐食照片及本机已保存的健康数据，请自行保管。删除 App 会移除本地记录。").font(.caption).foregroundStyle(.secondary)
                if let error { Text(error).foregroundStyle(.red) }
            }

        }.navigationTitle("计划与设置").navigationBarTitleDisplayMode(.inline).toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") { store.settings(start: start, waist: Double(waist), budget: Double(budget)!, weight: Double(baselineWeight), bodyFat: Double(baselineFat), mealsPerDay: mealsPerDay); if store.storageError == nil { finished=true;DraftStorage.remove(draftKey);dismiss() } }.disabled(!valid) }
        }.onAppear { guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:draftKey){baselineWeight=f["weight"] ?? "";baselineFat=f["fat"] ?? "";waist=f["waist"] ?? "";budget=f["budgetBase"] == String(store.data.weeklyBudget) ? f["budget"] ?? number(store.data.weeklyBudget) : number(store.data.weeklyBudget);mealsPerDay=Int(f["meals"] ?? "2") ?? 2;start=Date(timeIntervalSince1970:Double(f["start"] ?? "") ?? Date().timeIntervalSince1970);return}; baselineWeight = number(store.data.initialWeight); baselineFat = store.data.initialBodyFat > 0 ? number(store.data.initialBodyFat) : ""; mealsPerDay = store.data.mealsPerDay ?? 2; start = store.data.startDate; waist = store.data.initialWaist.map(number) ?? ""; budget = number(store.data.weeklyBudget) }
        }.tint(.forest).keyboardDone().onChange(of:store.data.weeklyBudget){_,new in budget=number(new);cacheDraft()}.onChange(of:DraftStorage.encoded(draftValues)){_,_ in cacheDraft()}.onDisappear{cacheDraft()}
    }
}
