import Foundation
import CryptoKit

struct WeeklyReportPayload: Codable {
    var summary: String
    var observations: [String]
    var dataGaps: [String]
    var question: String
    var recommendation: String
    var rationale: String
    var sourceIDs: [String]
    var proposedPlans: [TrainingPlan]
}
struct WeeklyReport: Codable, Identifiable {
    var week: String
    var state: String
    var payload: WeeklyReportPayload?
    var plansHash: String
    var snapshotAt: String
    var decision: String?
    var error: String?
    var id: String { week }
}
struct WeeklyInbox: Decodable {
    var enabled: Bool
    var modelState: String
    var snapshotAt: String?
    var reports: [WeeklyReport]
    var schedule: String
    var statusText: String {
        switch modelState {
        case "ready": "模型通道已配置"
        case "subscription_eligibility_unconfirmed": "Plus 自托管资格待核实"
        case "api_key_required": "等待配置 API Key"
        default: "等待模型授权"
        }
    }
}
enum WeeklySnapshot {
    static func encoded<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601; encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(value)
    }
    static func plansHash(_ plans: [TrainingPlan]) throws -> String {
        SHA256.hash(data: try encoded(plans)).map { String(format: "%02x", $0) }.joined()
    }
    static func object<T: Encodable>(_ value: T) throws -> Any {
        try JSONSerialization.jsonObject(with: encoded(value))
    }
    struct Day: Encodable {
        var date: Date
        var mode: DayMode
        var nutrition: Nutrition?
        var mealCount: Int
        var workouts: [Workout]
        var weight: Double?
        var bodyFat: Double?
        var healthImportedFields: [String]?
        var waist: Double?
        var steps: Int?
        var performance: String
        var recovery: RecoveryRecord?
    }
    static func body(_ data: AppData, at date: Date = Date()) throws -> Data {
        let start = Calendar.current.date(byAdding: .day, value: -27, to: Calendar.current.startOfDay(for: date))!
        let end = Calendar.current.startOfDay(for: date).addingTimeInterval(86400)
        let days = data.records.filter { $0.date >= start && $0.date < end }.map {
            Day(date: $0.date, mode: $0.mode, nutrition: $0.meals.isEmpty ? nil : $0.total, mealCount: $0.meals.count, workouts: $0.workouts, weight: $0.weight, bodyFat: $0.bodyFat, healthImportedFields: $0.healthImportedFields, waist: $0.waist, steps: $0.steps, performance: $0.performance, recovery: $0.recovery)
        }
        let plans = data.trainingPlans ?? []
        var profile = try object(data.coachProfile ?? CoachProfile()) as? [String: Any] ?? [:]
        var baseline: [String:Any] = ["weight":data.initialWeight,"bodyFat":NSNull()]
        if data.initialBodyFat > 0 { baseline["bodyFat"] = data.initialBodyFat }; profile["baseline"] = baseline
        profile["personalFields"] = data.personalProfile?.fields ?? [:]
        profile["diet"] = try data.activeDiet.map(object) ?? NSNull()
        profile["nutritionTargets"] = try data.nutritionTargets.map(object) ?? [:]
        profile["weeklyBudget"] = data.weeklyBudget
        profile["plannedMealsPerDay"] = data.mealsPerDay ?? 2
        let body: [String: Any] = ["id": UUID().uuidString, "snapshotAt": ISO8601DateFormatter().string(from: date), "windowDays": 28,
            "plansHash": try plansHash(plans), "plans": try object(plans), "profile": profile,
            "records": try object(days), "health": try data.healthCache.map(object) ?? [:]]
        return try JSONSerialization.data(withJSONObject: body, options: [.sortedKeys])
    }
    static func applicable(_ report: WeeklyReport, to data: AppData, at date: Date = Date()) -> Bool {
        guard report.state == "awaiting_choice" || report.state == "accepted", report.payload?.recommendation == "adjust",
              let payload = report.payload, !payload.proposedPlans.isEmpty, payload.proposedPlans.count <= 14,
              let hash = try? plansHash(data.trainingPlans ?? []), hash == report.plansHash,
              let snapshotAt = ISO8601DateFormatter().date(from: report.snapshotAt), date >= snapshotAt, date.timeIntervalSince(snapshotAt) < 7*86400 else { return false }
        let names = Set(ExerciseLibrary.all.map(\.name))
        let evidence = Set(CoachEvidenceLibrary.sources.map(\.id))
        return !payload.sourceIDs.isEmpty && Set(payload.sourceIDs).isSubset(of: evidence) &&
            Set(payload.proposedPlans.map(\.id)).count == payload.proposedPlans.count && payload.proposedPlans.allSatisfy {
                !$0.name.isEmpty && !$0.exercises.isEmpty && $0.exercises.count <= 20 && Set($0.exercises.map(\.id)).count == $0.exercises.count &&
                    $0.exercises.allSatisfy { names.contains($0.name) && (1...12).contains($0.sets) && (1...300).contains($0.reps) }
            }
    }
}

enum PersonalPlanFingerprint {
    static func hash(_ data: AppData) -> String {
        let days = data.records.map { WeeklySnapshot.Day(date:$0.date,mode:$0.mode,nutrition:$0.meals.isEmpty ? nil : $0.total,mealCount:$0.meals.count,workouts:$0.workouts,weight:$0.weight,bodyFat:$0.bodyFat,healthImportedFields:$0.healthImportedFields,waist:$0.waist,steps:$0.steps,performance:$0.performance,recovery:$0.recovery) }
        let bytes=DraftStorage.encoded(["profile":DraftStorage.encoded(data.personalProfile),"plans":DraftStorage.encoded(data.trainingPlans),"targets":DraftStorage.encoded(data.nutritionTargets),"history":DraftStorage.encoded(days),"health":DraftStorage.encoded(data.healthCache),"budget":DraftStorage.encoded(data.weeklyBudget)])
        return SHA256.hash(data:bytes).map { String(format:"%02x",$0) }.joined()
    }
}
