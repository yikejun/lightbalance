import tempfile
import unittest
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from budget import RequestBudget

class BudgetChecks(unittest.TestCase):
    def test_limits_survive_restart_and_recover(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'budget.db'
            budget = RequestBudget(path)
            self.assertIsNone(budget.reserve(1, 2, now=100000))
            restarted = RequestBudget(path)
            self.assertIn('每小时', restarted.reserve(1, 2, now=100001))
            self.assertIsNone(restarted.reserve(1, 2, now=103601))
            self.assertIn('24 小时', restarted.reserve(1, 2, now=107202))
            self.assertIsNone(restarted.reserve(1, 2, now=186401))
    def test_parallel_requests_cannot_exceed_limit(self):
        with tempfile.TemporaryDirectory() as directory:
            budget = RequestBudget(Path(directory) / 'budget.db')
            with ThreadPoolExecutor(max_workers=8) as pool:
                results = list(pool.map(lambda _: budget.reserve(3, 3, now=100000), range(8)))
            self.assertEqual(sum(result is None for result in results), 3)

if __name__ == '__main__': unittest.main()
