import base64
import contextlib
import http.client
import io
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from budget import RequestBudget
from server import Server, Handler

class GatewayHTTPChecks(unittest.TestCase):
    def test_plus_route_never_falls_back_to_api_key(self):
        with tempfile.TemporaryDirectory() as directory:
            server = Server(('127.0.0.1', 0), Handler)
            server.auth_mode = 'chatgpt'
            server.api_key = 'bridge-test-token'
            server.app_token = 'b' * 32
            server.model = 'test-model'
            server.hourly_limit, server.daily_limit = 6, 10
            server.budget = RequestBudget(Path(directory) / 'quota.db')
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            def denied(request, **kwargs):
                self.assertEqual(request.full_url, 'http://127.0.0.1:8788/responses')
                self.assertEqual(request.get_header('Authorization'), 'Bearer bridge-test-token')
                self.assertEqual(kwargs['timeout'], 190)
                import urllib.error
                raise urllib.error.HTTPError(request.full_url, 403, 'Forbidden', {}, io.BytesIO(b'{}'))
            connection = http.client.HTTPConnection(*server.server_address, timeout=3)
            try:
                with patch('server.urllib.request.urlopen', side_effect=denied) as upstream:
                    body = json.dumps({'photo_base64': base64.b64encode(b'\xff\xd8\xff' + b'x'*100).decode()})
                    connection.request('POST', '/analyze', body, {'Authorization': 'Bearer ' + server.app_token})
                    response = connection.getresponse()
                    value = json.loads(response.read())
                    self.assertEqual(response.status, 502)
                    self.assertIn('Plus', value['error'])
                    self.assertEqual(upstream.call_count, 1)
            finally:
                connection.close()
                server.shutdown(); server.server_close(); thread.join(timeout=3)

    def test_authentication_result_and_persistent_quota(self):
        with tempfile.TemporaryDirectory() as directory:
            server = Server(('127.0.0.1', 0), Handler)
            server.api_key = 'not-a-real-key'
            server.app_token = 'a' * 32
            server.model = 'test-model'
            server.hourly_limit = 6
            server.daily_limit = 1
            server.budget = RequestBudget(Path(directory) / 'quota.db')
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            def post(token):
                connection = http.client.HTTPConnection(*server.server_address, timeout=3)
                body = json.dumps({'photo_base64': base64.b64encode(b'\xff\xd8\xff' + b'x'*100).decode(), 'note': '合成测试数据'})
                connection.request('POST', '/analyze', body=body, headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'})
                response = connection.getresponse()
                value = (response.status, json.loads(response.read()))
                connection.close()
                return value
            estimate = dict(is_food=True, name='测试', items=[], calories=755, protein=48, fat=24, carbs=82, lower=650, upper=850, uncertainty='测试')
            upstream = dict(status='completed', output=[dict(type='message', content=[dict(type='output_text', text=json.dumps(estimate))])])
            try:
                with patch('server.urllib.request.urlopen', side_effect=lambda *args, **kwargs: contextlib.closing(io.BytesIO(json.dumps(upstream).encode()))) as api:
                    self.assertEqual(post('wrong-token')[0], 401)
                    api.assert_not_called()
                    status, value = post(server.app_token)
                    self.assertEqual(status, 200)
                    self.assertEqual(value['calories'], 755)
                    self.assertEqual(post(server.app_token)[0], 429)
                    self.assertEqual(api.call_count, 1)
                    self.assertIn('24 小时', RequestBudget(Path(directory) / 'quota.db').reserve(6, 1))
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=3)

if __name__ == '__main__': unittest.main()
