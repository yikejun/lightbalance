"""Generate identical local and gateway personal-plan contracts."""
from pathlib import Path
import sys,json
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'Backend'))
import plan_ai as p
s='import Foundation\nenum PersonalPlanResources {\n'
for name,value in [('prompt',p.PROMPT),('schema',json.dumps(p.SCHEMA,ensure_ascii=False)),('sources',json.dumps(p.SOURCES,ensure_ascii=False))]:
 s+=f' static let {name} = #"""\n{value}\n"""#\n'
s+='}\n'
(root/'LightBalance/PersonalPlanResources.swift').write_text(s)
