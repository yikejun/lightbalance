import Foundation
// Tests construct requests and parse synthetic responses; no keys or network.
enum APIKeyStore { static func read() -> String { "" } }
@main struct APIChecks {
    static func main() throws {
        let dummy = "sk-" + String(repeating: "x", count: 40)
        let payload = try UserAPIRequest.meal(photo: Data([0xff,0xd8,0xff,0]), note: "小份", model: "gpt-4.1-mini")
        let req = try UserAPIRequest.request(payload: payload, key: dummy)
        assert(req.url?.absoluteString == "https://api.openai.com/v1/responses")
        assert(req.value(forHTTPHeaderField: "Authorization") == "Bearer " + dummy)
        assert(payload["store"] as? Bool == false)
        do { try UserAPIRequest.validate(key: "", model: "gpt-4.1-mini"); fatalError() } catch {}
        do { _ = try UserAPIRequest.meal(photo: Data([0]), note: "", model: "gpt-4.1-mini"); fatalError() } catch {}
        do { try UserAPIRequest.validate(key: dummy, model: "https://untrusted.example"); fatalError() } catch {}
        let nutrition: [String: Any] = ["is_food":true,"name":"测试餐食","items":[],"calories":500,"protein":30,"fat":15,"carbs":60,"lower":400,"upper":600,"uncertainty":"估算"]
        let text = String(data: try JSONSerialization.data(withJSONObject: nutrition), encoding: .utf8)!
        let envelope: [String: Any] = ["status":"completed","output":[["type":"message","content":[["type":"output_text","text":text]]]]]
        let parsed = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: envelope))
        let meal = try JSONDecoder().decode(MealEstimate.self, from: parsed).validated()
        assert(meal.calories == 500)
        var incomplete = envelope; incomplete["status"] = "incomplete"
        do { _ = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: incomplete)); fatalError() } catch {}
        let refusal: [String: Any] = ["status":"completed","output":[["type":"message","content":[["type":"refusal","refusal":"no"]]]]]
        do { _ = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: refusal)); fatalError() } catch {}
        assert(UserAPIRequest.errorMessage(429).contains("不会转用其他账户"))
        print("Passed: fixed official endpoint, credential validation, JPEG bounds, no storage, structured parsing, refusal and quota handling")
    }
}
