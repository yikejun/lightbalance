import Foundation
@main struct HealthChecks {
 @MainActor static func main() throws {
  var cal = Calendar(identifier: .gregorian);cal.timeZone = TimeZone(secondsFromGMT: 0)!
  let day = Date(timeIntervalSince1970: 1_000_000)
  let start = day; let end = day.addingTimeInterval(10 * 3600)
  let samples: [SleepSegment] = [
   .init(start: start, end: start.addingTimeInterval(4 * 3600), asleep: true, sourceID: "watch", source: "Watch"),
   .init(start: start.addingTimeInterval(3 * 3600), end: start.addingTimeInterval(8 * 3600), asleep: true, sourceID: "app", source: "App"),
   .init(start: start.addingTimeInterval(-3600), end: end, asleep: false, sourceID: "bed", source: "In bed")]
  assert(HealthMath.sleepHours(samples, from: start, to: end) == 8)
  assert(HealthMath.sleepHours(samples, from: start, to: end, sourceID: "watch") == 4)
  assert(HealthMath.sleepHours(samples, from: start.addingTimeInterval(3600), to: start.addingTimeInterval(5 * 3600)) == 4)
  assert(HealthMath.sleepHours([], from: start, to: end) == nil)
  assert(HealthMath.sleepHours(samples, from: start, to: end, sourceID: "unknown") == nil)
  // Calendar windows remain local noon-to-noon across daylight saving changes.
  cal.timeZone = TimeZone(identifier: "America/Los_Angeles")!
  let dst = cal.date(from: .init(year: 2026, month: 3, day: 8))!
  let window = HealthMath.sleepWindow(for: dst, calendar: cal)
  assert(window.1.timeIntervalSince(window.0) == 23 * 3600)
  let workout = HealthWorkout(id: UUID(), start: start, end: end, name: "力量", minutes: 30, source: "Watch")
  let duplicate = HealthWorkout(id: UUID(), start: start.addingTimeInterval(60), end: end, name: "力量", minutes: 30, source: "App")
  assert(HealthMath.possiblyDuplicate(workout, in: [workout,duplicate]))
  assert(!HealthMath.possiblyDuplicate(workout, in: [workout]))
  let path = FileManager.default.temporaryDirectory.appendingPathComponent("health-check-" + UUID().uuidString + ".json")
  defer { try? FileManager.default.removeItem(at: path) }
  let store = AppStore(storageURL: path);let selected = store.selectedDate
  store.update { $0.weight = 58; $0.recovery = .init(sleepHours: 6, fatigue: 4, pain: true, persistentPain: false) }
  let hkDay = HealthDay(date: selected, values: ["weight":.init(value: 59,sources:["Scale"]),"waist":.init(value: 70,sources:["Health"]),"steps":.init(value: 8000,sources:["Watch"]),"sleep":.init(value: 8,sources:["Watch"])])
  store.saveHealthCache(.init(refreshedAt: Date(), days: [hkDay], workouts: [workout], sleepSources: [.init(id:"watch",name:"Watch")], issues: []))
  store.markHealthAuthorizationRequested();store.importHealthDay(hkDay)
  assert(store.day.weight == 58 && store.day.waist == 70 && store.day.steps == 8000)
  assert(store.day.recovery?.sleepHours == 6 && store.day.recovery?.fatigue == 4 && store.day.recovery?.pain == true)
  assert(store.day.workouts.isEmpty)
  let loaded = AppStore(storageURL: path);assert(loaded.data.healthCache?.workouts.count == 1)
  loaded.clearHealthCache();assert(loaded.data.healthCache == nil && loaded.day.steps == 8000 && loaded.data.healthAccessRequested == false)
  assert(loaded.day.recovery?.pain == true)
  // Missing or non-finite values never become phantom measurements.
  let blank = HealthDay(date: Calendar.current.date(byAdding: .day, value: -1, to: selected)!, values: ["steps":.init(value: .nan,sources:[])])
  loaded.importHealthDay(blank);assert(loaded.record(for: blank.date).steps == nil)
  let nowStart=Calendar.current.startOfDay(for:selected).addingTimeInterval(12*3600)
  let imported=HealthWorkout(id:UUID(),start:nowStart,end:nowStart.addingTimeInterval(1800),name:"力量训练",minutes:30,source:"Watch",trainingType:"力量")
  loaded.update {$0.workouts.append(Workout(kind:"全身",minutes:30,sets:[],note:"手动记录",trainingType:"力量"))}
  let manualID=loaded.day.workouts[0].id
  loaded.importHealthWorkouts([imported]);loaded.importHealthWorkouts([imported])
  assert(loaded.day.workouts.count==2 && loaded.day.workouts[1].healthDuplicateOf==manualID)
  assert(loaded.day.workouts[1].sets.isEmpty && !loaded.day.workouts[1].countsForSummary)
  loaded.resolveHealthDuplicate(imported.id,merge:true)
  assert(loaded.day.workouts.count==1 && loaded.day.workouts[0].healthWorkoutID==imported.id && loaded.day.workouts[0].note=="手动记录")
  loaded.importHealthWorkouts([imported]);assert(loaded.day.workouts.count==1)
  loaded.setHealthWorkoutSync(false)
  let cardio=HealthWorkout(id:UUID(),start:nowStart.addingTimeInterval(7200),end:nowStart.addingTimeInterval(9000),name:"跑步",minutes:30,source:"Watch",trainingType:"有氧")
  loaded.saveHealthCache(.init(refreshedAt:Date(),days:[],workouts:[imported,cardio],sleepSources:[],issues:[]))
  assert(loaded.day.workouts.count==1)
  loaded.setHealthWorkoutSync(true);assert(loaded.day.workouts.count==2 && !loaded.day.workouts.last!.isStrength)
  print("Passed: sleep interval union, in-bed exclusion, source selection, missing values, DST windows, duplicate workout flagging, cache persistence, explicit import without overwrite, no training double count, and cache clearing")
 }
}
