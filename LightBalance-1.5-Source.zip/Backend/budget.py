"""Persisted global request allowance for a single-user gateway."""
import sqlite3
import time
from pathlib import Path

class RequestBudget:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = str(path)
        with sqlite3.connect(self.path) as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS attempts (started REAL NOT NULL)")
            connection.execute("CREATE INDEX IF NOT EXISTS attempt_time ON attempts(started)")

    def reserve(self, hourly_limit, daily_limit, now=None):
        now = time.time() if now is None else now
        with sqlite3.connect(self.path, timeout=5) as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute("DELETE FROM attempts WHERE started <= ?", (now - 86400,))
            daily = connection.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]
            hourly = connection.execute("SELECT COUNT(*) FROM attempts WHERE started > ?", (now - 3600,)).fetchone()[0]
            if daily >= daily_limit:
                return "已达到最近 24 小时的识别次数限制，请稍后重试。"
            if hourly >= hourly_limit:
                return "已达到每小时识别次数限制，请稍后重试。"
            connection.execute("INSERT INTO attempts(started) VALUES (?)", (now,))
        return None
