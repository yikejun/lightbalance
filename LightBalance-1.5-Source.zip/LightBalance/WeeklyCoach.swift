import SwiftUI

enum WeeklyService {
    static func request(_ path: String, body: Data? = nil) async throws -> Data {
        #if LIGHTBALANCE_USER_API
        throw VisionError.message("API 版暂不连接开发者的个人周报服务器。")
        #else
        guard let photoURL = URL(string: UserDefaults.standard.string(forKey: "visionEndpoint") ?? ""), photoURL.scheme == "https", photoURL.host != nil, photoURL.user == nil, photoURL.password == nil else { throw VisionError.message("请先配置个人识别服务。") }
        var components = URLComponents(url: photoURL, resolvingAgainstBaseURL: false)!
        components.path = "/coach/v1/" + path; components.query = nil; components.fragment = nil
        guard let url = components.url else { throw VisionError.message("服务地址无效。") }
        let token = VisionCredentials.read()
        guard !token.isEmpty else { throw VisionError.message("请先配置个人服务令牌。") }
        var request = URLRequest(url: url); request.timeoutInterval = 210
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        if let body { request.httpMethod = "POST"; request.httpBody = body; request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else { throw VisionError.message("周报服务请求失败。请检查连接、授权及计划是否已变更。") }
        return data
        #endif
    }
    #if LIGHTBALANCE_USER_API
    static let automatic = false
    static let syncDescription = "API 版在你点击生成时，直接将资料发给 OpenAI，不使用开发者服务器。手机关闭时不会后台生成。"
    static let consentMessage = "允许用你自己的 API 在点击生成时分析最近28天训练、营养合计及已读取的健康资料？调用独立计费，结果保存在本机。不会使用开发者服务器或其他人的额度。"
    static func inbox(data: AppData) async throws -> WeeklyInbox {
        WeeklyInbox(enabled: data.weeklyCoachEnabled == true, modelState: APIKeyStore.read().isEmpty ? "api_key_required" : "ready", reports: data.weeklyAPIReports ?? [], schedule: "每周打开 App，使用自己的 API 生成总结")
    }
    static func consent(_ enabled: Bool) async throws {}
    static func sync(_ data: AppData) async throws {}
    static func generate(data: AppData) async throws -> (String, WeeklyReport?) {
        var calendar = Calendar(identifier: .iso8601); calendar.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        let week = String(format: "%d-W%02d",calendar.component(.yearForWeekOfYear, from: Date()),calendar.component(.weekOfYear, from: Date()))
        if (data.weeklyAPIReports ?? []).contains(where: { $0.week == week }) { return ("already_attempted", nil) }
        return ("awaiting_choice", try await WeeklyAPI.generate(data))
    }
    static func decide(_ report: WeeklyReport, choice: String) async throws {}
    #else
    static let automatic = true
    static let syncDescription = "启用后，打开App及保存记录时同步到你的服务器。手机未同步的新数据不会被云端读取；请先在 Apple 健康页面刷新睡眠等数据。照片和单餐明细不随周报上传。"
    static let consentMessage = "最近28天的训练组、营养合计、体重腰围、主观恢复及已读取的睡眠、心率等健康资料会保存到你的服务器。启用模型后用于每周分析，并消耗你授权的模型额度。关闭后停止生成和同步。"
    static func inbox(data: AppData) async throws -> WeeklyInbox { try JSONDecoder().decode(WeeklyInbox.self, from: await request("inbox")) }
    static func consent(_ enabled: Bool) async throws { _ = try await request("consent", body: JSONSerialization.data(withJSONObject: ["enabled": enabled])) }
    static func sync(_ data: AppData) async throws { _ = try await request("snapshot", body: WeeklySnapshot.body(data)) }
    static func generate(data: AppData) async throws -> (String, WeeklyReport?) {
        let data = try await request("generate", body: Data("{}".utf8))
        return (((try JSONSerialization.jsonObject(with: data)) as? [String: String])?["state"] ?? "unknown", nil)
    }
    static func decide(_ report: WeeklyReport, choice: String) async throws {
        _ = try await request("reports/" + report.week + "/decision", body: JSONSerialization.data(withJSONObject: ["choice": choice]))
    }
    #endif
}
struct WeeklyCoachView: View {
    @EnvironmentObject var store: AppStore
    @State private var inbox: WeeklyInbox?
    @State private var busy = false
    @State private var message: String?
    @State private var confirmingConsent = false
    var body: some View {
        Form {
            Section("每周训练 Agent") {
                Text(inbox?.statusText ?? "正在检查服务状态")
                Text(inbox?.schedule ?? "每周日 20:00（上海时间）")
                if let date = inbox?.snapshotAt { Text("最近同步：" + date).font(.caption).foregroundStyle(.secondary) }
                Text("模型阅读最近28天已同步的训练、身体与恢复资料，按提供的权威资料判断是否调整。调整需你预览确认。").font(.caption)
                Button("刷新周报") { perform { inbox = try await WeeklyService.inbox(data: store.data) } }
                if store.data.weeklyCoachEnabled == true {
                    if WeeklyService.automatic { Button("同步最新资料") { perform { try await WeeklyService.sync(store.data); inbox = try await WeeklyService.inbox(data: store.data) } } }
                    Button("现在生成本周总结") { perform {
                        try await WeeklyService.sync(store.data)
                        let (state, localReport) = try await WeeklyService.generate(data: store.data)
                        if let localReport { store.saveWeeklyAPIReport(localReport) }
                        message = state == "awaiting_choice" ? "本周总结已生成" : state == "already_attempted" ? "本周已有生成记录，请查看下方状态。" : "暂未生成：" + state
                        inbox = try await WeeklyService.inbox(data: store.data)
                    } }.disabled(inbox?.modelState != "ready")
                    Button(WeeklyService.automatic ? "关闭自动周报" : "关闭 API 周报", role: .destructive) { perform { try await WeeklyService.consent(false); store.setWeeklyCoachEnabled(false); inbox = try await WeeklyService.inbox(data: store.data) } }
                } else { Button(WeeklyService.automatic ? "启用并同步资料" : "启用 API 周报") { confirmingConsent = true } }
                Text(WeeklyService.syncDescription).font(.caption).foregroundStyle(.secondary)
                Link(WeeklyService.automatic ? "管理 ChatGPT 用量" : "查看 API 用量", destination: URL(string: WeeklyService.automatic ? "https://chatgpt.com/#settings/Usage" : "https://platform.openai.com/usage")!)
                if let message { Text(message).font(.caption) }
            }
            ForEach(inbox?.reports ?? []) { report in
                Section(report.week) {
                    if let payload = report.payload {
                        Text(payload.summary).font(.headline)
                        ForEach(Array(payload.observations.enumerated()), id: \.offset) { Text($0.element) }
                        ForEach(Array(payload.dataGaps.enumerated()), id: \.offset) { Text("待补充：" + $0.element).foregroundStyle(.secondary) }
                        Text(payload.rationale)
                        ForEach(CoachEvidenceLibrary.sources.filter { payload.sourceIDs.contains($0.id) }) { source in
                            Link(source.title, destination: URL(string: source.url)!)
                        }
                        Text(payload.question).font(.headline)
                        if !payload.proposedPlans.isEmpty {
                            Text("调整预览 · 完整替代计划").font(.headline)
                            ForEach(payload.proposedPlans) { plan in
                                Text(plan.name).bold()
                                ForEach(plan.exercises) { exercise in Text("\(exercise.name) · \(exercise.sets)组 × \(exercise.reps)\(ExerciseLibrary.all.first { $0.name == exercise.name }?.timed == true ? "秒" : "次")") }
                            }
                            Button("确认采用调整") { perform {
                                guard WeeklySnapshot.applicable(report, to: store.data), store.storageError == nil else { throw VisionError.message("计划或资料已变更，请同步后重新评估。") }
                                try await WeeklyService.decide(report, choice: "accept")
                                guard store.applyWeeklyPlans(report) else { throw VisionError.message("计划未保存，请检查本机存储。") }
                                if !WeeklyService.automatic { store.markWeeklyAPIReport(report.week, choice: "accept") }
                                inbox = try await WeeklyService.inbox(data: store.data)
                            } }.disabled(!WeeklySnapshot.applicable(report, to: store.data))
                        }
                        if report.state == "awaiting_choice" { Button("保持当前计划") { perform { try await WeeklyService.decide(report, choice: "keep"); if !WeeklyService.automatic { store.markWeeklyAPIReport(report.week, choice: "keep") }; inbox = try await WeeklyService.inbox(data: store.data) } } }
                        else { Text(report.state == "accepted" ? "已确认采用" : report.state == "kept" ? "已选择保持" : report.state).font(.caption) }
                    } else { Text(report.state == "failed" ? "生成失败：" + (report.error ?? "未知错误") : report.state == "running" ? "正在生成，稍后刷新" : report.state) }
                }
            }
        }.navigationTitle("每周 Agent").disabled(busy)
        .overlay { if busy { ProgressView().padding().background(.regularMaterial).clipShape(RoundedRectangle(cornerRadius: 12)) } }
        .task { perform { inbox = try await WeeklyService.inbox(data: store.data) } }
        .alert(WeeklyService.automatic ? "允许同步训练与健康资料？" : "允许调用 API 评估训练与健康资料？", isPresented: $confirmingConsent) {
            Button("取消", role: .cancel) {}
            Button(WeeklyService.automatic ? "启用并同步" : "启用 API 周报") { perform {
                try await WeeklyService.consent(true); store.setWeeklyCoachEnabled(true)
                try await WeeklyService.sync(store.data); inbox = try await WeeklyService.inbox(data: store.data)
            } }
        } message: { Text(WeeklyService.consentMessage) }
    }
    func perform(_ action: @escaping @MainActor () async throws -> Void) {
        busy = true
        Task { @MainActor in
            defer { busy = false }
            do { try await action() } catch { message = error.localizedDescription }
        }
    }
}
