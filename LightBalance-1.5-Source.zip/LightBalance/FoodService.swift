import Foundation

final class FoodRedirectGuard: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
enum FoodService {
    #if LIGHTBALANCE_USER_API
    static let destinationNotice = "资料由手机直接发送给 OpenAI，使用你自己的 API Key，独立计费。"
    #else
    static let destinationNotice = "资料发送到你配置的个人识别服务，再交给 OpenAI，使用该服务关联账户的额度。"
    #endif
    static let consent = destinationNotice + "发送你选择的食物照片、营养标签、备注，以及当前日期的已确认餐食名称、营养合计、参考目标与餐数。聊天发送本页最近的对话和同样的饮食参考数据；不发送身体或健康数据。使用你配置的模型账户额度。建议须你确认实际食用量后才记账。"
    static func object(_ text: String) throws -> Any { try JSONSerialization.jsonObject(with: Data(text.utf8)) }
    static func preview(images: [FoodPhoto], note: String, context: [String: Any]) async throws -> FoodPreview {
        guard (1...6).contains(images.count), images.contains(where: { $0.role == "food" }), note.count <= 2000,
              images.allSatisfy({ ["food","label"].contains($0.role) && $0.data.starts(with:[0xff,0xd8,0xff]) && $0.data.count <= 700000 }), images.reduce(0, { $0+$1.data.count }) <= 2800000 else { throw VisionError.message("至少选择一张食物照片，最多6张；请缩小照片或备注。") }
        let body: [String: Any] = ["images":images.map { ["role":$0.role,"base64":$0.data.base64EncodedString()] },"note":note,"context":context]
        #if LIGHTBALANCE_USER_API
        var content: [[String: Any]] = [["type":"input_text","text":String(data:try JSONSerialization.data(withJSONObject:["context":context,"note":note]),encoding:.utf8)!]]
        for image in images {
            content += [["type":"input_text","text":"下一张用途："+image.role],["type":"input_image","image_url":"data:image/jpeg;base64,"+image.data.base64EncodedString(),"detail":"high"]]
        }
        let raw = try await UserAPIClient.complete(payload: payload(prompt:FoodResources.previewPrompt,schema:FoodResources.previewSchema,name:"meal_before_eating",input:[["role":"user","content":content]]))
        #else
        let raw = try await gateway(path:"meal-preview",body:body)
        #endif
        return try JSONDecoder().decode(FoodPreview.self,from:raw).validated()
    }
    static func chat(messages: [FoodChatMessage], context: [String: Any]) async throws -> String {
        let history = Array(messages.suffix(12)).map { ["role":$0.role,"content":String($0.content.prefix(4000))] }
        #if LIGHTBALANCE_USER_API
        let input = [["role":"user","content":"当前饮食参考："+String(data:try JSONSerialization.data(withJSONObject:context),encoding:.utf8)!]]+history
        let raw = try await UserAPIClient.complete(payload: payload(prompt:FoodResources.chatPrompt,schema:FoodResources.chatSchema,name:"food_chat",input:input))
        #else
        let raw = try await gateway(path:"chat",body:["context":context,"messages":history])
        #endif
        let answer = try JSONDecoder().decode(FoodChatAnswer.self,from:raw).answer
        guard !answer.isEmpty, answer.count <= 12000 else { throw VisionError.message("回复内容无效，请重试。") }
        return answer
    }
    #if LIGHTBALANCE_USER_API
    static func payload(prompt: String, schema: String, name: String, input: Any) throws -> [String: Any] {
        ["model":UserDefaults.standard.string(forKey:"userAPIModel") ?? "gpt-4.1-mini","store":false,"max_output_tokens":4500,"instructions":prompt,"input":input,"text":["format":["type":"json_schema","name":name,"strict":true,"schema":try object(schema)]]]
    }
    #else
    static func gateway(path: String, body: [String: Any]) async throws -> Data {
        guard let base=URL(string:UserDefaults.standard.string(forKey:"visionEndpoint") ?? ""),base.scheme=="https",base.host != nil,base.user==nil,base.password==nil,base.query==nil,base.fragment==nil,var parts=URLComponents(url:base,resolvingAgainstBaseURL:false) else { throw VisionError.message("请先配置个人识别服务。") }
        parts.path="/"+path
        guard let url=parts.url else { throw VisionError.message("服务地址无效。") }
        let token=VisionCredentials.read();guard !token.isEmpty else { throw VisionError.message("请先配置服务访问令牌。") }
        var request=URLRequest(url:url);request.httpMethod="POST";request.timeoutInterval=210
        request.setValue("application/json",forHTTPHeaderField:"Content-Type");request.setValue("Bearer "+token,forHTTPHeaderField:"Authorization")
        request.httpBody=try JSONSerialization.data(withJSONObject:body)
        let configuration=URLSessionConfiguration.ephemeral;configuration.urlCache=nil
        let session=URLSession(configuration:configuration,delegate:FoodRedirectGuard(),delegateQueue:nil);defer {session.invalidateAndCancel()}
        let (data,response)=try await session.data(for:request)
        guard let response=response as? HTTPURLResponse else { throw VisionError.message("服务返回无效。") }
        guard response.statusCode==200 else {
            let error=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any]
            throw VisionError.message(error?["error"] as? String ?? "饮食助手暂时无法完成请求。")
        }
        return data
    }
    #endif
}
