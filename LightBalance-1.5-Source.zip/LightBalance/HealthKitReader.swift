import Foundation
#if os(iOS) && !targetEnvironment(macCatalyst)
import HealthKit
#endif

@MainActor final class HealthKitReader {
 #if os(iOS) && !targetEnvironment(macCatalyst)
 private let health = HKHealthStore()
 private struct Metric {
  let id: HKQuantityTypeIdentifier
  let key: String
  let unit: HKUnit
  let options: HKStatisticsOptions
  var scale: Double = 1
 }
 private var metrics: [Metric] { [
  .init(id: .stepCount, key: "steps", unit: .count(), options: .cumulativeSum),
  .init(id: .activeEnergyBurned, key: "activeEnergy", unit: .kilocalorie(), options: .cumulativeSum),
  .init(id: .bodyMass, key: "weight", unit: .gramUnit(with: .kilo), options: .discreteMostRecent),
  .init(id: .bodyFatPercentage, key: "bodyFat", unit: .percent(), options: .discreteMostRecent, scale: 100),
  .init(id: .waistCircumference, key: "waist", unit: .meterUnit(with: .centi), options: .discreteMostRecent),
  .init(id: .restingHeartRate, key: "restingHeartRate", unit: .count().unitDivided(by: .minute()), options: .discreteAverage),
  .init(id: .heartRateVariabilitySDNN, key: "hrv", unit: .secondUnit(with: .milli), options: .discreteAverage)
 ] }
 #endif
 static var available: Bool {
  #if os(iOS) && !targetEnvironment(macCatalyst)
  HKHealthStore.isHealthDataAvailable()
  #else
  false
  #endif
 }
 func authorize() async throws {
  #if os(iOS) && !targetEnvironment(macCatalyst)
  guard Self.available else { throw HealthReadError.unavailable }
  var types = Set<HKObjectType>(metrics.compactMap { HKObjectType.quantityType(forIdentifier: $0.id) })
  types.insert(HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!); types.insert(HKObjectType.workoutType())
  try await health.requestAuthorization(toShare: [], read: types)
  #else
  throw HealthReadError.unavailable
  #endif
 }
 func fetch(sleepSource: String? = nil, now: Date = Date()) async throws -> HealthCache {
  #if os(iOS) && !targetEnvironment(macCatalyst)
  guard Self.available else { throw HealthReadError.unavailable }
  let cal = Calendar.current; let today = cal.startOfDay(for: now)
  let start = cal.date(byAdding: .day, value: -27, to: today)!
  var days = (0..<28).map { HealthDay(date: cal.date(byAdding: .day, value: $0, to: start)!) }
  var issues: [String] = []
  for metric in metrics {
   do {
    let values = try await quantities(metric, from: start, to: now, calendar: cal)
    for i in days.indices { if let value = values[days[i].date] { days[i].values[metric.key] = value } }
   } catch { issues.append("部分 \(metric.key) 数据暂无法读取，请重试或检查健康权限。") }
  }
  var sources: [HealthSource] = []
  do {
   let from = HealthMath.sleepWindow(for: start, calendar: cal).0
   let samples = try await query(HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!, from: from, to: now) as? [HKCategorySample] ?? []
   var found: [String:String] = [:]
   let segments = samples.map { sample -> SleepSegment in
    let source = sample.sourceRevision.source
    let id = source.bundleIdentifier + "|" + source.name
    found[id] = source.name
    let sleeping = [HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,HKCategoryValueSleepAnalysis.asleepCore.rawValue,HKCategoryValueSleepAnalysis.asleepDeep.rawValue,HKCategoryValueSleepAnalysis.asleepREM.rawValue].contains(sample.value)
    return .init(start: sample.startDate, end: sample.endDate, asleep: sleeping, sourceID: id, source: source.name)
   }
   sources = found.map { .init(id: $0.key, name: $0.value) }.sorted { $0.name < $1.name }
   for i in days.indices {
    let window = HealthMath.sleepWindow(for: days[i].date, calendar: cal)
    let end = min(window.1,now)
    if let hours = HealthMath.sleepHours(segments, from: window.0, to: end, sourceID: sleepSource) {
     let used = Set(segments.filter { $0.asleep && $0.start < end && $0.end > window.0 && (sleepSource == nil || $0.sourceID == sleepSource) }.map(\.source))
     days[i].values["sleep"] = .init(value: hours, sources: used.sorted())
    }
   }
  } catch { issues.append("睡眠记录暂无法读取，请重试或检查健康权限。") }
  var workouts: [HealthWorkout] = []
  do {
   let samples = try await query(HKObjectType.workoutType(), from: start, to: now) as? [HKWorkout] ?? []
   workouts = samples.map { .init(id: $0.uuid, start: $0.startDate, end: $0.endDate, name: workoutName($0.workoutActivityType), minutes: $0.duration / 60, calories: $0.statistics(for: HKQuantityType(.activeEnergyBurned))?.sumQuantity()?.doubleValue(for: .kilocalorie()), source: $0.sourceRevision.source.name, trainingType: workoutCategory($0.workoutActivityType)) }
  } catch { issues.append("训练记录暂无法读取，请重试或检查健康权限。") }
  return .init(refreshedAt: now, days: days, workouts: workouts.sorted { $0.start > $1.start }, sleepSources: sources, issues: issues)
  #else
  throw HealthReadError.unavailable
  #endif
 }
 #if os(iOS) && !targetEnvironment(macCatalyst)
 private func quantities(_ metric: Metric, from start: Date, to end: Date, calendar: Calendar) async throws -> [Date:HealthValue] {
  let type = HKObjectType.quantityType(forIdentifier: metric.id)!
  let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
  return try await withCheckedThrowingContinuation { continuation in
   let query = HKStatisticsCollectionQuery(quantityType: type, quantitySamplePredicate: predicate, options: metric.options, anchorDate: start, intervalComponents: DateComponents(day: 1))
   query.initialResultsHandler = { _,collection,error in
    if let error { continuation.resume(throwing: error); return }
    var values: [Date:HealthValue] = [:]
    collection?.enumerateStatistics(from: start, to: end) { stat,_ in
     let q = metric.options == .cumulativeSum ? stat.sumQuantity() : metric.options == .discreteMostRecent ? stat.mostRecentQuantity() : stat.averageQuantity()
     if let q {
      let v = q.doubleValue(for: metric.unit) * metric.scale
      if v.isFinite { values[calendar.startOfDay(for: stat.startDate)] = .init(value: v, sources: (stat.sources ?? []).map(\.name).sorted()) }
     }
    }
    continuation.resume(returning: values)
   }
   health.execute(query)
  }
 }
 private func query(_ type: HKSampleType, from start: Date, to end: Date) async throws -> [HKSample] {
  try await withCheckedThrowingContinuation { continuation in
   let q = HKSampleQuery(sampleType: type, predicate: HKQuery.predicateForSamples(withStart: start, end: end, options: []), limit: HKObjectQueryNoLimit, sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]) { _,samples,error in
    if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: samples ?? []) }
   }; health.execute(q)
  }
 }
 private func workoutCategory(_ kind: HKWorkoutActivityType) -> String {
  switch kind {
  case .traditionalStrengthTraining, .functionalStrengthTraining, .coreTraining: "力量"
  case .walking, .running, .cycling, .swimming, .elliptical, .rowing, .stairClimbing, .hiking: "有氧"
  case .yoga, .pilates, .flexibility: "柔韧"
  default: "其他"
  }
 }
 private func workoutName(_ kind: HKWorkoutActivityType) -> String {
  switch kind {
  case .traditionalStrengthTraining: "传统力量训练"
  case .functionalStrengthTraining: "功能性力量训练"
  case .walking: "步行"
  case .running: "跑步"
  case .cycling: "骑行"
  case .swimming: "游泳"
  case .highIntensityIntervalTraining: "间歇训练"
  case .yoga: "瑜伽"
  case .pilates: "普拉提"
  case .elliptical: "椭圆机"
  case .rowing: "划船"
  case .coreTraining: "核心训练"
  default: "其他训练（类型 \(kind.rawValue)）"
  }
 }
 #endif
}
enum HealthReadError: LocalizedError {
 case unavailable
 var errorDescription: String? { "当前设备无法读取 Apple 健康，请在 iPhone 上使用。" }
}
