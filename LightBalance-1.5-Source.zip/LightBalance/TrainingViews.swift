import SwiftUI

struct TrainingView: View {
    @EnvironmentObject var store: AppStore
    @State private var adding = false
    @State private var editing: Workout?
    @State private var plans = false
    @State private var library = false
    var body: some View {
        VStack(spacing: 20) {
            Panel {
                SectionLabel(title: "按你的实际训练来", subtitle: "自选计划 · 实际记录 · 趋势评估")
                Text(store.data.personalProfile == nil ? "原安排参考：每周力量 3 次、有氧 2 次。你可以选择模板、修改动作，或自由记录；计划中的组数不会自动算作已完成。" : "按已确认的个人安排训练，也可以自由记录；计划组数不会自动算作已完成。").font(.subheadline).foregroundStyle(.secondary)
                Button("选择 / 配置训练计划") { plans = true }.font(.headline)
                Button("浏览 \(ExerciseLibrary.all.count) 个力量动作") { library = true }.font(.subheadline)
            }
            Button { adding = true } label: { Label("自由记录一次训练", systemImage: "plus.circle.fill").font(.headline).frame(maxWidth: .infinity).padding(18).background(Color.forest, in: RoundedRectangle(cornerRadius: 18)).foregroundStyle(.white) }
            if store.day.workouts.isEmpty { Panel { EmptyHint(icon: "dumbbell", title: "今天，还没有训练记录", detail: "按实际情况填写每组\n无需照着固定 A / B 计划") } }
            ForEach(store.day.workouts) { workout in
                if workout.healthDuplicateOf != nil {
                    Panel {
                        Text(workout.kind+" · Apple 健康").font(.headline)
                        Text("可能与这天的手填训练重复，暂不重复计入次数。").font(.caption)
                        Button("同一次训练，关联手填记录"){store.resolveHealthDuplicate(workout.id,merge:true)}
                        Button("是另一场训练，保留独立记录"){store.resolveHealthDuplicate(workout.id,merge:false)}
                    }
                }
                Button { editing = workout } label: { Panel {
                    HStack { Text("编辑训练").font(.caption.bold()).foregroundStyle(Color.forest);Spacer();Image(systemName:"chevron.right").foregroundStyle(Color.forest) }
                    SectionLabel(title: workout.kind, subtitle: "\(workout.minutes) 分钟 · \(workout.sets.filter(\.working).count) 工作组")
                    ForEach(workout.sets) { set in SetRow(set: set) }
                    if let source=workout.healthSource {
                        Text("Apple 健康 · "+source).font(.caption).foregroundStyle(.secondary)
                        if workout.sets.isEmpty { Text("健康未提供逐组信息；可点击补充实际组数。").font(.caption).foregroundStyle(.secondary) }
                    }
                    if workout.isStrength && workout.countsForSummary {
                        ForEach(TrainingAssessment.comparisons(workout: workout, records: store.data.records, date: store.selectedDate), id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                    }
                    if !workout.note.isEmpty { Text(workout.note).font(.caption).foregroundStyle(.secondary) }
                    Label("编辑实际记录", systemImage: "pencil").font(.caption).foregroundStyle(Color.forest)
                } }.buttonStyle(.plain)
            }
            Panel {
                SectionLabel(title: "训练评估", subtitle: "所选日期向前 7 天")
                ForEach(TrainingAssessment.summary(records: store.data.records, ending: store.selectedDate), id: \.self) { Text($0).font(.subheadline).foregroundStyle(.secondary) }
            }
            Panel {
                SectionLabel(title: "Apple 健康 / 健身")
                Text("可在 iPhone 上授权读取睡眠、步数、身体指标与训练记录。逐组重量、次数和余力保存在轻衡；健康中的训练单独展示。").font(.subheadline).foregroundStyle(.secondary)
                NavigationLink("连接 Apple 健康 / 查看数据") { HealthConnectionView() }
            }
        }.sheet(isPresented: $adding) { WorkoutEditor() }
        .sheet(item: $editing) { WorkoutEditor(workout: $0) }
        .sheet(isPresented: $plans) { TrainingPlansView() }
        .sheet(isPresented: $library) { ExercisePickerView { _ in } }
    }
}
struct SetRow: View {
    var set: ExerciseSet
    var body: some View {
        HStack(alignment: .top) {
            ExerciseThumbnail(name: set.exercise, size: 36)
            VStack(alignment: .leading) {
                Text(set.exercise)
                Text([set.warmup == true ? "热身组" : "工作组", set.rir.map { "余力 \($0) 次" } ?? "余力未填", set.loadMode ?? "外部负重"].joined(separator: " · ")).font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            Text(set.seconds.map { "\($0) 秒" } ?? "\(number(set.weight)) kg × \(set.reps)").foregroundStyle(.secondary)
        }.font(.subheadline)
    }
}
struct ExercisePickerView: View {
    var choose: (String) -> Void
    @Environment(\.dismiss) var dismiss
    @State private var search = ""
    @State private var muscle = "全部"
    @State private var equipment = "全部"
    @State private var custom = ""
    @State private var artwork: ExerciseDefinition?
    @State private var initialized = false
    @State private var draftError: String?
    var pickerDraft:[String:String]{["search":search,"muscle":muscle,"equipment":equipment,"custom":custom]}

    var filtered: [ExerciseDefinition] {
        ExerciseLibrary.all.filter {
            (muscle == "全部" || $0.muscle == muscle) && (equipment == "全部" || $0.equipment == equipment) &&
            (search.isEmpty || [$0.name, $0.muscle, $0.equipment, $0.pattern].contains { $0.localizedCaseInsensitiveContains(search) })
        }
    }
    var body: some View {
        NavigationStack { List {
            Section("筛选") {
                Picker("主要肌群", selection: $muscle) { ForEach(["全部"] + ExerciseLibrary.muscles, id: \.self) { Text($0) } }
                Picker("器械分类", selection: $equipment) { ForEach(["全部"] + ExerciseLibrary.equipment, id: \.self) { Text($0) } }
            }
            Section("自定义动作") {
                if let draftError{Text(draftError).foregroundStyle(.red).font(.caption)}
                TextField("找不到？输入你的动作名称", text: $custom)
                Button("使用自定义动作") { choose(custom.trimmingCharacters(in: .whitespacesAndNewlines)); dismiss() }.disabled(custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            Section("\(filtered.count) 个动作 · 点击选择") {
                ForEach(filtered) { exercise in
                    HStack(spacing: 12) {
                        Button { artwork = exercise } label: { ExerciseThumbnail(name: exercise.name) }
                            .buttonStyle(.plain).accessibilityLabel("查看\(exercise.name)图片")
                        Button { choose(exercise.name); dismiss() } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack { Text(exercise.name).fontWeight(.semibold).foregroundStyle(Color.forest);Spacer();Image(systemName:"chevron.right").font(.caption).foregroundStyle(Color.forest) }
                                Text("\(exercise.muscle) · \(exercise.equipment) · \(exercise.timed ? "计时" : "次数")\(exercise.advanced ? " · 技术要求较高" : "")").font(.caption).foregroundStyle(.secondary)
                                Text(ExerciseArt.all[exercise.name]?.reference == true ? "同类参考图 · 点图查看差异" : "点图放大 · 点名称选择").font(.caption2).foregroundStyle(Color.forest)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }.buttonStyle(.plain)
                    }
                }
            }
            Section("动作库说明") {
                Text("分类参考 ACE 动作库，动作名称与中文标签由轻衡整理。覆盖常见器械、自重、弹力带与自由重量动作；仍可自定义，不声称包含所有变式。动作配图仅供识别，标注为同类参考的图片不代表该变式。没有照片或视频评估，不能判断你的动作是否正确。")
                Link("ACE 动作库 · 查阅动作演示", destination: URL(string: "https://www.acefitness.org/resources/everyone/exercise-library/")!)
            }.font(.caption)
        }.searchable(text: $search, prompt: "搜索动作、肌群或器械")
        .sheet(item: $artwork) { ExerciseImageDetail(name: $0.name) }
        .navigationTitle("力量动作库").navigationBarTitleDisplayMode(.inline).keyboardDone()
        .onAppear{guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:"exercise-picker"){search=f["search"] ?? "";muscle=f["muscle"] ?? "全部";equipment=f["equipment"] ?? "全部";custom=f["custom"] ?? ""}}
        .onChange(of:DraftStorage.encoded(pickerDraft)){_,_ in guard initialized else{return};do{try DraftStorage.save(pickerDraft,key:"exercise-picker")}catch{draftError="动作输入草稿未保存"}}
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
        }.tint(.forest)
    }
}
struct TrainingPlansView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var draft: TrainingPlan?
    @State private var starting: TrainingPlan?
    var body: some View {
        NavigationStack { List {
            if let schedule=store.data.personalSchedule,schedule.count==7 {
                Section("已确认的每周安排") { ForEach(schedule.indices,id:\.self){i in Text(["周一","周二","周三","周四","周五","周六","周日"][i]+"："+schedule[i])} }
            }
            Section("AI 建立计划") { NavigationLink("根据身体数据与目标建立 / 更新计划"){PersonalPlanView()} }
            Section("我的计划 · 左滑删除") {
                if (store.data.trainingPlans ?? []).isEmpty { Text("先从模板复制，或创建自己的计划。").foregroundStyle(.secondary) }
                ForEach(store.data.trainingPlans ?? []) { plan in planRow(plan, saved: true) }
                    .onDelete { offsets in
                        let plans = store.data.trainingPlans ?? []
                        for index in offsets { store.removePlan(plans[index].id) }
                    }
                Button("新建我的计划") { draft = TrainingPlan(name: "我的计划", exercises: []) }
            }
            Section("可选模板 · 单次训练示例") {
                ForEach(ExerciseLibrary.templates) { plan in planRow(plan, saved: false) }
            }
            Section("如何选择") {
                Text("每次选一个适合器械条件和恢复状态的模板。全身 A / B、上下肢、推拉分化是不同选择，不需要同时全部执行。模板默认 3 组 × 10 次，计时动作 30 秒，可自行修改；重量从能稳定完成的水平开始。")
                Text("参考 ACSM 2026：规律训练主要肌群，比复杂计划更重要。评估依据实际记录，不用通用组数给你打健康分。")
                Link("查看训练研究依据", destination: URL(string: "https://acsm.org/resistance-training-guidelines-update-2026/")!)
            }.font(.caption)
        }.navigationTitle("自选训练计划").navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
        .sheet(item: $draft) { PlanEditor(plan: $0) }
        .sheet(item: $starting) { WorkoutEditor(plan: $0) }
        }.tint(.forest)
    }
    func planRow(_ plan: TrainingPlan, saved: Bool) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(plan.name).font(.headline)
            Text(plan.exercises.map(\.name).joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
            HStack {
                Button("按此计划记录") { starting = plan }.buttonStyle(ActionButtonStyle())
                Spacer()
                Button(saved ? "编辑计划" : "复制并修改") {
                    draft = saved ? plan : TrainingPlan(name: plan.name, exercises: plan.exercises)
                }.buttonStyle(ActionButtonStyle())
            }
        }.padding(.vertical, 5)
    }
}
struct PlanEditor: View {
    var plan: TrainingPlan
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var exercises: [PlannedExercise] = []
    @State private var selecting = false
    @State private var initialized = false
    @State private var finished = false
    var draftKey: String { "plan-"+((store.data.trainingPlans ?? []).contains(where:{$0.id==plan.id}) ? plan.id.uuidString : "new") }
    var draftValues: [String:String] { ["name":name,"exercises":DraftStorage.encoded(exercises).base64EncodedString()] }
    func cacheDraft(){guard initialized,!finished else{return};do{try DraftStorage.save(draftValues,key:draftKey)}catch{store.storageError="草稿未保存："+error.localizedDescription}}

    var body: some View {
        NavigationStack { Form {
            Section("计划名称") { TextField("例如：周一全身", text: $name) }
            Section("动作与参考目标 · 可调整顺序") {
                ForEach($exercises) { $item in
                    VStack(alignment: .leading) {
                        HStack { ExerciseThumbnail(name: item.name, size: 44); Text(item.name).font(.headline) }
                        Stepper("目标 \(item.sets) 组", value: $item.sets, in: 1...12)
                        Stepper("每组 \(item.reps) \(ExerciseLibrary.find(item.name)?.timed == true ? "秒" : "次")", value: $item.reps, in: 1...300)
                    }
                }.onDelete { exercises.remove(atOffsets: $0) }.onMove { exercises.move(fromOffsets: $0, toOffset: $1) }
                Button("从动作库添加") { selecting = true }
            }
            Section { Text("这里只设置参考目标，训练时仍需逐组填写实际表现。计划保存在本机。") }.font(.caption)
        }.navigationTitle("配置我的计划").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .primaryAction) { EditButton() }
            ToolbarItem(placement: .confirmationAction) { Button("保存") {
                let savedDraftKey=draftKey
                store.savePlan(TrainingPlan(id: plan.id, name: name.trimmingCharacters(in: .whitespacesAndNewlines), exercises: exercises))
                if store.storageError == nil { finished=true;DraftStorage.remove(savedDraftKey);dismiss() }
            }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || exercises.isEmpty) }
        }.onAppear { guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:draftKey){name=f["name"] ?? "";if let bytes=Data(base64Encoded:f["exercises"] ?? ""),let items=try? JSONDecoder().decode([PlannedExercise].self,from:bytes){exercises=items};return}; name = plan.name; exercises = plan.exercises }
        .sheet(isPresented: $selecting) { ExercisePickerView { exercises.append(PlannedExercise(name: $0)) } }
        }.tint(.forest).keyboardDone().onChange(of:DraftStorage.encoded(draftValues)){_,_ in cacheDraft()}.onDisappear{cacheDraft()}
    }
}
struct WorkoutEditor: View {
    var workout: Workout? = nil
    var plan: TrainingPlan? = nil
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var kind = "力量"
    @State private var title = "自由力量训练"
    @State private var minutes = 40
    @State private var sets: [ExerciseSet] = []
    @State private var exercise = ""
    @State private var weight = "0"
    @State private var reps = 10
    @State private var seconds = 30
    @State private var timed = false
    @State private var loadMode = "外部负重"
    @State private var warmup = false
    @State private var rir = -1
    @State private var note = ""
    @State private var selecting = false
    @State private var changing: UUID?
    @State private var initialized = false
    @State private var finished = false
    var draftKey: String { "workout-"+DraftStorage.dayKey(store.selectedDate)+"-"+(workout?.id.uuidString ?? "new") }
    var draftValues: [String:String] { ["kind":kind,"title":title,"minutes":String(minutes),"sets":DraftStorage.encoded(sets).base64EncodedString(),"exercise":exercise,"weight":weight,"reps":String(reps),"seconds":String(seconds),"timed":String(timed),"loadMode":loadMode,"warmup":String(warmup),"rir":String(rir),"note":note,"changing":changing?.uuidString ?? ""] }
    func cacheDraft(){guard initialized,!finished else{return};do{try DraftStorage.save(draftValues,key:draftKey)}catch{store.storageError="草稿未保存："+error.localizedDescription}}

    var loadValid: Bool { validNumber(weight).map { $0 <= 1000 } == true }
    var body: some View {
        NavigationStack { Form {
            Section("训练") {
                Picker("类型", selection: $kind) { Text("力量").tag("力量"); Text("有氧").tag("有氧");Text("柔韧 / 身心").tag("柔韧");Text("其他").tag("其他") }
                TextField("训练名称", text: $title)
                Stepper("实际时长 \(minutes) 分钟", value: $minutes, in: 1...360)
            }
            if kind == "力量" {
                if let plan {
                    Section("计划参考 · 点击切换动作") {
                        ForEach(plan.exercises) { item in
                            Button { select(item.name); reps = item.reps; seconds = item.reps } label: {
                                HStack { ExerciseThumbnail(name: item.name, size: 40); Text(item.name); Spacer(); Text("\(sets.filter { $0.exercise == item.name && $0.working }.count) / \(item.sets) 组").font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }
                }
                Section(changing == nil ? "添加实际完成的一组" : "修改选中的一组") {
                    Button(exercise.isEmpty ? "从动作库选择 / 自定义" : exercise) { selecting = true }
                    Toggle("按秒记录", isOn: $timed)
                    if timed { Stepper("持续 \(seconds) 秒", value: $seconds, in: 1...3600) }
                    else {
                        Picker("负重方式", selection: $loadMode) { ForEach(["外部负重", "单侧负重", "自重", "辅助重量"], id: \.self) { Text($0) } }
                        if loadMode != "自重" { HStack { Text("重量 kg"); TextField("0", text: $weight).keyboardType(.decimalPad).multilineTextAlignment(.trailing) } }
                        Stepper("实际 \(reps) 次", value: $reps, in: 1...300)
                        Text("杠铃记总重量，哑铃可选择单侧负重并记单只重量；单腿动作的次数按每侧记录。辅助重量越大通常越轻松，不与外部负重比较。").font(.caption).foregroundStyle(.secondary)
                    }
                    Toggle("这是热身组", isOn: $warmup)
                    Picker("余力 RIR", selection: $rir) {
                        Text("未填写").tag(-1)
                        ForEach(0...5, id: \.self) { Text($0 == 5 ? "还能做 5 次以上" : "还能做 \($0) 次").tag($0) }
                    }
                    Text("余力指保持动作标准还能完成几次；0 表示已无余力。无需为了填数刻意练到力竭。").font(.caption).foregroundStyle(.secondary)
                    Button(changing == nil ? "添加这组" : "保存这组修改") { saveSet() }
                        .disabled(exercise.isEmpty || (!timed && loadMode != "自重" && !loadValid))
                    if changing != nil { Button("取消这组修改") { changing = nil } }
                }
                Section("已记录 \(sets.count) 组 · 点击修改，左滑移除") {
                    ForEach(sets) { set in Button { edit(set) } label: { SetRow(set: set) }.foregroundStyle(Color.forest) }
                        .onDelete { offsets in if offsets.contains(where: { sets[$0].id == changing }) { changing = nil }; sets.remove(atOffsets: offsets) }
                }
            }
            Section("感受与备注") { TextField("状态、器械设置、动作幅度、实际情况", text: $note, axis: .vertical) }
            Section { Text("只保存已添加的实际组数。修改训练类型为有氧后，保存时将不保留力量组。实际力量训练会更新为高碳日；机动日保留你的安排。").font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle(workout == nil ? "记录实际训练" : "编辑实际训练").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("完成") {
                store.update { day in
                    let record = Workout(id: workout?.id ?? UUID(), kind: kind == "有氧" ? "有氧" : title.trimmingCharacters(in: .whitespacesAndNewlines), minutes: minutes, sets: kind == "有氧" ? [] : sets, note: note, trainingType: kind, healthWorkoutID:workout?.healthWorkoutID,healthSource:workout?.healthSource,startedAt:workout?.startedAt,endedAt:workout?.endedAt,healthDuplicateOf:workout?.healthDuplicateOf,healthIndependent:workout?.healthIndependent)
                    if let index = day.workouts.firstIndex(where: { $0.id == record.id }) { day.workouts[index] = record } else { day.workouts.append(record) }
                    if day.mode != .flexible { day.mode = day.workouts.contains(where: \.isStrength) ? .high : .medium }
                }
                if store.storageError == nil { finished=true;DraftStorage.remove(draftKey);dismiss() }
            }.disabled(changing != nil || (kind == "力量" && ((sets.isEmpty && workout?.healthWorkoutID == nil) || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))) }
        }.onAppear { guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:draftKey){kind=f["kind"] ?? "力量";title=f["title"] ?? "自由力量训练";minutes=Int(f["minutes"] ?? "40") ?? 40;exercise=f["exercise"] ?? "";weight=f["weight"] ?? "0";reps=Int(f["reps"] ?? "10") ?? 10;seconds=Int(f["seconds"] ?? "30") ?? 30;timed=f["timed"] == "true";loadMode=f["loadMode"] ?? "外部负重";warmup=f["warmup"] == "true";rir=Int(f["rir"] ?? "-1") ?? -1;note=f["note"] ?? "";changing=UUID(uuidString:f["changing"] ?? "");if let bytes=Data(base64Encoded:f["sets"] ?? ""),let items=try? JSONDecoder().decode([ExerciseSet].self,from:bytes){sets=items};return};
            if let workout { kind = workout.trainingType ?? (workout.isStrength ? "力量" : "有氧"); title = workout.kind; minutes = workout.minutes; sets = workout.sets; note = workout.note }
            else if let plan { title = plan.name; if let first = plan.exercises.first { select(first.name); reps = first.reps; seconds = first.reps } }
        }.sheet(isPresented: $selecting) { ExercisePickerView { select($0) } }
        }.tint(.forest).keyboardDone().onChange(of:DraftStorage.encoded(draftValues)){_,_ in cacheDraft()}.onDisappear{cacheDraft()}
    }
    func select(_ name: String) { exercise = name; timed = ExerciseLibrary.find(name)?.timed == true }
    func edit(_ set: ExerciseSet) {
        changing = set.id; exercise = set.exercise; weight = number(set.weight); reps = set.reps; seconds = set.seconds ?? 30
        timed = set.seconds != nil; warmup = set.warmup == true; rir = set.rir ?? -1; loadMode = set.loadMode ?? "外部负重"
    }
    func saveSet() {
        let set = ExerciseSet(id: changing ?? UUID(), exercise: exercise, weight: timed || loadMode == "自重" ? 0 : validNumber(weight)!, reps: timed ? 0 : reps, seconds: timed ? seconds : nil, rir: rir < 0 ? nil : rir, warmup: warmup, loadMode: timed ? "计时" : loadMode)
        if let index = sets.firstIndex(where: { $0.id == set.id }) { sets[index] = set } else { sets.append(set) }
        changing = nil
    }
}
