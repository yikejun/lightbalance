import Foundation

struct HealthValue: Codable {
 var value: Double
 var sources: [String]
}
struct HealthDay: Codable, Identifiable {
 var date: Date
 var values: [String: HealthValue] = [:]
 var id: Date { date }
}
struct HealthWorkout: Codable, Identifiable {
 var id: UUID
 var start: Date
 var end: Date
 var name: String
 var minutes: Double
 var calories: Double?
 var source: String
 var trainingType: String? = nil
 var category: String { trainingType ?? (["传统力量训练","功能性力量训练","核心训练","力量"].contains(name) ? "力量" : ["跑步","步行","骑行","游泳","椭圆机","划船","有氧"].contains(name) ? "有氧" : ["瑜伽","普拉提"].contains(name) ? "柔韧" : "其他") }
}
struct HealthSource: Codable, Identifiable, Hashable {
 var id: String
 var name: String
}
struct HealthCache: Codable {
 var refreshedAt: Date
 var days: [HealthDay]
 var workouts: [HealthWorkout]
 var sleepSources: [HealthSource]
 var issues: [String]
}
struct SleepSegment {
 var start: Date
 var end: Date
 var asleep: Bool
 var sourceID: String
 var source: String
}
enum HealthMath {
 // Union asleep intervals, excluding in-bed/awake records. A sample is counted once across devices/stages.
 static func sleepHours(_ segments: [SleepSegment], from start: Date, to end: Date, sourceID: String? = nil) -> Double? {
  let intervals = segments.filter { $0.asleep && (sourceID == nil || $0.sourceID == sourceID) }
   .map { (max($0.start,start), min($0.end,end)) }.filter { $0.0 < $0.1 }.sorted { $0.0 < $1.0 }
  guard var current = intervals.first else { return nil }
  var total: TimeInterval = 0
  for interval in intervals.dropFirst() {
   if interval.0 <= current.1 { current.1 = max(current.1,interval.1) }
   else { total += current.1.timeIntervalSince(current.0); current = interval }
  }
  total += current.1.timeIntervalSince(current.0)
  return total / 3600
 }
 static func sleepWindow(for date: Date, calendar: Calendar) -> (Date,Date) {
  let noon = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: date)!
  return (calendar.date(byAdding: .day, value: -1, to: noon)!,noon)
 }
 static func possiblyDuplicate(_ a: HealthWorkout, in all: [HealthWorkout]) -> Bool {
  all.contains { b in
   guard a.id != b.id, a.name == b.name else { return false }
   let overlap = min(a.end,b.end).timeIntervalSince(max(a.start,b.start))
   let shortest = min(a.end.timeIntervalSince(a.start),b.end.timeIntervalSince(b.start))
   return shortest > 0 && overlap / shortest > 0.8
  }
 }
}
