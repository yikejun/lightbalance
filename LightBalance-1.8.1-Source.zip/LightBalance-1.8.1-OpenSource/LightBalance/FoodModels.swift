import Foundation

struct FoodPhoto: Codable, Identifiable {
    var id = UUID()
    var data: Data
    var role: String
}
struct FoodPortion: Codable {
    var name: String
    var available: Bool
    var availableGrams: Double
    var recommendedGrams: Double
    var per100g: Nutrition
    var note: String
    func nutrition(grams: Double) -> Nutrition {
        let scale = grams / 100
        return Nutrition(calories: per100g.calories * scale, protein: per100g.protein * scale, fat: per100g.fat * scale, carbs: per100g.carbs * scale)
    }
}
struct FoodPreview: Codable {
    var name: String
    var assessment: String
    var explanation: String
    var items: [FoodPortion]
    var uncertainty: String
    var availableTotal: Nutrition { items.filter(\.available).reduce(Nutrition()) { $0 + $1.nutrition(grams: $1.availableGrams) } }
    func validated() throws -> Self {
        guard ["over","under","balanced","uncertain"].contains(assessment), items.count <= 20,
              items.allSatisfy({ item in
                  !item.name.isEmpty && [item.availableGrams,item.recommendedGrams].allSatisfy { $0.isFinite && (0...5000).contains($0) } &&
                  (!item.available || item.recommendedGrams <= item.availableGrams) && (item.available || item.availableGrams == 0) &&
                  [item.per100g.calories,item.per100g.protein,item.per100g.fat,item.per100g.carbs].allSatisfy { $0.isFinite && (0...1000).contains($0) }
              }) else { throw VisionError.message("份量或营养建议异常，请重试或手动记录。") }
        return self
    }
    var assessmentText: String { switch assessment { case "over": "按这餐参考额度，现有份量偏多"; case "under": "按这餐参考额度，可以考虑补充"; case "balanced": "与这餐参考额度大致匹配"; default: "资料不足，先核对份量" } }
}
struct FoodChatAnswer: Decodable { var answer: String }
struct FoodChatMessage: Codable, Identifiable {
    var id = UUID()
    var role: String
    var content: String
}
enum FoodContext {
    static func make(data: AppData, day: DayRecord, excluding: UUID? = nil) -> [String: Any] {
        let meals = day.meals.filter { $0.id != excluding }
        let eaten = meals.reduce(Nutrition()) { $0 + $1.nutrition }
        let target = data.nutritionTargets?[day.mode.rawValue] ?? (data.nutritionTargets == nil ? day.mode.target : Nutrition())
        let count = data.mealsPerDay ?? 2
        let remainingMeals = max(1,count-meals.filter { $0.kind != "加餐" }.count)
        var targets: [String: Any] = values(target)
        var balances: [String: Any] = ["calories":target.calories-eaten.calories,"protein":target.protein-eaten.protein,"fat":target.fat-eaten.fat,"carbs":target.carbs-eaten.carbs]
        if target.calories == 0 { targets = ["calories":NSNull(),"protein":NSNull(),"fat":NSNull(),"carbs":NSNull()]; balances = targets }
        else if day.mode == .flexible && data.nutritionTargets == nil { targets["fat"] = NSNull(); targets["carbs"] = NSNull(); balances["fat"] = NSNull(); balances["carbs"] = NSNull() }
        return ["date":ISO8601DateFormatter().string(from: day.date),"dayMode":data.modeTitle(day.mode),
                "plannedMeals":count,"confirmedMeals":meals.count,"remainingMealsReference":remainingMeals,
                "target":targets,"confirmedIntake":values(eaten),
                "remaining":balances,
                "mealReferenceCalories":target.calories == 0 ? NSNull() : max(0,target.calories-eaten.calories)/Double(remainingMeals),
                "confirmedFoods":meals.map { ["name":$0.name,"nutrition":values($0.nutrition)] },
                "memoryEnabled":memoryEnabled, "recentConfirmedMeals":memoryEnabled ? recent(data:data,ending:day.date) : [],
                "note":"参考额度按尚未记录的计划餐次分配，不要求吃满。实际摄入可能记录不完整；未知过敏及偏好请询问。"]
    }
    static var memoryEnabled:Bool {
        #if LIGHTBALANCE_USER_API
        false
        #else
        UserDefaults.standard.bool(forKey:"foodMemoryEnabled")
        #endif
    }
    static func recent(data:AppData,ending:Date)->[[String:Any]] {
        let start=Calendar.current.date(byAdding:.day,value:-13,to:Calendar.current.startOfDay(for:ending))!
        return Array(data.records.filter{$0.date>=start && $0.date<=ending}.sorted{$0.date>$1.date}.flatMap{day in day.meals.map{["date":ISO8601DateFormatter().string(from:day.date),"kind":$0.kind,"name":String($0.name.prefix(200)),"nutrition":values($0.nutrition)] as [String:Any]}}.prefix(48))
    }
    static func values(_ n: Nutrition) -> [String: Double] { ["calories":n.calories,"protein":n.protein,"fat":n.fat,"carbs":n.carbs] }
}

struct MealDraft: Codable {
    var fields: [String: String]
    var photos: [FoodPhoto]
    var preview: FoodPreview?
    var grams: [String]
    var adopted: Bool
}
struct ChatDraft: Codable { var messages: [FoodChatMessage]; var text: String }
