import SwiftUI
import UIKit
import CryptoKit

struct AIWork: Codable, Identifiable {
    var id = UUID()
    var key: String
    var title: String
    var kind: String
    var date: Date
    var created = Date()
    var state = "preparing"
    var result: Data?
    var error: String?
    var host: String?
    var request: Data?
    var accepted = false
    var delivered = false
    var signature: Data?
    var profile: PersonalProfile?
    var baseHash: String?
    var pending: Bool { ["preparing","queued","running","waiting"].contains(state) }
    var status: String { pending ? "正在分析 · 可离开页面" : state == "completed" ? "分析完成" : error ?? "未完成" }
}
struct AIWorkPaused:LocalizedError {var errorDescription:String?{"请恢复原服务地址或授权，再打开 App 取回；云端任务未取消。"}}
enum AIInputSignature {static func make<T:Encodable>(_ value:T)->Data {Data(SHA256.hash(data:DraftStorage.encoded(value)))}}
enum AIWorkScope { @TaskLocal static var id: UUID? }
struct RemoteAIJob: Decodable { var id: String; var state: String; var result: JSONValue?; var error: String? }
// JSON values preserve validated server results without decoding into a view's state.
enum JSONValue: Codable {
    case object([String:JSONValue]), array([JSONValue]), string(String), number(Double), bool(Bool), null
    init(from decoder:Decoder)throws { let c=try decoder.singleValueContainer();if c.decodeNil(){self = .null}else if let v=try? c.decode(Bool.self){self = .bool(v)}else if let v=try? c.decode(Double.self){self = .number(v)}else if let v=try? c.decode(String.self){self = .string(v)}else if let v=try? c.decode([String:JSONValue].self){self = .object(v)}else{self = .array(try c.decode([JSONValue].self))} }
    func encode(to encoder:Encoder)throws {var c=encoder.singleValueContainer();switch self{case .object(let v):try c.encode(v);case .array(let v):try c.encode(v);case .string(let v):try c.encode(v);case .number(let v):try c.encode(v);case .bool(let v):try c.encode(v);case .null:try c.encodeNil()}}
}
@MainActor final class AIWorkCenter: ObservableObject {
    static let shared = AIWorkCenter()
    @Published private(set) var jobs: [AIWork] = []
    @Published var revision = UUID()
    @Published var storageError: String?
    private var tasks: [UUID:Task<Void,Never>] = [:]
    private weak var store: AppStore?
    private var journal:URL { DraftStorage.root.deletingLastPathComponent().appendingPathComponent("ai-work.json") }
    init() {if let raw=try? Data(contentsOf:journal),let saved=try? JSONDecoder().decode([AIWork].self,from:raw){jobs=saved}}
    func attach(_ store:AppStore){self.store=store;resume()}
    func save(){do{try FileManager.default.createDirectory(at:journal.deletingLastPathComponent(),withIntermediateDirectories:true);try JSONEncoder().encode(jobs).write(to:journal,options:[.atomic,.completeFileProtectionUntilFirstUserAuthentication]);storageError=nil}catch{storageError="分析任务未保存，请保持 App 打开。"};revision=UUID()}
    func active(_ key:String)->Bool {jobs.contains{$0.key==key && $0.pending}}
    func latest(_ key:String)->AIWork? {jobs.last{$0.key==key}}
    func change(_ id:UUID,_ action:(inout AIWork)->Void){guard let i=jobs.firstIndex(where:{$0.id==id})else{return};action(&jobs[i]);save()}
    func start(key:String,title:String,kind:String,date:Date,signature:Data?=nil,planData:AppData?=nil,operation:@escaping @MainActor () async throws -> Data){
        guard !active(key) else{return}
        var job=AIWork(key:key,title:title,kind:kind,date:date);job.signature=signature;job.profile=planData?.personalProfile;job.baseHash=planData.map{PersonalPlanService.hash($0)}
        jobs.append(job);save();guard storageError==nil else{change(job.id){$0.state="failed";$0.error="任务未保存，未调用模型。"};return}
        let id=job.id
        tasks[id]=Task { @MainActor in
            let background=UIApplication.shared.beginBackgroundTask(withName:"AI analysis"){}
            defer{if background != .invalid{UIApplication.shared.endBackgroundTask(background)};tasks[id]=nil}
            do{let bytes=try await AIWorkScope.$id.withValue(id){try await operation()};change(id){$0.result=bytes;$0.state="completed";$0.request=nil};await deliver(id)}
            catch is AIWorkPaused{change(id){$0.state="waiting";$0.error=AIWorkPaused().localizedDescription}}
            catch{change(id){$0.state="failed";$0.error=error.localizedDescription;$0.request=nil}}
        }
    }
    func prepare(_ id:UUID,path:String,body:[String:Any])throws {
        guard let host=URL(string:UserDefaults.standard.string(forKey:"visionEndpoint") ?? "")?.host else{throw VisionError.message("请配置个人服务。")}
        let raw=try JSONSerialization.data(withJSONObject:["id":id.uuidString.lowercased(),"route":"/"+path,"body":body])
        change(id){$0.host=host;$0.request=raw;$0.state="queued"}
        if storageError != nil{throw VisionError.message("无法保存任务，未提交模型分析。")}
    }
    func cloud(_ id:UUID) async throws -> Data {
        guard let original=jobs.first(where:{$0.id==id}),original.host==URL(string:UserDefaults.standard.string(forKey:"visionEndpoint") ?? "")?.host else{throw AIWorkPaused()}
        if !original.accepted,let body=original.request {
            // Repeated submission uses the same durable ID, including after a lost response.
            while true {
                do {guard original.host==URL(string:UserDefaults.standard.string(forKey:"visionEndpoint") ?? "")?.host else{throw AIWorkPaused()};let (_,status)=try await FoodService.transport(path:"v1/jobs",method:"POST",body:body)
                    guard status==202 else{throw VisionError.message("分析任务提交失败。")};change(id){$0.accepted=true};break
                } catch is AIWorkPaused {throw AIWorkPaused()}
                  catch let error as VisionError {throw error}
                  catch {change(id){$0.state="waiting"};try await Task.sleep(for:.seconds(5))}
            }
        }
        while true {
            do {
                guard original.host==URL(string:UserDefaults.standard.string(forKey:"visionEndpoint") ?? "")?.host else{throw AIWorkPaused()}
                let (bytes,status)=try await FoodService.transport(path:"v1/jobs/"+id.uuidString.lowercased(),method:"GET")
                guard status==200 else{throw VisionError.message("原任务不存在，请在任务列表查看；未自动重复调用模型。")}
                let remote=try JSONDecoder().decode(RemoteAIJob.self,from:bytes)
                guard remote.id==id.uuidString.lowercased() else{throw VisionError.message("任务编号不匹配，结果未采用。")}
                if !["completed","failed"].contains(remote.state){change(id){$0.state=remote.state}}
                if remote.state=="completed",let result=remote.result{return try JSONEncoder().encode(result)}
                if remote.state=="failed"{throw VisionError.message(remote.error ?? "分析未完成。")}
            } catch is AIWorkPaused {throw AIWorkPaused()}
                  catch let error as VisionError {throw error}
              catch {change(id){$0.state="waiting";$0.error="连接中断，回到 App 后继续取回。"};try await Task.sleep(for:.seconds(5));continue}
            try await Task.sleep(for:.seconds(3))
        }
    }
    func resume(){
        for job in jobs where job.pending && tasks[job.id]==nil {
            #if LIGHTBALANCE_USER_API
            change(job.id){$0.state="failed";$0.error="App 已重新启动；API 直连任务无法取回，未自动再次扣费。"}
            #else
            guard job.request != nil else{change(job.id){$0.state="failed";$0.error="任务尚未提交，未调用模型。"};continue}
            if Date().timeIntervalSince(job.created)>7*86400{change(job.id){$0.state="failed";$0.error="任务恢复窗口已过期，未自动重新生成。"};continue}
            let id=job.id
            tasks[id]=Task{@MainActor in defer{tasks[id]=nil};do{let bytes=try await AIWorkScope.$id.withValue(id){try await cloud(id)};change(id){$0.result=bytes;$0.state="completed";$0.request=nil};await deliver(id)}catch is AIWorkPaused{change(id){$0.state="waiting";$0.error=AIWorkPaused().localizedDescription}}catch{change(id){$0.state="failed";$0.error=error.localizedDescription;$0.request=nil}}}
            #endif
        }
        for job in jobs where job.state=="completed" && !job.delivered {Task{@MainActor in await deliver(job.id)}}
    }
    func deliver(_ id:UUID) async {
        guard let job=jobs.first(where:{$0.id==id}),!job.delivered,let raw=job.result,let store else{return}
        do {
            switch job.kind {
            case "plan":
                var proposal=try JSONDecoder().decode(PersonalProposal.self,from:raw).validated(profile:job.profile ?? PersonalProfile(fields:[:]))
                proposal.baseHash=job.baseHash;proposal.createdAt=job.created
                // Stable job date prevents duplicate insertion when delivery is resumed.
                if !(store.data.personalPlanHistory ?? []).contains(where:{$0.proposal.createdAt==job.created && $0.proposal.baseHash==job.baseHash}){store.savePersonalProposal(proposal)}
                guard store.storageError==nil else{return}
            case "meal":
                if var draft=DraftStorage.load(MealDraft.self,key:job.key),AIInputSignature.make(draft)==job.signature {
                    draft.preview=try JSONDecoder().decode(FoodPreview.self,from:raw).validated();draft.grams=draft.preview!.items.map{_ in ""};draft.adopted=false;try DraftStorage.save(draft,key:job.key)
                }
            case "chat":
                if var draft=DraftStorage.load(ChatDraft.self,key:job.key){let answer=try JSONDecoder().decode(FoodChatAnswer.self,from:raw).answer;if !draft.messages.contains(where:{$0.id==job.id}){draft.messages.append(.init(id:job.id,role:"assistant",content:answer))};try DraftStorage.save(draft,key:job.key)}
            case "weekly":
                #if LIGHTBALANCE_USER_API
                store.saveWeeklyAPIReport(try JSONDecoder().decode(WeeklyReport.self,from:raw))
                #else
                let inbox=try await WeeklyService.inbox(data:store.data);store.cacheWeeklyReports(inbox.reports)
                #endif
                guard store.storageError==nil else{return}
            default:break
            }
            change(id){$0.delivered=true}
        }catch{storageError="结果已保留，返回 App 后可再次取回。"}
    }
}
struct AIWorkView:View {
    @EnvironmentObject var store:AppStore
    @ObservedObject var center=AIWorkCenter.shared
    @State private var mealJob:AIWork?
    @AppStorage("foodMemoryEnabled") private var memory=false
    @State private var clear=false
    @State private var message:String?
    var body:some View {
        List {
            if let error=center.storageError{Text(error).foregroundStyle(.red)}
            #if !LIGHTBALANCE_USER_API
            Section("饮食记忆") {
                Toggle("使用近期饮食记忆",isOn:$memory)
                Text("开启后发送近14天已确认餐食，云端另保留最近8次饮食建议供参考。照片不进入记忆；建议不算实际摄入。").font(.caption).foregroundStyle(.secondary)
                Button("清空云端饮食记忆",role:.destructive){clear=true}
                if let message{Text(message).font(.caption)}
            }
            #endif
            Section("分析任务") {
                if center.jobs.isEmpty{Text("暂无分析任务")}
                ForEach(center.jobs.reversed()){job in
                    DisclosureGroup {Text(job.status);if job.pending,let error=job.error{Text(error).font(.caption)};if let raw=job.result {
                        if job.kind=="meal",let preview=try? JSONDecoder().decode(FoodPreview.self,from:raw){Text(preview.name);Text(preview.explanation);ForEach(preview.items.indices,id:\.self){i in Text(preview.items[i].name+" · 建议 "+number(preview.items[i].recommendedGrams)+" g")};Text(preview.uncertainty).font(.caption);Button("返回对应餐食草稿"){store.selectedDate=job.date;mealJob=job}}
                        else if job.kind=="chat",let answer=try? JSONDecoder().decode(FoodChatAnswer.self,from:raw){Text(answer.answer).textSelection(.enabled)}
                        else{Text("结果已保存到计划 / 周总结历史。").font(.caption)}
                    }} label:{VStack(alignment:.leading){Text(job.title);Text(job.created.formatted(date:.abbreviated,time:.shortened)+" · "+job.status).font(.caption).foregroundStyle(.secondary)}}
                }
            }
        }.navigationTitle("AI 任务与记忆").onAppear{center.attach(store)}
        .sheet(item:$mealJob){job in MealEditor(meal:store.record(for:job.date).meals.first{$0.id.uuidString==job.key.components(separatedBy:"-").dropFirst(2).joined(separator:"-")})}
        .alert("清空云端饮食记忆？",isPresented:$clear){Button("取消",role:.cancel){};Button("清空",role:.destructive){memory=false;Task{do{_ = try await FoodService.transport(path:"v1/memory/clear",method:"POST",body:Data("{}".utf8));message="饮食记忆已清空。"}catch{message=error.localizedDescription}}}} message:{Text("清除云端餐食参考和建议记忆，手机记录与任务结果保留。")}
    }
}
