import SwiftUI
import UIKit

struct FoodChatView: View {
    @EnvironmentObject var store: AppStore
    @State private var messages: [FoodChatMessage] = []
    @State private var draft = ""
    @ObservedObject private var ai=AIWorkCenter.shared
    var busy:Bool {ai.active(draftKey)}
    @State private var error: String?
    @State private var consent = false
    @State private var allowed = false
    @State private var initialized = false
    @State private var consumedJob:UUID?
    var draftKey: String { "chat-"+DraftStorage.dayKey(store.selectedDate) }
    var cached: ChatDraft { .init(messages:messages,text:draft) }
    func persist(){guard initialized else{return};do{try DraftStorage.save(cached,key:draftKey)}catch{self.error="对话草稿未保存："+error.localizedDescription}}
    func restore(){if let value=DraftStorage.load(ChatDraft.self,key:draftKey){messages=value.messages;draft=value.text}else{messages=[];draft=""};initialized=true}

    var body: some View {
        VStack(spacing:0) {
            VStack(alignment:.leading,spacing:5) {
                Text(store.selectedDate.formatted(date:.abbreviated,time:.omitted)).font(.headline)
                Text(store.target(store.day.mode).calories>0 ? "参考余额 \(number(store.target(store.day.mode).calories-store.day.total.calories)) kcal · 蛋白质还差 \(number(max(0,store.target(store.day.mode).protein-store.day.total.protein))) g" : "尚未建立个人营养目标，已记录摄入仍会保留")
                    .font(.caption).foregroundStyle(.secondary)
                Text("建议不自动记账").font(.caption).foregroundStyle(.secondary)
            }.frame(maxWidth:.infinity,alignment:.leading).padding().background(Color.canvas)
            ScrollViewReader { proxy in ScrollView {
                VStack(alignment:.leading,spacing:14) {
                    if messages.isEmpty { Text("告诉我你手头有什么食物、饮食偏好和过敏信息，我会根据记录后的余额建议份量。").foregroundStyle(.secondary).padding() }
                    ForEach(messages) { message in
                        Text(message.content).textSelection(.enabled).padding().frame(maxWidth:.infinity,alignment:message.role=="user" ? .trailing : .leading).background(message.role=="user" ? Color.forest.opacity(0.1) : Color.canvas,in:RoundedRectangle(cornerRadius:16)).id(message.id)
                    }
                    if busy { ProgressView("正在准备建议…") }
                    if let error { Text(error).foregroundStyle(.red).font(.caption) }
                }.padding()
            }.onChange(of:messages.count) { _,_ in if let id=messages.last?.id { proxy.scrollTo(id,anchor:.bottom) } } }
            HStack(alignment:.bottom) {
                TextField("例如：剩500千卡，有米饭和鸡蛋",text:$draft,axis:.vertical).lineLimit(1...5)
                Button("发送") { if allowed { send() } else { consent=true } }.disabled(busy || draft.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || draft.count>2000)
            }.padding().background(.white)
        }.keyboardDone().navigationTitle("吃什么 · AI 助手").navigationBarTitleDisplayMode(.inline)
            .toolbar { NavigationLink { VisionSettingsView() } label: { Image(systemName:"gearshape") } }
            .alert("发送饮食资料与对话？",isPresented:$consent) { Button("取消",role:.cancel){};Button("同意并发送"){allowed=true;send()} } message:{Text(FoodService.consent)}
            .onChange(of:ai.revision){_,_ in if let job=ai.latest(draftKey),job.delivered,consumedJob != job.id{restore();consumedJob=job.id};error=ai.latest(draftKey)?.state=="failed" ? ai.latest(draftKey)?.error : nil}
            .onAppear { ai.attach(store);guard !initialized else{return};restore() }
            .onChange(of:DraftStorage.encoded(cached)){_,_ in persist()}
            .onChange(of:store.selectedDate) { _,_ in initialized=false;restore();error=nil;allowed=false }
            .onDisappear { persist() }
    }
    func send() {
        let text=draft.trimmingCharacters(in:.whitespacesAndNewlines);guard !busy,!text.isEmpty,text.count<=2000 else{return}
        messages.append(.init(role:"user",content:text));draft="";error=nil;persist()
        let sent=messages;let context=FoodContext.make(data:store.data,day:store.day);ai.attach(store)
        ai.start(key:draftKey,title:"饮食聊天 · "+store.selectedDate.formatted(date:.abbreviated,time:.omitted),kind:"chat",date:store.selectedDate){let answer=try await FoodService.chat(messages:sent,context:context);return try JSONSerialization.data(withJSONObject:["answer":answer])}
    }

}
struct CameraPhotoPicker: UIViewControllerRepresentable {
    var completed: (UIImage)->Void
    @Environment(\.dismiss) var dismiss
    func makeUIViewController(context:Context)->UIImagePickerController {
        let picker=UIImagePickerController();picker.sourceType = .camera;picker.delegate=context.coordinator;return picker
    }
    func updateUIViewController(_ uiViewController:UIImagePickerController,context:Context) {}
    func makeCoordinator()->Coordinator { Coordinator(self) }
    final class Coordinator:NSObject,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        let parent:CameraPhotoPicker
        init(_ parent:CameraPhotoPicker){self.parent=parent}
        func imagePickerControllerDidCancel(_ picker:UIImagePickerController){parent.dismiss()}
        func imagePickerController(_ picker:UIImagePickerController,didFinishPickingMediaWithInfo info:[UIImagePickerController.InfoKey:Any]) {if let image=info[.originalImage] as? UIImage {parent.completed(image)};parent.dismiss()}
    }
}

