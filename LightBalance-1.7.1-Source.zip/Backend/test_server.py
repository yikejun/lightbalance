import base64
import json
import unittest
from server import image_from_body, request_payload, parse_response, validate_result, InvalidResult

class MealGatewayChecks(unittest.TestCase):
    def result(self):
        return dict(is_food=True, name="鸡肉饭", items=["鸡肉约150 g"], calories=755, protein=48, fat=24, carbs=82, lower=650, upper=850, uncertainty="油量不确定")
    def test_completed_response(self):
        response = dict(status="completed", output=[dict(type="reasoning", summary=[]), dict(type="message", content=[dict(type="output_text", text=json.dumps(self.result()))])])
        self.assertEqual(parse_response(response)["calories"], 755)
    def test_incomplete_and_refusal(self):
        for response in [dict(status="incomplete", output=[]), dict(status="completed", output=[dict(type="message", content=[dict(type="refusal")])])]:
            with self.assertRaises(InvalidResult): parse_response(response)
    def test_estimate_interval_and_nonfinite(self):
        for field, value in [("lower", 800), ("upper", 700), ("fat", -1), ("protein", float("nan")), ("calories", True)]:
            result = self.result(); result[field] = value
            with self.assertRaises(InvalidResult): validate_result(result)
    def test_bad_input(self):
        for body in [{}, {"photo_base64":"invalid"}, {"photo_base64":base64.b64encode(b"png"*100).decode()}, {"photo_base64":"abc", "note":"x"*2001}]:
            with self.assertRaises(ValueError): image_from_body(body)
    def test_supported_request_and_no_other_records(self):
        photo = base64.b64encode(b"\xff\xd8\xff"+b"x"*100).decode()
        self.assertEqual(image_from_body(dict(photo_base64=photo, note="半碗米饭")), (photo, "半碗米饭"))
        payload = request_payload(photo, "半碗米饭", "account-model")
        self.assertFalse(payload["store"])
        self.assertTrue(payload["text"]["format"]["strict"])
        self.assertEqual(payload["input"][0]["content"][1]["type"], "input_image")
        self.assertNotIn("weight", json.dumps(payload))

if __name__ == "__main__": unittest.main()
