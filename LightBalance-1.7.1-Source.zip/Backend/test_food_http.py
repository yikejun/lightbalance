import base64,contextlib,http.client,io,json,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
from budget import RequestBudget
from server import Server,Handler
from test_food_ai import Tests
class FoodHTTP(unittest.TestCase):
 def test_authenticated_new_routes_use_owner_bridge_and_validate_before_inference(self):
  with tempfile.TemporaryDirectory() as d:
   server=Server(('127.0.0.1',0),Handler);server.auth_mode='chatgpt';server.api_key='test-bridge';server.app_token='z'*32;server.model='test-model';server.hourly_limit=6;server.daily_limit=6;server.budget=RequestBudget(Path(d)/'budget.db')
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   helper=Tests()
   def post(route,body,token=server.app_token):
    c=http.client.HTTPConnection(*server.server_address,timeout=3);c.request('POST',route,json.dumps(body),{'Authorization':'Bearer '+token});r=c.getresponse();result=(r.status,json.loads(r.read()));c.close();return result
   def response(request,**kwargs):
    self.assertEqual(request.full_url,'http://127.0.0.1:8788/responses');self.assertEqual(request.get_header('Authorization'),'Bearer test-bridge')
    p=json.loads(request.data);result={'answer':'可选晚餐'} if p['text']['format']['name']=='food_chat' else helper.result()
    return contextlib.closing(io.BytesIO(json.dumps({'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(result)}]}]}).encode()))
   try:
    with patch('server.urllib.request.urlopen',side_effect=response) as upstream:
     self.assertEqual(post('/meal-preview',helper.body(),'wrong')[0],401);upstream.assert_not_called()
     bad=helper.body();bad['images']=bad['images'][1:];self.assertEqual(post('/meal-preview',bad)[0],400);upstream.assert_not_called()
     self.assertEqual(post('/meal-preview',helper.body())[0],200)
     self.assertEqual(post('/chat',{'context':{},'messages':[{'role':'user','content':'吃什么'}]})[0],200);self.assertEqual(upstream.call_count,2)
   finally:server.shutdown();server.server_close();thread.join(timeout=3)
if __name__=='__main__':unittest.main()
