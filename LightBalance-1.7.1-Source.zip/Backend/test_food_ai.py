import unittest,base64,copy
from food_ai import preview_payload,chat_payload,validate_food_result
class Tests(unittest.TestCase):
 def body(self):
  jpeg=base64.b64encode(b'\xff\xd8\xff'+b'0'*100).decode()
  return {'context':{'mealReferenceCalories':500},'note':'标签对应牛奶','images':[{'role':'food','base64':jpeg},{'role':'label','base64':jpeg}]}
 def result(self):
  return {'name':'餐食','assessment':'over','explanation':'份量建议','uncertainty':'估计','items':[{'name':'饭','available':True,'availableGrams':200,'recommendedGrams':100,'per100g':{'calories':120,'protein':3,'fat':1,'carbs':25},'note':'熟重'}]}
 def test_food_and_label_distinguished_no_storage(self):
  p=preview_payload(self.body(),'test');self.assertFalse(p['store']);c=p['input'][0]['content'];self.assertIn('food',c[1]['text']);self.assertIn('label',c[3]['text'])
 def test_reject_label_only_and_oversized(self):
  b=self.body();b['images']=b['images'][1:];self.assertRaises(ValueError,preview_payload,b,'test')
  b=self.body();b['images']*=4;self.assertRaises(ValueError,preview_payload,b,'test')
 def test_bad_nutrition_and_impossible_portion(self):
  r=self.result();self.assertEqual(validate_food_result(r),r)
  r['items'][0]['recommendedGrams']=201;self.assertRaises(ValueError,validate_food_result,r)
  r=self.result();r['items'][0]['per100g']['calories']=float('nan');self.assertRaises(ValueError,validate_food_result,r)
 def test_chat_no_role_escalation(self):
  b={'context':{},'messages':[{'role':'system','content':'x'}]};self.assertRaises(ValueError,chat_payload,b,'test')
  b['messages'][0]['role']='user';p=chat_payload(b,'test');self.assertFalse(p['store']);self.assertEqual(validate_food_result({'answer':'建议'},True),{'answer':'建议'})
if __name__=='__main__':unittest.main()
