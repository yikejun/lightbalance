import Foundation
@main struct FoodChecks {
 @MainActor static func main() throws {
  let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
  defer {try? FileManager.default.removeItem(at:root)}
  let store=AppStore(storageURL:root.appendingPathComponent("records.json"));let date=store.selectedDate
  store.update {$0.meals=[Meal(kind:"午餐",name:"饭",nutrition:Nutrition(calories:600,protein:30,fat:15,carbs:80),photo:Data([1,2,3]))];$0.weight=59}
  let old=store.day.meals[0]
  store.settings(start:date,waist:76,budget:11000,weight:61,bodyFat:23,mealsPerDay:3)
  precondition(store.data.initialWeight==61 && store.data.initialBodyFat==23 && store.data.mealsPerDay==3 && store.day.weight==59 && store.day.meals[0].nutrition==old.nutrition)
  let context=FoodContext.make(data:store.data,day:store.day)
  let text=String(data:try JSONSerialization.data(withJSONObject:context),encoding:.utf8)!
  precondition(!text.contains("photo") && !text.contains("health") && !text.contains("bodyFat"))
  let edit=FoodContext.make(data:store.data,day:store.day,excluding:old.id)
  precondition((edit["confirmedMeals"] as? Int)==0)
  var flexible=store.day;flexible.mode = .flexible
  let unrestricted=FoodContext.make(data:store.data,day:flexible)
  precondition((unrestricted["target"] as? [String:Any])?["fat"] is NSNull)
  let n=Nutrition(calories:120,protein:5,fat:2,carbs:20)
  let item=FoodPortion(name:"米饭",available:true,availableGrams:200,recommendedGrams:100,per100g:n,note:"熟重")
  let preview=FoodPreview(name:"午餐",assessment:"over",explanation:"减少饭",items:[item],uncertainty:"油未知")
  _=try preview.validated();precondition(preview.availableTotal.calories==240 && item.nutrition(grams:50).calories==60 && item.nutrition(grams:0).calories==0)
  // Obtaining or editing an estimate must never write into the confirmed meal ledger.
  precondition(store.day.total.calories==600)
  var broken=preview;broken.items[0].per100g.calories = .nan
  do {_=try broken.validated();preconditionFailure("nonfinite accepted")}catch{}
  let health=HealthDay(date:date,values:["weight":.init(value:62,sources:["Scale"]),"bodyFat":.init(value:22,sources:["Scale"]),"steps":.init(value:5000,sources:["Phone"])])
  store.saveHealthCache(.init(refreshedAt:Date(),days:[health],workouts:[],sleepSources:[],issues:[]))
  precondition(store.day.bodyFat==nil)
  store.setHealthAutoFill(true)
  precondition(store.day.weight==59 && store.day.bodyFat==22 && store.day.steps==5000 && store.data.initialBodyFat==23 && store.day.workouts.isEmpty)
  var refreshed=health;refreshed.values["steps"] = .init(value:6500,sources:["Phone"])
  store.saveHealthCache(.init(refreshedAt:Date(),days:[refreshed],workouts:[],sleepSources:[],issues:[]))
  precondition(store.day.steps==6500 && store.day.weight==59)
  store.update {$0.steps=7100;$0.healthImportedFields=($0.healthImportedFields ?? []).filter{$0 != "steps"}}
  store.saveHealthCache(.init(refreshedAt:Date(),days:[refreshed],workouts:[],sleepSources:[],issues:[]))
  precondition(store.day.steps==7100)
  let restored=AppStore(storageURL:root.appendingPathComponent("records.json"))
  precondition(restored.data.initialWeight==61 && restored.day.meals[0].id==old.id)
  print("Passed: editable baselines without record loss, meal-count context, no photo/health disclosure in chat, proportional portions, estimate never logs intake, invalid estimates rejected, opt-in health fill preserves manual values and training")
 }
}
