import Foundation
// Tests construct requests and parse synthetic responses; no keys or network.
enum APIKeyStore { static func read() -> String { "" } }
@main struct APIChecks {
    static func main() throws {
        let dummy = "sk-" + String(repeating: "x", count: 40)
        let payload = try UserAPIRequest.meal(photo: Data([0xff,0xd8,0xff,0]), note: "小份", model: "gpt-4.1-mini")
        let req = try UserAPIRequest.request(payload: payload, key: dummy)
        assert(req.url?.absoluteString == "https://api.openai.com/v1/responses")
        assert(req.value(forHTTPHeaderField: "Authorization") == "Bearer " + dummy)
        assert(payload["store"] as? Bool == false)
        do { try UserAPIRequest.validate(key: "", model: "gpt-4.1-mini"); fatalError() } catch {}
        do { _ = try UserAPIRequest.meal(photo: Data([0]), note: "", model: "gpt-4.1-mini"); fatalError() } catch {}
        do { try UserAPIRequest.validate(key: dummy, model: "https://untrusted.example"); fatalError() } catch {}
        let nutrition: [String: Any] = ["is_food":true,"name":"测试餐食","items":[],"calories":500,"protein":30,"fat":15,"carbs":60,"lower":400,"upper":600,"uncertainty":"估算"]
        let text = String(data: try JSONSerialization.data(withJSONObject: nutrition), encoding: .utf8)!
        let envelope: [String: Any] = ["status":"completed","output":[["type":"message","content":[["type":"output_text","text":text]]]]]
        let parsed = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: envelope))
        let meal = try JSONDecoder().decode(MealEstimate.self, from: parsed).validated()
        assert(meal.calories == 500)
        var incomplete = envelope; incomplete["status"] = "incomplete"
        do { _ = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: incomplete)); fatalError() } catch {}
        let refusal: [String: Any] = ["status":"completed","output":[["type":"message","content":[["type":"refusal","refusal":"no"]]]]]
        do { _ = try UserAPIRequest.parse(JSONSerialization.data(withJSONObject: refusal)); fatalError() } catch {}
        assert(UserAPIRequest.errorMessage(429).contains("不会转用其他账户"))
        let custom=try UserAPIRequest.request(payload:payload,key:"vendor-token-123",base:"https://models.example/v1/",apiProtocol:"chat",outputMode:"json_object")
        assert(custom.url?.absoluteString=="https://models.example/v1/chat/completions")
        let customBody=try JSONSerialization.jsonObject(with:custom.httpBody!) as! [String:Any]
        let messages=customBody["messages"] as! [[String:Any]]
        assert((messages[0]["content"] as! String).contains("JSON"))
        let parts=messages[1]["content"] as! [[String:Any]]
        assert(parts[1]["type"] as! String == "image_url")
        let schemaBody=try UserAPIRequest.converted(payload,apiProtocol:"chat",outputMode:"json_schema")
        assert((schemaBody["response_format"] as! [String:Any])["type"] as! String == "json_schema")
        for url in ["http://models.example/v1","https://key@models.example/v1","https://models.example/v1?key=secret"] {assert((try? UserAPIRequest.endpoint(base:url,apiProtocol:"chat"))==nil)}
        let chat:[String:Any]=["choices":[["finish_reason":"stop","message":["content":text]]]]
        let chatParsed=try UserAPIRequest.parse(JSONSerialization.data(withJSONObject:chat),apiProtocol:"chat")
        let chatMeal=try JSONDecoder().decode(MealEstimate.self,from:chatParsed);assert(chatMeal.calories==500)
        var truncated=chat;truncated["choices"]=[["finish_reason":"length","message":["content":text]]]
        assert((try? UserAPIRequest.parse(JSONSerialization.data(withJSONObject:truncated),apiProtocol:"chat"))==nil)
        print("Passed: fixed official endpoint, credential validation, JPEG bounds, no storage, structured parsing, refusal and quota handling")
    }
}
