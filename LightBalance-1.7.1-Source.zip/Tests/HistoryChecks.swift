import Foundation
@main struct HistoryChecks {
 @MainActor static func main() throws {
  let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
  try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
  defer{try? FileManager.default.removeItem(at:root)}
  let url=root.appendingPathComponent("records.json")
  let profile=PersonalProfile(fields:["age":"30","height":"175","weight":"75","goal":"减脂保肌","restriction":"无","pregnancy":"否"])
  func proposal(_ title:String,_ calories:Double)->PersonalProposal {
   PersonalProposal(status:"ready",explanation:"指南支持",questions:[],sourceIDs:["WHO2020","ACSM2026","NIDDK"],plans:[TrainingPlan(name:title,exercises:[.init(name:"自重深蹲")])],targets:Dictionary(uniqueKeysWithValues:DayMode.allCases.map{($0.rawValue,Nutrition(calories:calories,protein:120,fat:60,carbs:245))}),weeklyBudget:calories*7,schedule:Array(repeating:title,count:7),assumptions:"估计",createdAt:Date())
  }
  var legacy=AppData();legacy.personalProfile=profile;legacy.personalProposal=proposal("旧计划",2000)
  try JSONEncoder().encode(legacy).write(to:url)
  let store=AppStore(storageURL:url)
  precondition(store.data.personalPlanHistory?.count==1)
  let originalID=store.data.personalPlanHistory![0].id
  precondition(AppStore(storageURL:url).data.personalPlanHistory![0].id==originalID)
  store.update{$0.weight=74;$0.meals=[Meal(kind:"午餐",name:"饭",nutrition:Nutrition(calories:600,protein:30,fat:20,carbs:75))];$0.workouts=[Workout(kind:"力量",minutes:40)]}
  let records=DraftStorage.encoded(store.data.records)
  var a=proposal("计划 A",2000);a.baseHash=PersonalPlanFingerprint.hash(store.data)
  store.savePersonalProposal(a);let aID=store.data.personalPlanHistory!.last!.id
  precondition(store.applyPersonalProposal(a,currentHash:PersonalPlanFingerprint.hash(store.data)))
  let aVersion=store.data.activePlanVersionID!
  var b=proposal("计划 B",2200);b.baseHash=PersonalPlanFingerprint.hash(store.data)
  store.savePersonalProposal(b);let bID=store.data.personalPlanHistory!.last!.id
  precondition(store.data.personalPlanHistory?.count==3)
  precondition(store.switchPersonalPlan(bID) && store.data.weeklyBudget==15400)
  precondition(store.switchPersonalPlan(aID) && store.data.weeklyBudget==14000 && store.data.trainingPlans![0].name=="计划 A")
  precondition(store.data.activePlanVersionID==aVersion)
  precondition(store.switchPersonalPlan(bID));precondition(store.switchPlanVersion(aVersion))
  precondition(store.data.personalSchedule?.first=="计划 A" && store.data.nutritionTargets?[DayMode.high.rawValue]?.calories==2000)
  precondition(DraftStorage.encoded(store.data.records)==records)
  var stale=b;stale.baseHash="old-input-hash"
  precondition(!store.applyPersonalProposal(stale,currentHash:PersonalPlanFingerprint.hash(store.data)))
  let payload=WeeklyReportPayload(summary:"阶段总结",observations:["训练记录"],dataGaps:["睡眠不足"],question:"是否调整？",recommendation:"adjust",rationale:"依据指南",sourceIDs:[CoachEvidenceLibrary.sources[0].id],proposedPlans:[TrainingPlan(name:"周报方案",exercises:[.init(name:"自重深蹲",sets:2,reps:10)])])
  let reports=(1...15).map{i in WeeklyReport(week:"2026-W40",state:"kept",payload:payload,plansHash:"old",snapshotAt:String(format:"2026-10-04T00:00:%02dZ",i))}
  store.cacheWeeklyReports(reports);store.cacheWeeklyReports([reports[0]])
  precondition(store.data.weeklyAPIReports?.count==15 && Set(store.data.weeklyAPIReports!.map(\.id)).count==15)
  let budget=store.data.weeklyBudget;let targets=DraftStorage.encoded(store.data.nutritionTargets)
  precondition(store.switchWeeklyReport(reports[0].id))
  precondition(store.data.trainingPlans![0].name=="周报方案" && store.data.weeklyBudget==budget && DraftStorage.encoded(store.data.nutritionTargets)==targets && store.data.personalSchedule==nil)
  let weeklyVersion=store.data.activePlanVersionID!
  precondition(store.switchPlanVersion(aVersion) && store.data.personalSchedule?.first=="计划 A")
  precondition(store.switchPlanVersion(weeklyVersion) && store.data.personalSchedule==nil)
  precondition(DraftStorage.encoded(store.data.records)==records)
  var invalid=reports[0];invalid.snapshotAt="invalid";invalid.payload?.sourceIDs=["invented"]
  store.saveWeeklyAPIReport(invalid);precondition(!store.switchWeeklyReport(invalid.id))
  var unsafe=profile;unsafe.fields["restriction"]="有";store.savePersonalProfile(unsafe)
  precondition(!store.switchPersonalPlan(aID) && !store.switchPlanVersion(aVersion) && !store.switchWeeklyReport(reports[0].id))
  var sameTime1=reports[0];sameTime1.localGenerationID=UUID().uuidString
  var sameTime2=reports[0];sameTime2.localGenerationID=UUID().uuidString
  store.cacheWeeklyReports([sameTime1,sameTime2]);precondition(store.data.weeklyAPIReports?.count==18)
  let reopened=AppStore(storageURL:url)
  precondition(reopened.data.personalPlanHistory?.count==3 && reopened.data.weeklyAPIReports?.count==18 && reopened.data.activePlanVersionID==weeklyVersion)
  precondition(DraftStorage.encoded(reopened.data.records)==records)
  print("Passed: legacy history migration, all generated candidates retained, personal/version switching, weekly same-week history beyond 12, persisted offline history, nutrition separation, actual records preservation, stale and unsafe rejection")
 }
}
