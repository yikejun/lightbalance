import Foundation

@main struct AccountChecks {
    static func main() async throws {
        assert(!VisionService.isAvailable)
        // Even a previous personal installation's settings cannot authorize the
        // multi-user build. Failure occurs locally before any photo is sent.
        do {
            _ = try await VisionService.analyze(photo: Data([1, 2, 3]), note: "test")
            fatalError("Unconfigured user authorization must fail closed")
        } catch {
            assert(error.localizedDescription == VisionService.unavailableReason)
        }
        print("Passed: multi-user recognition fails locally without personal authorization")
    }
}
