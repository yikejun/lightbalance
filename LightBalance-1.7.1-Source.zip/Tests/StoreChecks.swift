import Foundation

@main struct StoreChecks {
    @MainActor static func main() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("LightBalanceTests-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let url = root.appendingPathComponent("records.json")
        let store = AppStore(storageURL: url)
        let meal = Meal(kind: "午餐", name: "测试", nutrition: Nutrition(calories: 755, protein: 48, fat: 24, carbs: 82))
        store.update { $0.meals.append(meal); $0.mode = .high; $0.weight = 58 }
        assert(store.storageError == nil)
        store.update { $0.mode = .low }
        let loaded = AppStore(storageURL: url)
        assert(loaded.day.mode == .low)
        assert(loaded.day.meals[0].id == meal.id && loaded.day.total.calories == 755)
        loaded.selectedDate = Calendar.current.date(byAdding: .day, value: -1, to: loaded.selectedDate)!
        assert(loaded.day.weight == nil && loaded.day.meals.isEmpty)
        let corruptURL = root.appendingPathComponent("corrupt.json")
        let original = Data("invalid-json-preserved".utf8)
        try original.write(to: corruptURL)
        let corrupt = AppStore(storageURL: corruptURL)
        assert(corrupt.storageError != nil)
        corrupt.update { $0.weight = 55 }
        let preserved = try Data(contentsOf: corruptURL)
        assert(preserved == original)
        let guest = AppStore(storageRoot: root)
        let accountA = UUID(), accountB = UUID()
        let first = AppStore(accountID: accountA, storageRoot: root)
        let second = AppStore(accountID: accountB, storageRoot: root)
        assert(first.day.meals.isEmpty && second.day.meals.isEmpty)
        assert(guest.day.meals.first?.id == meal.id)
        first.update { $0.weight = 61; $0.meals.append(meal) }
        second.update { $0.weight = 72 }
        assert(AppStore(accountID: accountA, storageRoot: root).day.weight == 61)
        assert(AppStore(accountID: accountB, storageRoot: root).day.weight == 72)
        assert(AppStore(accountID: accountB, storageRoot: root).day.meals.isEmpty)
        assert(AppStore(storageRoot: root).day.weight == 58)
        assert(AccountStorage.recordsURL(root: root, accountID: accountA) != AccountStorage.recordsURL(root: root, accountID: accountB))
        let exportA = try first.export(), exportB = try second.export()
        defer {
            try? FileManager.default.removeItem(at: exportA.deletingLastPathComponent())
            try? FileManager.default.removeItem(at: exportB.deletingLastPathComponent())
        }
        assert(exportA != exportB)
        let exportedA = try JSONSerialization.jsonObject(with: Data(contentsOf: exportA)) as! [String: Any]
        let exportedB = try JSONSerialization.jsonObject(with: Data(contentsOf: exportB)) as! [String: Any]
        assert((exportedA["records"] as! [[String: Any]])[0]["weight"] as? Double == 61)
        assert((exportedB["records"] as! [[String: Any]])[0]["weight"] as? Double == 72)
        print("Passed: disk persistence, relaunch restore, date isolation, corrupt-file preservation")
        print("Passed: account file isolation, guest preservation, no automatic migration, distinct exports")
    }
}
