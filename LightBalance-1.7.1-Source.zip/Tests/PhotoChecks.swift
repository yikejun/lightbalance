import UIKit
@main struct PhotoChecks {
 static func main() {
  let width=6000,height=4000
  var pixels=[UInt8](repeating:0,count:width*height*4)
  var noise:UInt32=12345
  for i in stride(from:0,to:pixels.count,by:4){noise=noise &* 1664525 &+ 1013904223;pixels[i]=UInt8(truncatingIfNeeded:noise);pixels[i+1]=UInt8(truncatingIfNeeded:noise>>8);pixels[i+2]=UInt8(truncatingIfNeeded:noise>>16);pixels[i+3]=255}
  let provider=CGDataProvider(data:Data(pixels) as CFData)!
  let cg=CGImage(width:width,height:height,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:width*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue),provider:provider,decode:nil,shouldInterpolate:true,intent:.defaultIntent)!
  let source=UIImage(cgImage:cg,scale:1,orientation:.right)
  let jpeg=FoodImageEncoder.jpeg(source)!
  let restored=UIImage(data:jpeg)!
  precondition(jpeg.count<=450000 && restored.size.width>240 && restored.size.height>240)
  let smaller=FoodImageEncoder.jpeg(source,maxBytes:90000)!
  precondition(smaller.count<=90000)
  print("Passed: 24-megapixel noisy camera image with rotation, adaptive JPEG/dimension compression; \(jpeg.count) / \(smaller.count) bytes")
 }
}
