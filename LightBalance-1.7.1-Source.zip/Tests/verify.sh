#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
work=$(mktemp -d /private/tmp/lightbalance-checks.XXXXXX)
trap 'rm -rf "$work"' EXIT
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift Tests/PlanChecks.swift -o "$work/plan"
"$work/plan"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/Store.swift Tests/StoreChecks.swift -o "$work/store"
"$work/store"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift Tests/TrainingChecks.swift -o "$work/training"
"$work/training"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/Store.swift Tests/CoachChecks.swift -o "$work/coach"
"$work/coach"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/Store.swift Tests/HealthChecks.swift -o "$work/health"
"$work/health"
swiftc -D LIGHTBALANCE_USER_API -module-cache-path "$work/cache" LightBalance/VisionModels.swift LightBalance/UserAPI.swift Tests/APIChecks.swift -o "$work/api"
"$work/api"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/VisionModels.swift LightBalance/FoodModels.swift LightBalance/Store.swift Tests/FoodChecks.swift -o "$work/food"
"$work/food"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/VisionModels.swift LightBalance/FoodModels.swift LightBalance/Store.swift Tests/PersonalChecks.swift -o "$work/personal"
"$work/personal"
swiftc -module-cache-path "$work/cache" LightBalance/Models.swift LightBalance/TrainingModels.swift LightBalance/CoachModels.swift LightBalance/CoachEvidence.swift LightBalance/HealthModels.swift LightBalance/WeeklyModels.swift LightBalance/Store.swift Tests/HistoryChecks.swift -o "$work/history"
"$work/history"
