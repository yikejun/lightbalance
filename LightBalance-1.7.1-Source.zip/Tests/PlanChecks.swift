import Foundation

@main struct PlanChecks {
    static func main() throws {
        let calendar = Calendar.current
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 3))!
        let day7 = calendar.date(byAdding: .day, value: 6, to: start)!
        let day8 = calendar.date(byAdding: .day, value: 7, to: start)!
        assert(Plan.cycleDay(start, start: start) == 1)
        assert(Plan.weekDates(containing: day7, start: start).first == start)
        assert(Plan.weekDates(containing: day8, start: start).first == day8)
        assert(Plan.mean([]) == nil, "Missing weight data must never become zero")
        assert(Plan.mean([58, 57.8, 58.1])!.rounded() == 58)
        let lunch = Meal(kind: "午餐", name: "已吃的午餐", nutrition: Nutrition(calories: 755, protein: 48, fat: 24, carbs: 82), lower: 650, upper: 800)
        var day = DayRecord(date: start, mode: .high, meals: [lunch])
        assert(Plan.remaining(day.mode.target.calories, eaten: day.total.calories) == 945)
        day.mode = .low
        assert(day.meals[0].id == lunch.id && day.total == lunch.nutrition, "Cancelling training must preserve lunch")
        assert(Plan.remaining(day.mode.target.calories, eaten: day.total.calories) == 745)
        assert(Plan.remaining(1500, eaten: 1900) == 0, "Over-budget days must not suggest negative food intake")
        day.mode = .flexible
        assert(day.mode.target.protein >= 100)
        let restored = try JSONDecoder().decode(DayRecord.self, from: JSONEncoder().encode(day))
        assert(restored.mode == .flexible && restored.meals[0].id == lunch.id)
        assert(restored.total == lunch.nutrition)
        print("Passed: cycle boundaries, missing data, dynamic targets, meal preservation, overspend handling, JSON round trip")
    }
}
