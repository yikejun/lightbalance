import Foundation
@main struct CoachChecks {
 static func sample(at today: Date) -> AppData {
  let cal = Calendar.current
  let plan = TrainingPlan(name: "全身", exercises: [.init(name: "杠铃背蹲", sets: 3, reps: 8)])
  var data = AppData()
  data.trainingPlans = [plan]
  data.coachProfile = .init(goal: "减脂保肌", healthyAdult: true, medicalRestriction: false, equipment: ["杠铃"], availableMinutes: 45)
  for offset in [-20, -8, -1] {
   let sets = (0..<3).map { _ in ExerciseSet(exercise: "杠铃背蹲", weight: 30, reps: 8, rir: 2, warmup: false, loadMode: "外部负重") }
   data.records.append(.init(date: cal.date(byAdding: .day, value: offset, to: today)!, mode: .high, workouts: [.init(kind: "力量", minutes: 40, sets: sets)]))
  }
  for offset in [-3,-2,0] {
   data.records.append(.init(date: cal.date(byAdding: .day, value: offset, to: today)!, mode: .low, recovery: .init(sleepHours: 7, fatigue: 2, pain: false, persistentPain: false)))
  }
  return data
 }
 @MainActor static func main() throws {
  let today = Calendar.current.startOfDay(for: Date())
  let baseline = sample(at: today)
  var data = baseline
  let eligible = CoachPolicy.evaluate(data: data, at: today)
  assert(eligible.status == "eligible" && eligible.changes.count == 1)
  assert(eligible.changes[0].after == 9 && eligible.sourceIDs.contains("acsm-progress"))
  data.records[5].recovery?.pain = true
  assert(CoachPolicy.evaluate(data: data, at: today).status == "professional_review")
  data = sample(at: today); data.coachProfile?.healthyAdult = nil
  assert(CoachPolicy.evaluate(data: data, at: today).status == "needs_info")
  data = sample(at: today); data.coachProfile?.goal = nil
  assert(CoachPolicy.evaluate(data: data, at: today).status == "needs_info")
  data = sample(at: today); data.records[2].workouts[0].sets[0].rir = nil
  assert(CoachPolicy.evaluate(data: data, at: today).changes.isEmpty)
  data = sample(at: today); data.records[2].workouts[0].sets[0].weight = 35
  assert(CoachPolicy.evaluate(data: data, at: today).changes.isEmpty)
  data = sample(at: today); data.records[1].workouts[0].sets[0].reps = 12
  assert(CoachPolicy.evaluate(data: data, at: today).changes.isEmpty)
  data = sample(at: today); data.records[2].workouts[0].sets = [.init(exercise: "杠铃背蹲", weight: 30, reps: 20, rir: 4, warmup: true, loadMode: "外部负重")]
  assert(CoachPolicy.evaluate(data: data, at: today).changes.isEmpty)
  // Legacy optional keys remain readable. Existing meals/workouts are preserved.
  let raw = try JSONEncoder().encode(baseline)
  var legacy = try JSONSerialization.jsonObject(with: raw) as! [String: Any]
  legacy.removeValue(forKey: "coachProfile"); legacy.removeValue(forKey: "coachDecisions")
  var records = legacy["records"] as! [[String: Any]]
  for i in records.indices { records[i].removeValue(forKey: "recovery") }; legacy["records"] = records
  let decoded = try JSONDecoder().decode(AppData.self, from: JSONSerialization.data(withJSONObject: legacy))
  assert(decoded.coachProfile == nil && decoded.records.allSatisfy { $0.recovery == nil })
  assert(decoded.records[0].workouts[0].sets.count == 3)
  let path = FileManager.default.temporaryDirectory.appendingPathComponent("coach-check-" + UUID().uuidString + ".json")
  defer { try? FileManager.default.removeItem(at: path) }
  try raw.write(to: path)
  let store = AppStore(storageURL: path); let change = eligible.changes[0]
  assert(!store.acceptCoachChange(change, at: Calendar.current.date(byAdding: .day, value: -1, to: today)!))
  assert(store.acceptCoachChange(change, at: today))
  assert(!store.acceptCoachChange(change, at: today))
  let loaded = AppStore(storageURL: path)
  assert(loaded.data.trainingPlans![0].exercises[0].reps == 9 && loaded.data.coachDecisions?.count == 1)
  assert(loaded.data.records[2].workouts[0].sets[0].reps == 8)
  assert(CoachPolicy.evaluate(data: loaded.data, at: today).status == "hold")
  // New pain after a candidate was displayed prevents acceptance.
  try raw.write(to: path, options: .atomic)
  let stale = AppStore(storageURL: path);stale.selectedDate = today
  stale.update { $0.recovery = .init(sleepHours: 7, fatigue: 2, pain: true, persistentPain: false) }
  assert(!stale.acceptCoachChange(change, at: today))
  stale.saveProfessionalReview(reviewer: "测试审核人", qualification: "用户填写的资质", conclusion: "确认基础计划", note: "仅验证保存")
  let audited = AppStore(storageURL: path)
  assert(audited.data.professionalReviews?.count == 1)
  assert(CoachPolicy.evaluate(data: audited.data, at: today).status == "professional_review")
  assert(audited.data.professionalReviews![0].plans[0].exercises[0].reps == 8)
  let summary = CoachPolicy.professionalSummary(data: baseline, at: today)
  assert(summary.contains("30.0 kg") && summary.contains("余力 2") && !summary.contains("餐食自由备注"))
  print("Passed: evidence policy, missing data, pain gating, comparable load/RIR, warmup exclusion, legacy decoding, confirmed update, persistence, cooldown and stale-candidate rejection")
 }
}
