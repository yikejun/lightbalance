import UIKit

enum FoodImageEncoder {
    static func jpeg(_ image: UIImage, maxBytes: Int = 450000) -> Data? {
        guard image.size.width > 0, image.size.height > 0 else{return nil}
        var side: CGFloat = min(1800,max(image.size.width,image.size.height))
        // Re-render at actual pixels, removing orientation/metadata. Reduce dimensions too,
        // so even detailed labels converge instead of randomly failing at a quality floor.
        while side >= 240 {
            let ratio=side/max(image.size.width,image.size.height)
            let size=CGSize(width:max(1,(image.size.width*ratio).rounded()),height:max(1,(image.size.height*ratio).rounded()))
            let format=UIGraphicsImageRendererFormat();format.scale=1;format.opaque=true
            let rendered=UIGraphicsImageRenderer(size:size,format:format).image{context in UIColor.white.setFill();context.fill(CGRect(origin:.zero,size:size));image.draw(in:CGRect(origin:.zero,size:size))}
            for quality in [0.85,0.7,0.55,0.4,0.25] { if let data=rendered.jpegData(compressionQuality:quality),data.count<=maxBytes{return data} }
            side *= 0.75
        }
        return nil
    }
}
