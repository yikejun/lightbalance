import Foundation

struct RecoveryRecord: Codable {
 var sleepHours: Double?
 var fatigue: Int?
 var pain: Bool?
 var persistentPain: Bool?
}
struct CoachProfile: Codable {
 var goal: String? = nil
 var healthyAdult: Bool?
 var medicalRestriction: Bool?
 var equipment: [String] = []
 var availableMinutes: Int?
}
struct CoachChange: Codable, Identifiable, Equatable {
 var planID: UUID
 var exerciseID: UUID
 var exercise: String
 var before: Int
 var after: Int
 var id: String { planID.uuidString + exerciseID.uuidString }
}
struct CoachDecision: Codable, Identifiable {
 var id = UUID()
 var date: Date
 var change: CoachChange
 var policyVersion: String
 var evidenceVersion: String
 var sourceIDs: [String]
 var facts: [String]? = nil
 var sourceSnapshot: [CoachEvidence]? = nil
}
struct ProfessionalReviewRecord: Codable, Identifiable {
 var id = UUID()
 var date: Date
 var reviewer: String
 var qualification: String
 var conclusion: String
 var note: String
 var plans: [TrainingPlan]
}
struct CoachReview {
 var status: String
 var title: String
 var facts: [String]
 var questions: [String]
 var changes: [CoachChange]
 var sourceIDs: [String]
}
enum CoachPolicy {
 static let version = "conservative-reps-v1"
 static let interpretation = "渐进训练有指南支持。观察 14 天、恢复记录 3 天、睡眠 6 小时、疲劳≤3、余力≥2以及每次只增加 1 次，是本 App 的保守规则，并非指南直接规定的医学阈值。"
 static let followUp = "确认后至少观察两周。若出现疼痛、疲劳加重或动作质量下降，先停止增加目标并重新评估；不同时增加重量和组数。"
 static func evaluate(data: AppData, at date: Date) -> CoachReview {
  let cal = Calendar.current
  let end = cal.startOfDay(for: date)
  let start = cal.date(byAdding: .day, value: -13, to: end)!
  let weekStart = cal.date(byAdding: .day, value: -6, to: end)!
  let past = data.records.filter { $0.date <= end }.sorted { $0.date < $1.date }
  let recent = past.filter { $0.date >= start }
  let recovery = recent.filter { $0.date >= weekStart }.compactMap(\.recovery)
  let profile = data.coachProfile ?? CoachProfile()
  if recovery.contains(where: { $0.pain == true || $0.persistentPain == true }) || profile.medicalRestriction == true || profile.healthyAdult == false {
   return .init(status: "professional_review", title: "先进行专业评估", facts: ["记录了疼痛、健康限制或指南适用范围不符"], questions: ["请将训练与恢复记录交给合适的专业人员评估。此版本不提供伤病康复或特殊人群方案。"], changes: [], sourceIDs: ["niddk-scope", "acsm-personalize"])
  }
  var gaps: [String] = []
  let earliest = past.first { $0.workouts.contains(where: \.isStrength) }?.date
  let days = earliest.map { (cal.dateComponents([.day], from: $0, to: end).day ?? 0) + 1 } ?? 0
  if days < 14 { gaps.append("建立至少 14 天的训练观察记录") }
  let complete = recovery.filter { $0.sleepHours != nil && $0.fatigue != nil }
  if complete.count < 3 { gaps.append("补充最近 7 天中至少 3 天的睡眠与疲劳记录") }
  if recovery.isEmpty || recovery.contains(where: { $0.pain == nil || $0.persistentPain == nil }) { gaps.append("填写恢复记录中的疼痛与持续情况") }
  if profile.goal == nil { gaps.append("填写训练目标") }
  if profile.healthyAdult == nil || profile.medicalRestriction == nil { gaps.append("确认是否为健康成年人及是否有健康限制") }
  if profile.equipment.isEmpty || profile.availableMinutes == nil { gaps.append("填写可用器械和每次训练时间") }
  let plans = data.trainingPlans ?? []
  if plans.isEmpty { gaps.append("先保存你的实际训练计划，才能比较调整前后") }
  if !gaps.isEmpty { return .init(status: "needs_info", title: "先补充信息，保持计划", facts: ["可观察 \(days) 天 · 完整恢复记录 \(complete.count) 天"], questions: gaps, changes: [], sourceIDs: ["acsm-personalize"]) }
  if let latest = data.coachDecisions?.map(\.date).max(), (cal.dateComponents([.day], from: latest, to: end).day ?? 0) < 14 {
   return .init(status: "hold", title: "观察上一项调整", facts: ["上次调整尚未观察满两周"], questions: [], changes: [], sourceIDs: ["acsm-personalize"])
  }
  let sleep = Plan.mean(complete.compactMap(\.sleepHours)) ?? 0
  let fatigue = Plan.mean(complete.compactMap { $0.fatigue.map(Double.init) }) ?? 5
  if sleep < 6 || fatigue > 3 {
   return .init(status: "hold", title: "先关注恢复，保持目标", facts: ["睡眠均值 \(sleep.formatted(.number.precision(.fractionLength(1)))) 小时；疲劳均值 \(fatigue.formatted(.number.precision(.fractionLength(1)))) / 5"], questions: ["这周的恢复状态是否与工作、睡眠或训练安排有关？"], changes: [], sourceIDs: ["acsm-personalize"])
  }
  for plan in plans {
   for item in plan.exercises where (5...19).contains(item.reps) {
    guard let definition = ExerciseLibrary.find(item.name), !definition.timed, !definition.advanced, profile.equipment.contains(definition.equipment) else { continue }
    let sessions = recent.compactMap { day -> [ExerciseSet]? in
     let sets = day.workouts.filter(\.isStrength).flatMap(\.sets).filter { $0.working && $0.exercise == item.name && $0.seconds == nil }
     return sets.isEmpty ? nil : sets
    }
    guard sessions.count >= 2 else { continue }
    let last = Array(sessions.suffix(2))
    guard let load = last[0].first?.weight, let mode = last[0].first?.loadMode, ["外部负重", "单侧负重"].contains(mode), load > 0,
     last.allSatisfy({ sets in sets.count >= item.sets && sets.allSatisfy { $0.weight == load && $0.loadMode == mode && $0.reps >= item.reps && ($0.rir ?? -1) >= 2 } }),
     (last[1].map(\.reps).max() ?? 0) >= (last[0].map(\.reps).max() ?? 0) else { continue }
    return .init(status: "eligible", title: "有一项小幅调整可讨论", facts: ["\(item.name)：最近两次不同日期，同重量、同负重方式完成目标组数与次数，记录余力至少 2 次", "观察 \(days) 天；恢复记录 \(complete.count) 天"], questions: ["你是否愿意保持重量与组数，只把这一个动作的每组目标增加 1 次？"], changes: [.init(planID: plan.id, exerciseID: item.id, exercise: item.name, before: item.reps, after: item.reps + 1)], sourceIDs: ["acsm-progress", "acsm-personalize", "acsm-failure"])
   }
  }
  return .init(status: "hold", title: "保持计划，继续观察", facts: ["尚未找到连续两次达到目标且保有余力的可比动作"], questions: ["逐组记录重量、次数、余力，热身组单独标记。"], changes: [], sourceIDs: ["acsm-personalize"])
 }
 static func professionalSummary(data: AppData, at date: Date) -> String {
  let r = evaluate(data: data, at: date)
  let beginning = Calendar.current.date(byAdding: .day, value: -13, to: date)!
  let records = data.records.filter { $0.date >= beginning && $0.date <= date }.sorted { $0.date < $1.date }
  var lines = ["轻衡 · 供专业人员查看的训练摘要", "截至：" + date.formatted(date: .abbreviated, time: .omitted), "程序评估：" + r.title, "这不是专业诊断或已审核处方。", "证据版本：" + CoachEvidenceLibrary.version]
  lines += r.facts + r.questions
  lines.append("当前保存计划：")
  for plan in data.trainingPlans ?? [] {
   lines.append(plan.name)
   for e in plan.exercises { lines.append("  \(e.name)：\(e.sets) 组 × \(e.reps) \(ExerciseLibrary.find(e.name)?.timed == true ? "秒" : "次")") }
  }
  lines.append("最近 14 天实际训练与恢复：")
  for day in records {
   lines.append(day.date.formatted(date: .abbreviated, time: .omitted))
   if let recovery = day.recovery {
    lines.append("睡眠 \(recovery.sleepHours.map { String($0) } ?? "未知") 小时；疲劳 \(recovery.fatigue.map(String.init) ?? "未知") / 5；疼痛 \(recovery.pain.map { $0 ? "有" : "无" } ?? "未知")；持续/反复 \(recovery.persistentPain.map { $0 ? "是" : "否" } ?? "未知")")
   }
   for workout in day.workouts {
    lines.append("\(workout.kind)：\(workout.minutes) 分钟")
    for set in workout.sets where set.working { lines.append("\(set.exercise)：\(set.weight) kg，\(set.reps) 次，余力 \(set.rir.map(String.init) ?? "未知")，\(set.loadMode ?? "未记录负重方式")") }
   }
  }
  lines.append("不含餐食照片与自由备注；资料来源：")
  lines += CoachEvidenceLibrary.sources.map { $0.title + " " + $0.url }
  return lines.joined(separator: "\n")
 }

}
