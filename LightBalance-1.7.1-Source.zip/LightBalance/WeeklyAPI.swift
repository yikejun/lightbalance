import Foundation

#if LIGHTBALANCE_USER_API
enum WeeklyAPI {
    static func generate(_ data: AppData) async throws -> WeeklyReport {
        guard data.weeklyCoachEnabled == true else { throw VisionError.message("请先同意启用 API 周报。") }
        let snapshot = try JSONSerialization.jsonObject(with: WeeklySnapshot.body(data))
        func object(_ string: String) throws -> Any { try JSONSerialization.jsonObject(with: Data(string.utf8)) }
        let context: [String: Any] = ["snapshot": snapshot, "evidence": try object(WeeklyAPIResources.evidence), "catalog": try object(WeeklyAPIResources.catalog)]
        let text = String(data: try JSONSerialization.data(withJSONObject: context), encoding: .utf8)!
        let request: [String: Any] = ["model": UserDefaults.standard.string(forKey: "userAPIModel") ?? "gpt-4.1-mini", "store": false, "max_output_tokens": 6000,
            "instructions": WeeklyAPIResources.prompt, "input": [["role":"user","content":text]],
            "text": ["format":["type":"json_schema","name":"weekly_training_review_v2","strict":true,"schema":try object(WeeklyAPIResources.schema)]]]
        let payload = try JSONDecoder().decode(WeeklyReportPayload.self, from: await UserAPIClient.complete(payload: request))
        var calendar = Calendar(identifier: .iso8601); calendar.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        let date = Date(); let year = calendar.component(.yearForWeekOfYear, from: date); let week = calendar.component(.weekOfYear, from: date)
        let report = WeeklyReport(week: String(format: "%d-W%02d",year,week), state: "awaiting_choice", payload: payload,
            plansHash: try WeeklySnapshot.plansHash(data.trainingPlans ?? []), snapshotAt: ISO8601DateFormatter().string(from: date), localGenerationID: UUID().uuidString)
        let ids = Set(CoachEvidenceLibrary.sources.map(\.id))
        guard !payload.summary.isEmpty, !payload.rationale.isEmpty, Set(payload.sourceIDs).isSubset(of: ids),
              ["keep","adjust","insufficient_data"].contains(payload.recommendation),
              payload.recommendation == "adjust" ? WeeklySnapshot.applicable(report, to: data) : payload.proposedPlans.isEmpty else { throw VisionError.message("总结或引用不符合要求，未保存或调整计划。") }
        return report
    }
}
#endif
