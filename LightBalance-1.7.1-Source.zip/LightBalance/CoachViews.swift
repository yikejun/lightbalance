import SwiftUI

struct CoachReviewView: View {
 @EnvironmentObject var store: AppStore
 @State private var pending: CoachChange?
 @State private var message: String?
 var review: CoachReview { CoachPolicy.evaluate(data: store.data, at: store.selectedDate) }
 var body: some View {
  List {
   Section("本机规则评估") {
    Text(review.title).font(.headline)
    Text("先依据记录和已核实资料做检查，再讨论调整。这里显示的是程序规则评估，不是医生或教练审核结果。").font(.caption).foregroundStyle(.secondary)
    NavigationLink("个人计划与训练条件") { CoachProfileView() }
    ForEach(review.facts, id: \.self) { Text($0) }
   }
   if !review.questions.isEmpty {
    Section(review.status == "needs_info" ? "需要补充的信息" : "下一步") { ForEach(review.questions, id: \.self) { Text($0) } }
   }
   ForEach(review.changes) { change in
    Section("调整内容 · 需你确认") {
     Text(change.exercise).font(.headline)
     Text("每组目标 \(change.before) → \(change.after) 次；重量和组数保持")
     Text("依据：最近两次可比训练完成目标并保有余力。增加 1 次是个人情况推断，不是指南直接规定。").font(.subheadline)
     Button("预览并确认这项调整") { pending = change }.disabled(!Calendar.current.isDateInToday(store.selectedDate))
     if !Calendar.current.isDateInToday(store.selectedDate) { Text("历史日期可查看，切回今天才能确认。").font(.caption) }
    }
   }
   Section("证据与推断") {
    Text(CoachPolicy.interpretation).font(.subheadline)
    ForEach(CoachEvidenceLibrary.sources.filter { review.sourceIDs.contains($0.id) }) { source in NavigationLink(source.title) { CoachEvidenceDetail(source: source) } }
    NavigationLink("查看全部核实资料") { CoachEvidenceList() }
   }
   Section("复查与专业审核") {
    Text(CoachPolicy.followUp)
    ShareLink(item: CoachPolicy.professionalSummary(data: store.data, at: store.selectedDate)) { Label("分享训练审核摘要", systemImage: "square.and.arrow.up") }
    NavigationLink("记录已获得的专业审核") { ProfessionalReviewView() }
    Text("疼痛、伤病及特殊健康情况进入专业评估；本 App 不验证专业人员资质，也不会把 AI 自检标成专业认证。").font(.caption).foregroundStyle(.secondary)
   }
   if let history = store.data.coachDecisions, !history.isEmpty {
    Section("已确认的调整") {
     ForEach(history.sorted { $0.date > $1.date }) { item in
      VStack(alignment: .leading, spacing: 6) {
       Text("\(item.change.exercise)：\(item.change.before) → \(item.change.after) 次")
       Text(item.date.formatted(date: .abbreviated, time: .omitted)).font(.caption)
       ForEach(item.facts ?? [], id: \.self) { Text($0).font(.caption) }
       ForEach(item.sourceSnapshot ?? []) { source in NavigationLink("当时依据：" + source.title) { CoachEvidenceDetail(source: source) } }
       Text("保留调整前后目标、规则与证据版本；历史训练记录不变。").font(.caption).foregroundStyle(.secondary)
      }
     }
    }
   }
   if let message { Section { Text(message) } }
  }.navigationTitle("每周训练评估").navigationBarTitleDisplayMode(.inline)
   .alert("确认调整一个动作？", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } })) {
    Button("保持原计划", role: .cancel) { pending = nil }
    Button("确认调整") {
     if let change = pending { message = store.acceptCoachChange(change, at: store.selectedDate) ? "已保存目标调整，接下来观察两周。" : "记录或计划已有变化，请重新查看评估。" }
     pending = nil
    }
   } message: {
    if let change = pending { Text("\(change.exercise)：每组 \(change.before) → \(change.after) 次。重量、组数及历史记录保持。\n\n" + CoachPolicy.followUp) }
   }
 }
}
struct CoachProfileView: View {
 var body:some View {PersonalPlanView()}
}
struct CoachEvidenceList: View {
 var body: some View { List {
  Section { Text("资料核实版本：\(CoachEvidenceLibrary.version)。已核对官方说明及论文摘要；不代表获得机构认证。") }
  ForEach(CoachEvidenceLibrary.sources) { source in NavigationLink(source.title) { CoachEvidenceDetail(source: source) } }
 }.navigationTitle("训练依据") }
}
struct CoachEvidenceDetail: View {
 let source: CoachEvidence
 var body: some View { List {
  Section("来源") { Text(source.title).font(.headline); Text("发布：\(source.published)"); Text(source.type); if let url = URL(string: source.url) { Link("查看原文", destination: url) }; Text("定位：\(source.locator)").font(.caption) }
  Section("适用范围") { Text(source.population) }
  Section("核实结论") { Text(source.conclusion) }
  Section("解释限制") { Text(source.limit) }
 }.navigationTitle("依据详情").navigationBarTitleDisplayMode(.inline) }
}

struct ProfessionalReviewView: View {
 @EnvironmentObject var store: AppStore
 @State private var reviewer = ""
 @State private var qualification = ""
 @State private var conclusion = "需补充评估"
 @State private var note = ""
 @State private var saved = false
 @State private var initialized = false
 var reviewDraft:[String:String]{["reviewer":reviewer,"qualification":qualification,"conclusion":conclusion,"note":note]}

 var body: some View {
  Form {
   Section("你获得的审核信息") {
    TextField("专业人员姓名", text: $reviewer)
    TextField("专业资质 / 所属机构", text: $qualification)
    Picker("审核结论", selection: $conclusion) { ForEach(["需补充评估", "确认基础计划", "建议另行调整"], id: \.self) { Text($0) } }
    TextField("记录实际收到的建议", text: $note, axis: .vertical)
    Text("此处是你填写的审核记录，App 未验证身份或资质；保存不会自动解除疼痛与特殊情况的限制。").font(.caption)
    Button("保存审核记录") { store.saveProfessionalReview(reviewer: reviewer, qualification: qualification, conclusion: conclusion, note: note); saved = store.storageError == nil }
     .disabled(reviewer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || qualification.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    if saved { Text("已保存当时的计划与审核信息。") }
   }
   ForEach((store.data.professionalReviews ?? []).sorted { $0.date > $1.date }) { item in
    Section(item.date.formatted(date: .abbreviated, time: .omitted)) {
     Text(item.reviewer + " · " + item.qualification)
     Text(item.conclusion); Text(item.note)
     Text("当时计划：" + item.plans.map(\.name).joined(separator: "、")).font(.caption)
    }
   }
  }.navigationTitle("专业审核记录").keyboardDone()
   .onAppear{guard !initialized else{return};initialized=true;if let f=DraftStorage.load([String:String].self,key:"professional-review"){reviewer=f["reviewer"] ?? "";qualification=f["qualification"] ?? "";conclusion=f["conclusion"] ?? "需补充评估";note=f["note"] ?? ""}}
   .onChange(of:DraftStorage.encoded(reviewDraft)){_,_ in guard initialized else{return};do{try DraftStorage.save(reviewDraft,key:"professional-review")}catch{store.storageError="审核信息草稿未保存"}}
 }
}
