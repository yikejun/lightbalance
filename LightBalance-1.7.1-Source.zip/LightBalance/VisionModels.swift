import Foundation

struct MealEstimate: Decodable {
    var is_food: Bool
    var name: String
    var items: [String]
    var calories: Double
    var protein: Double
    var fat: Double
    var carbs: Double
    var lower: Double
    var upper: Double
    var uncertainty: String

    func validated() throws -> MealEstimate {
        guard is_food else { throw VisionError.message(uncertainty.isEmpty ? "照片中未能识别到餐食，请换一张。" : uncertainty) }
        guard !name.isEmpty, [calories, protein, fat, carbs, lower, upper].allSatisfy({ $0.isFinite && $0 >= 0 && $0 <= 20000 }), lower <= calories, upper >= calories else { throw VisionError.message("识别值异常，请重试或手动记录。") }
        return self
    }
}
enum VisionError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
