import SwiftUI

enum WeeklyService {
    static func request(_ path: String, body: Data? = nil) async throws -> Data {
        #if LIGHTBALANCE_USER_API
        throw VisionError.message("API 版暂不连接开发者的个人周报服务器。")
        #else
        guard let photoURL = URL(string: UserDefaults.standard.string(forKey: "visionEndpoint") ?? ""), photoURL.scheme == "https", photoURL.host != nil, photoURL.user == nil, photoURL.password == nil else { throw VisionError.message("请先配置个人识别服务。") }
        var components = URLComponents(url: photoURL, resolvingAgainstBaseURL: false)!
        components.path = "/coach/v1/" + path; components.query = nil; components.fragment = nil
        guard let url = components.url else { throw VisionError.message("服务地址无效。") }
        let token = VisionCredentials.read()
        guard !token.isEmpty else { throw VisionError.message("请先配置个人服务令牌。") }
        var request = URLRequest(url: url); request.timeoutInterval = 210
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        if let body { request.httpMethod = "POST"; request.httpBody = body; request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else { throw VisionError.message("周报服务请求失败。请检查连接、授权及计划是否已变更。") }
        return data
        #endif
    }
    #if LIGHTBALANCE_USER_API
    static let automatic = false
    static var syncDescription:String { "API 版在你点击生成时发送到你配置的模型服务（"+(URL(string:UserAPIRequest.base)?.host ?? "未配置")+"）。手机关闭时不会后台生成。" }
    static var consentMessage:String { "允许将最近28天训练、营养合计及已读取的健康资料发送到配置的模型服务（"+(URL(string:UserAPIRequest.base)?.host ?? "未配置")+"）分析？使用你的 API 并按供应商计费，结果保存在本机。" }
    static func inbox(data: AppData) async throws -> WeeklyInbox {
        WeeklyInbox(enabled: data.weeklyCoachEnabled == true, modelState: APIKeyStore.read().isEmpty ? "api_key_required" : "ready", reports: data.weeklyAPIReports ?? [], schedule: "每周打开 App，使用自己的 API 生成总结")
    }
    static func consent(_ enabled: Bool) async throws {}
    static func sync(_ data: AppData) async throws {}
    static func generate(data: AppData) async throws -> (String, WeeklyReport?) {
        return ("awaiting_choice", try await WeeklyAPI.generate(data))
    }
    static func decide(_ report: WeeklyReport, choice: String) async throws {}
    #else
    static let automatic = true
    static let syncDescription = "启用后，打开App及保存记录时同步到你的服务器。手机未同步的新数据不会被云端读取；请先在 Apple 健康页面刷新睡眠等数据。照片和单餐明细不随周报上传。"
    static let consentMessage = "最近28天的训练组、营养合计、体重腰围、主观恢复及已读取的睡眠、心率等健康资料会保存到你的服务器。启用模型后用于每周分析，并消耗你授权的模型额度。关闭后停止生成和同步。"
    static func inbox(data: AppData) async throws -> WeeklyInbox { try JSONDecoder().decode(WeeklyInbox.self, from: await request("inbox")) }
    static func consent(_ enabled: Bool) async throws { _ = try await request("consent", body: JSONSerialization.data(withJSONObject: ["enabled": enabled])) }
    static func sync(_ data: AppData) async throws { _ = try await request("snapshot", body: WeeklySnapshot.body(data)) }
    static func generate(data: AppData) async throws -> (String, WeeklyReport?) {
        let data = try await request("generate", body: Data("{}".utf8))
        return (((try JSONSerialization.jsonObject(with: data)) as? [String: String])?["state"] ?? "unknown", nil)
    }
    static func decide(_ report: WeeklyReport, choice: String) async throws {
        _ = try await request("reports/" + report.week + "/decision", body: JSONSerialization.data(withJSONObject: ["choice": choice]))
    }
    #endif
}
struct WeeklyCoachView: View {
    @EnvironmentObject var store: AppStore
    @State private var inbox: WeeklyInbox?
    @State private var busy = false
    @State private var message: String?
    @State private var confirmingConsent = false
    @State private var selectedReport:WeeklyReport?
    @State private var reuseHistory=false
    var body: some View {
        Form {
            Section("每周训练 Agent") {
                Text(inbox?.statusText ?? "正在检查服务状态")
                Text(inbox?.schedule ?? "每周日 20:00（上海时间）")
                if let date = inbox?.snapshotAt { Text("最近同步：" + date).font(.caption).foregroundStyle(.secondary) }
                Text("模型阅读最近28天已同步的训练、身体与恢复资料，按提供的权威资料判断是否调整。调整需你预览确认。").font(.caption)
                Button("刷新周报") { perform { inbox = try await WeeklyService.inbox(data: store.data) } }
                if store.data.weeklyCoachEnabled == true {
                    if WeeklyService.automatic { Button("同步最新资料") { perform { try await WeeklyService.sync(store.data); inbox = try await WeeklyService.inbox(data: store.data) } } }
                    Button("现在生成本周总结") { perform {
                        try await WeeklyService.sync(store.data)
                        let (state, localReport) = try await WeeklyService.generate(data: store.data)
                        if let localReport { store.saveWeeklyAPIReport(localReport) }
                        message = state == "awaiting_choice" ? "本周总结已生成" : state == "already_attempted" ? "本周已有生成记录，请查看下方状态。" : "暂未生成：" + state
                        inbox = try await WeeklyService.inbox(data: store.data)
                    } }.disabled(inbox?.modelState != "ready")
                    Button(WeeklyService.automatic ? "关闭自动周报" : "关闭 API 周报", role: .destructive) { perform { try await WeeklyService.consent(false); store.setWeeklyCoachEnabled(false); inbox = try await WeeklyService.inbox(data: store.data) } }
                } else { Button(WeeklyService.automatic ? "启用并同步资料" : "启用 API 周报") { confirmingConsent = true } }
                Text(WeeklyService.syncDescription).font(.caption).foregroundStyle(.secondary)
                Link(WeeklyService.automatic ? "管理 ChatGPT 用量" : "查看 API 用量", destination: URL(string: WeeklyService.automatic ? "https://chatgpt.com/#settings/Usage" : "https://platform.openai.com/usage")!)
                if let message { Text(message).font(.caption) }
            }
            Section("周总结历史 · 点击展开") {
                if (store.data.weeklyAPIReports ?? []).isEmpty {Text("生成或刷新后的周总结会保留在这里，退出 App 后仍可查看。").font(.caption).foregroundStyle(.secondary)}
                ForEach(store.data.weeklyAPIReports ?? []) { report in
                    DisclosureGroup {
                        if let payload=report.payload {
                            DisclosureGroup("总结与观察"){Text(payload.summary);ForEach(Array(payload.observations.enumerated()),id:\.offset){Text($0.element)}}
                            DisclosureGroup("调整理由与数据缺口"){Text(payload.rationale);ForEach(Array(payload.dataGaps.enumerated()),id:\.offset){Text("待补充："+$0.element).foregroundStyle(.secondary)};Text(payload.question)}
                            DisclosureGroup("资料依据"){ForEach(CoachEvidenceLibrary.sources.filter{payload.sourceIDs.contains($0.id)}){source in Link(source.title,destination:URL(string:source.url)!)}}
                            if !payload.proposedPlans.isEmpty {
                                DisclosureGroup("候选训练方案"){FoldedTrainingPlans(plans:payload.proposedPlans)}
                                if WeeklySnapshot.applicable(report,to:store.data), report.state=="awaiting_choice" {
                                    Button("确认采用本次调整"){selectedReport=report;reuseHistory=false}
                                } else {
                                    Button("复用此历史训练方案"){selectedReport=report;reuseHistory=true}
                                    Text("基于当时资料生成，复用不会重新调用 AI，也不会改变当前饮食目标。").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            if report.state=="awaiting_choice" {Button("保持当前计划"){perform{try await WeeklyService.decide(report,choice:"keep");if !WeeklyService.automatic{store.markWeeklyAPIReport(report.id,choice:"keep")};inbox=try await WeeklyService.inbox(data:store.data)}}}
                            Text(report.state=="accepted" ? "当时已采用" : report.state=="kept" ? "当时选择保持" : report.state).font(.caption)
                        } else {Text(report.state=="failed" ? "生成失败："+(report.error ?? "未知错误") : report.state)}
                    } label:{VStack(alignment:.leading){Text(report.week+" · 周总结");Text(report.snapshotAt+(isCurrent(report) ? " · 当前训练方案" : "")).font(.caption).foregroundStyle(.secondary)}}
                }
            }
            PlanVersionHistoryView()
        }.navigationTitle("每周 Agent").disabled(busy)
        .overlay { if busy { ProgressView().padding().background(.regularMaterial).clipShape(RoundedRectangle(cornerRadius: 12)) } }
        .onChange(of:DraftStorage.encoded(inbox?.reports)){_,_ in if let reports=inbox?.reports{store.cacheWeeklyReports(reports)}}
        .alert(reuseHistory ? "复用历史训练方案？" : "采用本次周报调整？",isPresented:Binding(get:{selectedReport != nil},set:{if !$0{selectedReport=nil}})) {
            Button("取消",role:.cancel){selectedReport=nil}
            Button("确认切换"){if let r=selectedReport{let historical=reuseHistory;selectedReport=nil;perform{if historical{guard store.switchWeeklyReport(r.id) else{throw VisionError.message("当前身体适用范围或方案校验未通过，请重新评估。")}}else{guard WeeklySnapshot.applicable(r,to:store.data) else{throw VisionError.message("资料或计划已改变，请重新评估。")};try await WeeklyService.decide(r,choice:"accept");guard store.applyWeeklyPlans(r) else{throw VisionError.message("保存失败，计划未切换。")};if !WeeklyService.automatic{store.markWeeklyAPIReport(r.id,choice:"accept")};inbox=try await WeeklyService.inbox(data:store.data)}}}}
        } message:{Text(reuseHistory ? "这份方案基于历史资料，未重新评估最新情况。确认后只切换训练，保留饮食目标和实际记录，并保存切换前版本。" : "确认后保存原计划版本并更新训练方案，饮食目标与实际记录保留。")}
        .task { perform { inbox = try await WeeklyService.inbox(data: store.data) } }
        .alert(WeeklyService.automatic ? "允许同步训练与健康资料？" : "允许调用 API 评估训练与健康资料？", isPresented: $confirmingConsent) {
            Button("取消", role: .cancel) {}
            Button(WeeklyService.automatic ? "启用并同步" : "启用 API 周报") { perform {
                try await WeeklyService.consent(true); store.setWeeklyCoachEnabled(true)
                try await WeeklyService.sync(store.data); inbox = try await WeeklyService.inbox(data: store.data)
            } }
        } message: { Text(WeeklyService.consentMessage) }
    }
    func isCurrent(_ report:WeeklyReport)->Bool {store.data.planVersions?.contains{$0.id==store.data.activePlanVersionID && $0.weeklyReportID==report.id && $0.matches(store.data)} == true}
    func perform(_ action: @escaping @MainActor () async throws -> Void) {
        busy = true
        Task { @MainActor in
            defer { busy = false }
            do { try await action() } catch { message = error.localizedDescription }
        }
    }
}
