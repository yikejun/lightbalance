import SwiftUI

struct ExerciseThumbnail: View {
    let name: String
    var size: CGFloat = 64
    var body: some View {
        Group {
            if let art = ExerciseArt.all[name] {
                Image(art.asset).resizable().scaledToFit()
                    .accessibilityLabel(art.reference ? "\(name)，同类动作参考图" : "\(name)，示意图")
            } else {
                Image(systemName: "figure.strengthtraining.traditional").font(.title2).foregroundStyle(.secondary)
                    .accessibilityLabel("自定义动作暂无配图")
            }
        }.frame(width: size, height: size).padding(4)
            .background(Color.forest, in: RoundedRectangle(cornerRadius: 10))
    }
}
struct ExerciseImageDetail: View {
    let name: String
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let art = ExerciseArt.all[name] {
                        Image(art.asset).resizable().scaledToFit().frame(maxHeight: 380).frame(maxWidth: .infinity).padding().background(Color.forest, in: RoundedRectangle(cornerRadius: 18))
                        Text(art.reference ? "同类动作参考" : "动作示意图").font(.headline)
                        Text(art.caption).foregroundStyle(.secondary)
                        Text("图片仅帮助认出动作。实际动作流程与器械设置，请按完整动作名称另行查阅。").font(.subheadline).foregroundStyle(.secondary)
                        Divider()
                        Text("作者：\(art.author)").font(.caption)
                        Text("许可：\(art.license)").font(.caption)
                        if let url = URL(string: art.source) { Link("查看原图与来源", destination: url) }
                        if let url = URL(string: art.licenseURL) { Link("查看图片许可", destination: url) }
                    }
                }.padding(20)
            }.background(Color.canvas).navigationTitle(name).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
        }.tint(.forest)
    }
}
