import SwiftUI

struct HealthConnectionView: View {
 @EnvironmentObject var store: AppStore
 @State private var busy = false
 @State private var error: String?
 @State private var message: String?
 @State private var confirmClear = false
 private let reader = HealthKitReader()
 var cache: HealthCache? { store.data.healthCache }
 var body: some View {
  List {
   Section("Apple 健康 · 本机读取") {
    Toggle("将健康训练同步到我的训练",isOn:Binding(get:{store.data.healthWorkoutSync != false},set:{store.setHealthWorkoutSync($0)}))
    Text("读取后的训练按日期同步到训练页；重复健康记录只导入一次。可能与手填重复的训练先标记，确认后再计入次数；不编造组数、负重或余力。").font(.caption).foregroundStyle(.secondary)
    Text("读取最近 28 天的睡眠、步数、活动能量、体重、体脂、腰围、静息心率、心率变异性和训练记录，为后续模型评估整理资料。")
    Text("每项由你在系统授权页选择。健康数据先保存到本机，不向健康写入。若你另行启用每周 Agent，健康快照会随训练资料同步到你配置的服务用于评估。").font(.caption).foregroundStyle(.secondary)
    Toggle("刷新后自动补全身体记录的空白项", isOn: Binding(get: { store.data.healthAutoFill == true }, set: { store.setHealthAutoFill($0) }))
    Text("补全体重、体脂、腰围、步数和睡眠；保留手动值；已采用的健康值可随刷新更新，不改基准。不自动添加训练组或把运动热量加进饮食额度。开启 App 时最多每小时刷新一次；不承诺后台实时同步。").font(.caption).foregroundStyle(.secondary)
    if HealthKitReader.available {
     Button(store.data.healthAccessRequested == true ? "再次请求读取权限" : "连接 Apple 健康") { read(authorize: true) }
     if store.data.healthAccessRequested == true { Button("刷新最近 28 天数据") { read(authorize: false) } }
    } else { Text("请在 iPhone 上授权读取；此设备暂不提供健康读取。") }
    Text("若系统未再次弹出授权页，可在 Apple 健康的个人资料 → App / 数据访问中修改轻衡权限。").font(.caption).foregroundStyle(.secondary)
    if busy { HStack { ProgressView(); Text("正在读取健康数据…") } }
    if let error { Text(error).foregroundStyle(.red) }
    if let message { Text(message).font(.caption) }
   }
   if let cache {
    Section("数据状态") {
     Text("更新于 " + cache.refreshedAt.formatted(date: .abbreviated, time: .shortened))
     Text("有数据的日期：\(cache.days.filter { !$0.values.isEmpty }.count) / \(cache.days.count) 天")
     Text("无数据可能表示没有记录、未允许读取或仅授权了部分历史。App 无法区分读取被拒绝与没有记录。").font(.caption)
     ForEach(cache.issues, id: \.self) { Text($0).font(.caption).foregroundStyle(.orange) }
    }
    if !cache.sleepSources.isEmpty {
     Section("睡眠来源") {
      Picker("使用来源", selection: Binding(get: { store.data.healthSleepSource ?? "all" }, set: { value in store.setHealthSleepSource(value == "all" ? nil : value); read(authorize: false) })) {
       Text("全部来源 · 合并区间").tag("all")
       ForEach(cache.sleepSources) { source in Text(source.name).tag(source.id) }
      }
      Text("睡眠按前一天中午至当天中午归属日期，只计算实际睡着的区间。多来源结果可能有差异，可选择主要设备或应用；不把卧床时间计为睡眠。").font(.caption)
     }
    }
    Section("每日健康数据") {
     ForEach(cache.days.sorted { $0.date > $1.date }) { day in
      NavigationLink { HealthDayDetail(day: day) } label: {
       VStack(alignment: .leading, spacing: 5) {
        Text(day.date.formatted(date: .abbreviated, time: .omitted))
        Text("睡眠 \(day.values["sleep"].map { number($0.value) + " 小时" } ?? "无可读取数据") · 步数 \(day.values["steps"].map { number($0.value) } ?? "无可读取数据")").font(.caption).foregroundStyle(.secondary)
       }
      }
     }
    }
    Section("健康中的训练 · 原始来源") {
     if cache.workouts.isEmpty { Text("暂无可读取训练记录") }
     ForEach(cache.workouts) { workout in
      VStack(alignment: .leading, spacing: 5) {
       Text(workout.name).font(.headline)
       Text("\(workout.start.formatted(date: .abbreviated, time: .shortened)) · \(number(workout.minutes)) 分钟")
       Text("来源：" + workout.source).font(.caption).foregroundStyle(.secondary)
       if let calories = workout.calories { Text("活动能量：\(number(calories)) kcal").font(.caption) }
       if HealthMath.possiblyDuplicate(workout, in: cache.workouts) { Text("与另一条记录高度重叠，可能重复；尚未合并进训练次数。").font(.caption).foregroundStyle(.orange) }
      }
     }
     Text("已开启同步时会进入训练页；训练次数去重，逐组负重、次数、余力仍以实际填写为准。").font(.caption)
    }
    Section("本机数据管理") {
     Button("清除本机健康缓存", role: .destructive) { confirmClear = true }
     Text("清除不会删除 Apple 健康中的数据或撤销系统权限。若要停用权限，请在 Apple 健康的个人资料 → App / 数据访问中管理轻衡。").font(.caption)
    }
   }
  }.disabled(busy).navigationTitle("Apple 健康").navigationBarTitleDisplayMode(.inline)
   .alert("清除健康缓存？", isPresented: $confirmClear) {
    Button("取消", role: .cancel) {}
    Button("清除", role: .destructive) { store.clearHealthCache(); message = "缓存已清除。已手动采用的身体记录保留。" }
   } message: { Text("只清除轻衡保存的健康快照，Apple 健康原始数据不受影响。") }
 }
 func read(authorize: Bool) {
  guard !busy else { return }; busy = true; error = nil; message = nil
  Task { @MainActor in
   defer { busy = false }
   do {
    if authorize { try await reader.authorize(); store.markHealthAuthorizationRequested() }
    let next = try await reader.fetch(sleepSource: store.data.healthSleepSource)
    store.saveHealthCache(next)
    if store.storageError != nil { error = store.storageError }
    else if next.days.allSatisfy({ $0.values.isEmpty }) && next.workouts.isEmpty { message = "本次没有可读取的数据，请检查是否有健康记录以及各项读取权限。" }
    else { message = "已更新本机健康快照。" }
   } catch { self.error = error.localizedDescription }
  }
 }
}
struct HealthDayDetail: View {
 @EnvironmentObject var store: AppStore
 let day: HealthDay
 @State private var imported = false
 private let metrics: [(String,String,String)] = [("sleep","睡眠","小时"),("steps","步数","步"),("activeEnergy","活动能量","kcal"),("weight","体重","kg"),("bodyFat","体脂","%"),("waist","腰围","cm"),("restingHeartRate","静息心率","次/分钟"),("hrv","心率变异性 SDNN","ms")]
 var body: some View {
  List {
   Section(day.date.formatted(date: .abbreviated, time: .omitted)) {
    ForEach(metrics, id: \.0) { key,title,unit in
     VStack(alignment: .leading, spacing: 6) {
      HStack { Text(title); Spacer(); Text(day.values[key].map { number($0.value) + " " + unit } ?? "无可读取数据") }
      if let value = day.values[key], !value.sources.isEmpty { Text("来源：" + value.sources.joined(separator: "、")).font(.caption).foregroundStyle(.secondary) }
     }
    }
   }
   Section("可选 · 补全身体记录") {
    Button("采用尚未填写的体重、体脂、腰围、步数与睡眠") { store.importHealthDay(day); imported = store.storageError == nil }
    Text("补空白项并刷新已采用的健康值；手填值保留。疲劳、疼痛和训练余力无法由这些健康数据自动得出，仍需记录。睡眠是设备或应用的估计。").font(.caption)
    if imported { Text("已补全可用的空白项。") }
   }
  }.navigationTitle("健康数据详情").navigationBarTitleDisplayMode(.inline)
 }
}
