"""Offline asset coverage and provenance checks; does not judge exercise technique."""
import json,re,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
rows=json.loads((root/'Research/exercise-images.json').read_text())
names=re.findall(r'\.init\(name: "([^"]+)"',(root/'LightBalance/TrainingModels.swift').read_text())
assert len(rows)==len(names)==201 and {x['name'] for x in rows}==set(names)
registry=(root/'LightBalance/ExerciseArtwork.swift').read_text()
for row in rows:
 p=root/'LightBalance/Assets.xcassets'/(row['asset']+'.imageset')
 contents=json.loads((p/'Contents.json').read_text());f=p/contents['images'][0]['filename']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'],row['name']
 assert all(row[k] for k in ['caption','source','author','license','licenseURL'])
 assert row['name'] in registry and row['asset'] in registry
actual={p.stem for p in (root/'LightBalance/Assets.xcassets').glob('exercise_*.imageset')}
assert actual=={x['asset'] for x in rows}
print(f'Passed: {len(rows)} actions, {len(actual)} offline images, {sum(x["reference"] for x in rows)} marked related references, provenance and hashes')
