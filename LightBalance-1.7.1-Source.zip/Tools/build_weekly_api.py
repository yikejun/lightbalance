from pathlib import Path
import sys,json
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'Backend/Weekly'))
import weekly_service as w
values={'prompt':w.PROMPT,'schema':json.dumps(w.SCHEMA,ensure_ascii=False),'evidence':json.dumps(w.EVIDENCE,ensure_ascii=False),'catalog':json.dumps(w.CATALOG,ensure_ascii=False)}
s='import Foundation\n\n#if LIGHTBALANCE_USER_API\nenum WeeklyAPIResources {\n'
for name,value in values.items():s+=f'    static let {name} = #"""\n{value}\n"""#\n'
s+='}\n#endif\n'
(root/'LightBalance/WeeklyAPIResources.swift').write_text(s)
