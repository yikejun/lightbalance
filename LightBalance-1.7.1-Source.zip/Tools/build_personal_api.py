"""Generate identical local and gateway personal-plan contracts."""
from pathlib import Path
import sys,json,re
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'Backend'))
import plan_ai as p
s='import Foundation\nenum PersonalPlanResources {\n'
for name,value in [('prompt',p.PROMPT),('schema',json.dumps(p.SCHEMA,ensure_ascii=False)),('sources',json.dumps(p.SOURCES,ensure_ascii=False))]:
 s+=f' static let {name} = #"""\n{value}\n"""#\n'
s+='}\n'
(root/'LightBalance/PersonalPlanResources.swift').write_text(s)

# Both app editions validate and link exactly the sources supplied to the model.
# Keep this in Models.swift so standalone model checks use the same contract.
ids=[source['id'] for source in p.SOURCES]
assert len(ids)==len(set(ids)), 'Duplicate personal guide IDs'
links={source['id']:source['url'] for source in p.SOURCES}
quotes=lambda value:json.dumps(value,ensure_ascii=False)
library='enum GuideLibrary {\n static let ids: [String] = '+quotes(ids)+'\n static let links: [String:String] = [\n'+',\n'.join(quotes(k)+': '+quotes(v) for k,v in links.items())+'\n ]\n static func url(_ id:String) -> URL? { links[id].flatMap(URL.init(string:)) }\n}\n'
for edition in ['LightBalance','APIEdition/LightBalance']:
 model=root/edition/'Models.swift'
 text=model.read_text()
 text,count=re.subn(r'enum GuideLibrary \{.*?\n\}\n',lambda _:library,text,count=1,flags=re.S)
 assert count==1, 'GuideLibrary block not found'
 model.write_text(text)
 (root/edition/'PersonalPlanResources.swift').write_text(s)
