import json
from pathlib import Path
root=Path(__file__).resolve().parents[1];lib=json.loads((root/'Research/Evidence/coach-evidence.json').read_text())
def lit(s):return json.dumps(s,ensure_ascii=False)
s='// Generated from Research/Evidence/coach-evidence.json. Edit the curated manifest, then regenerate.\nimport Foundation\n\nstruct CoachEvidence: Codable, Identifiable {\n let id, title, published, url, locator, population, type, conclusion, limit: String\n}\nenum CoachEvidenceLibrary {\n static let version = '+lit(lib['version'])+'\n static let sources: [CoachEvidence] = [\n'
for r in lib['sources']:s+=' .init('+', '.join(k+': '+lit(r[k]) for k in ['id','title','published','url','locator','population','type','conclusion','limit'])+'),\n'
s+=' ]\n}\n';(root/'LightBalance/CoachEvidence.swift').write_text(s)
