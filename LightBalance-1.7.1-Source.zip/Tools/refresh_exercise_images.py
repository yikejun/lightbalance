"""Recreate missing packaged assets using the saved, pinned attribution manifest.
No temporary discovery files required. Stops on CDN rate limiting; no retries.
"""
import json,hashlib,urllib.request,urllib.parse,urllib.error,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
rows=json.loads((root/'Research/exercise-images.json').read_text())
for row in {x['asset']:x for x in rows}.values():
 p=root/'LightBalance/Assets.xcassets'/(row['asset']+'.imageset');contents=p/'Contents.json'
 if contents.exists():
  f=p/json.loads(contents.read_text())['images'][0]['filename']
  if f.exists() and hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256']:continue
 try:
  with urllib.request.urlopen(urllib.request.Request(row['url'],headers={'User-Agent':'LightBalance exercise attribution asset refresh'}),timeout=45) as response:raw=response.read(12_000_001)
 except urllib.error.HTTPError as e:
  retry=e.headers.get('Retry-After','unspecified');raise SystemExit(f'Source returned HTTP {e.code}; Retry-After {retry}. Refresh stopped.') from None
 if len(raw)>12_000_000 or len(raw)<500 or b'<!doctype html' in raw[:100].lower():raise SystemExit('Source was not a usable image.')
 suffix=Path(urllib.parse.urlparse(row['url']).path).suffix.lower();suffix='.jpg' if suffix=='.jfif' else suffix
 with tempfile.TemporaryDirectory() as work:
  original=Path(work)/('reference'+suffix);original.write_bytes(raw);result=original
  if suffix!='.svg':
   result=Path(work)/'reference.png'
   if result!=original:subprocess.run(['sips','-s','format','png',str(original),'--out',str(result)],check=True,stdout=subprocess.DEVNULL)
   subprocess.run(['sips','-Z','720',str(result)],check=True,stdout=subprocess.DEVNULL)
  if hashlib.sha256(result.read_bytes()).hexdigest()!=row['sha256']:raise SystemExit('Asset hash changed; review upstream content before replacing it.')
  p.mkdir(parents=True,exist_ok=True);(p/result.name).write_bytes(result.read_bytes())
  contents.write_text(json.dumps({'images':[{'filename':result.name,'idiom':'universal'}],'info':{'author':'xcode','version':1}},indent=2)+'\n')
print('All saved exercise images present.')
