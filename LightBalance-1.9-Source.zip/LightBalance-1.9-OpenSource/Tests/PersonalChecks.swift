import Foundation
@main struct PersonalChecks {
 @MainActor static func main() throws {
  let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
  defer{try? FileManager.default.removeItem(at:directory)}
  let url=directory.appendingPathComponent("records.json")
  let store=AppStore(storageURL:url)
  precondition(store.needsOnboarding)
  let profile=PersonalProfile(fields:["age":"30","height":"175","weight":"75","goal":"减脂保肌","restriction":"无","pregnancy":"否","meals":"3"])
  store.savePersonalProfile(profile)
  let reopened=AppStore(storageURL:url)
  precondition(!reopened.needsOnboarding && reopened.data.personalProfile==profile && reopened.target(.high).calories==0 && reopened.data.trainingPlans?.isEmpty==true)
  let n=Nutrition(calories:2000,protein:120,fat:60,carbs:245)
  let plan=TrainingPlan(name:"全身",exercises:[PlannedExercise(name:"徒手深蹲")])
  var proposal=PersonalProposal(status:"ready",explanation:"WHO和ACSM依据；营养为估计",questions:[],sourceIDs:["WHO2020","ACSM2026","NIDDK"],plans:[plan],targets:Dictionary(uniqueKeysWithValues:DayMode.allCases.map{($0.rawValue,n)}),weeklyBudget:14000,schedule:Array(repeating:"中碳日，全身/休息",count:7),assumptions:"估计，逐步调整",baseHash:PersonalPlanFingerprint.hash(store.data))
  _ = try proposal.validated(profile:profile)
  precondition(store.applyPersonalProposal(proposal,currentHash:PersonalPlanFingerprint.hash(store.data)))
  store.update{$0.weight=74;$0.meals=[Meal(kind:"午餐",name:"饭",nutrition:n)];$0.workouts=[Workout(kind:"力量",minutes:40)]}
  let mealID=store.day.meals[0].id
  precondition(!store.applyPersonalProposal(proposal,currentHash:PersonalPlanFingerprint.hash(store.data)))
  proposal.baseHash=PersonalPlanFingerprint.hash(store.data)
  precondition(store.applyPersonalProposal(proposal,currentHash:PersonalPlanFingerprint.hash(store.data)))
  precondition(store.day.weight==74 && store.day.meals[0].id==mealID && store.day.workouts.count==1)
  var unsafe=profile;unsafe.fields["restriction"]="有";precondition((try? proposal.validated(profile:unsafe))==nil)
  unsafe=profile;unsafe.fields["targetWeight"]="40";precondition((try? proposal.validated(profile:unsafe))==nil)
  precondition(!profile.missingForPlan.isEmpty && profile.missingForPlan.contains("目前活动水平"))
  proposal.diet=DietRecommendation(style:"balanced",name:"均衡家常",rationale:"可持续",meals:["早餐","午餐","晚餐"],tips:[],sourceIDs:["NIDDK-diet"],carbCycling:false)
  proposal.weekModes=Array(repeating:"medium",count:7)
  proposal.baseHash=PersonalPlanFingerprint.hash(store.data)
  precondition(store.applyPersonalProposal(proposal,currentHash:PersonalPlanFingerprint.hash(store.data)))
  precondition(store.data.activeDiet?.name=="均衡家常" && store.data.weeklyBudget==14000 && store.defaultMode(for:Date()) == .medium)
  proposal.weeklyBudget=11000;precondition((try? proposal.validated(profile:profile))==nil)
  proposal.weeklyBudget=14000
  let manifest = try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:"Backend/personal-guides.json"))) as! [String:Any]
  let sources=manifest["sources"] as! [[String:Any]]
  precondition(Set(GuideLibrary.ids)==Set(sources.map{$0["id"] as! String}))
  for source in sources {
   let id=source["id"] as! String
   precondition(GuideLibrary.url(id)?.absoluteString==source["url"] as? String)
   proposal.sourceIDs=[id]
   _ = try proposal.validated(profile:profile)
  }
  proposal.sourceIDs=["ACSM2026","NASM-upper-lower","NASM-beginner-split"]
  precondition((try? proposal.validated(profile:profile)) != nil)
  proposal.diet?.sourceIDs=["NICE-diet2025","DIRECT2008","DIETFITS2018"]
  precondition((try? proposal.validated(profile:profile)) != nil)
  proposal.sourceIDs=["invented"];precondition((try? proposal.validated(profile:profile))==nil)
  proposal.sourceIDs=["ACSM2026"];proposal.diet?.sourceIDs=["invented"]
  precondition((try? proposal.validated(profile:profile))==nil)
  precondition(IntakeRange.valid(lower:"",upper:"",calories:600))
  precondition(IntakeRange.valid(lower:"  ",upper:"700",calories:600))
  precondition(IntakeRange.valid(lower:"500",upper:"",calories:600))
  precondition(IntakeRange.valid(lower:"650",upper:"",calories:600))
  precondition(!IntakeRange.valid(lower:"700",upper:"600",calories:650))
  DraftStorage.customRoot=directory.appendingPathComponent("drafts")
  let key="test-"+UUID().uuidString
  defer{DraftStorage.remove(key)}
  let preview=FoodPreview(name:"饭",assessment:"balanced",explanation:"待确认",items:[],uncertainty:"估计")
  let draft=MealDraft(fields:["name":"未完成","lower":""],photos:[.init(data:Data([255,216,255,1]),role:"label")],preview:preview,grams:[],adopted:false)
  try DraftStorage.save(draft,key:key)
  let restored=DraftStorage.load(MealDraft.self,key:key)!
  precondition(restored.fields["name"]=="未完成" && restored.preview?.name=="饭" && restored.photos[0].role=="label" && restored.photos[0].data==draft.photos[0].data)
  precondition(store.day.meals.count==1) // Cached estimates never become logged intake.
  print("Passed: onboarding without model, personalized target application, stale/unsafe plan rejection, historical preservation, optional range endpoints, persisted photo and AI drafts")
 }
}
