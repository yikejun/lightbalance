import Foundation

@main struct TrainingChecks {
    static func main() throws {
        assert(Set(ExerciseLibrary.all.map(\.name)).count == ExerciseLibrary.all.count)
        assert(ExerciseLibrary.all.count >= 150)
        assert(ExerciseLibrary.templates.flatMap(\.exercises).allSatisfy { ExerciseLibrary.find($0.name) != nil })
        assert(Workout(kind: "有氧", minutes: 40, trainingType: "力量").isStrength)
        let day = Calendar.current.startOfDay(for: Date())
        let oldDate = Calendar.current.date(byAdding: .day, value: -7, to: day)!
        let previous = Workout(kind: "力量 A", minutes: 40, sets: [ExerciseSet(exercise: "杠铃卧推", weight: 40, reps: 8)])
        let current = Workout(kind: "自选训练", minutes: 45, sets: [
            ExerciseSet(exercise: "杠铃卧推", weight: 40, reps: 10),
            ExerciseSet(exercise: "杠铃卧推", weight: 40, reps: 20, warmup: true),
            ExerciseSet(exercise: "平板支撑", weight: 0, reps: 0, seconds: 30)])
        let noncontiguous=[current.sets[0],current.sets[2],current.sets[1]]
        let grouped=ExerciseSetGroup.make(noncontiguous)
        assert(grouped.map(\.name)==["杠铃卧推","平板支撑"])
        assert(grouped[0].sets.map(\.id)==[current.sets[0].id,current.sets[1].id])
        assert(grouped[0].sets[1].warmup==true && grouped[1].sets[0].seconds==30)
        assert(Set(grouped.flatMap(\.sets).map(\.id))==Set(noncontiguous.map(\.id)))
        let records = [DayRecord(date: oldDate, mode: .high, workouts: [previous]), DayRecord(date: day, mode: .high, workouts: [current])]
        let text = TrainingAssessment.comparisons(workout: current, records: records, date: day).joined()
        assert(text.contains("8 → 10"))
        assert(!text.contains("→ 20 次"))
        assert(TrainingAssessment.summary(records: records, ending: day).joined().contains("2 个工作组"))
        let assisted = Workout(kind: "力量", minutes: 30, sets: [ExerciseSet(exercise: "杠铃卧推", weight: 40, reps: 10, loadMode: "辅助重量")])
        assert(TrainingAssessment.comparisons(workout: assisted, records: records, date: day).joined().contains("暂无"))
        assert(TrainingAssessment.comparisons(workout: current, records: [records[1]], date: day).joined().contains("暂无"))
        var app = AppData(); app.records = records
        let encoded = try JSONEncoder().encode(app)
        var object = try JSONSerialization.jsonObject(with: encoded) as! [String: Any]
        object.removeValue(forKey: "trainingPlans")
        var days = object["records"] as! [[String: Any]]
        for i in days.indices {
            var workouts = days[i]["workouts"] as! [[String: Any]]
            for j in workouts.indices {
                var sets = workouts[j]["sets"] as! [[String: Any]]
                for k in sets.indices { for key in ["seconds", "rir", "warmup", "loadMode"] { sets[k].removeValue(forKey: key) } }
                workouts[j]["sets"] = sets
            }
            days[i]["workouts"] = workouts
        }
        object["records"] = days
        let migrated = try JSONDecoder().decode(AppData.self, from: JSONSerialization.data(withJSONObject: object))
        assert(migrated.records.count == 2 && migrated.trainingPlans == nil)
        assert(migrated.records[0].workouts[0].sets[0].reps == 8)
        app.trainingPlans = [ExerciseLibrary.templates[0]]
        let loaded = try JSONDecoder().decode(AppData.self, from: JSONEncoder().encode(app))
        assert(loaded.trainingPlans?.first?.name == app.trainingPlans?.first?.name)
        let p=PersonalProfile(fields:["equipment":"自重、哑铃"])
  var preferenceData=AppData();preferenceData.personalProfile=p
  assert(TrainingPreferences.available(preferenceData)==Set(["自重","哑铃"]))
  assert(TrainingPreferences.matches(ExerciseLibrary.all.first{$0.equipment=="哑铃"}!,data:preferenceData))
  assert(!TrainingPreferences.matches(ExerciseLibrary.all.first{$0.equipment=="杠铃"}!,data:preferenceData))
  print("Passed: catalog integrity, legacy migration, templates round-trip, warmup exclusion, sparse history and load-mode isolation")
    }
}
