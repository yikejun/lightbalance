"""Keep iOS food contracts in sync with the gateway."""
from pathlib import Path
import sys,json
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'Backend'))
import food_ai
s='import Foundation\nenum FoodResources {\n'
for name,value in [('previewPrompt',food_ai.PREVIEW_PROMPT),('previewSchema',json.dumps(food_ai.PREVIEW_SCHEMA,ensure_ascii=False)),('chatPrompt',food_ai.CHAT_PROMPT),('chatSchema',json.dumps(food_ai.CHAT_SCHEMA,ensure_ascii=False)),('supplyPrompt',food_ai.SUPPLY_PROMPT)]:
 s+=' static let '+name+' = '+json.dumps(value,ensure_ascii=False)+'\n'
s+='}\n'
for directory in [root/'LightBalance',root/'APIEdition/LightBalance']:
 if directory.exists():(directory/'FoodResources.swift').write_text(s)
