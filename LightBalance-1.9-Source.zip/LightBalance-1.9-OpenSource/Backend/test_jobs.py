import http.client,json,tempfile,threading,unittest,uuid
from pathlib import Path
from jobs import JobStore,QueueFull
from memory import FoodMemory
from server import Server,Handler
from test_food_ai import Tests
class DurableJobs(unittest.TestCase):
 def test_resubmit_reopen_payload_cleanup(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'jobs.db';calls=[];j=JobStore(path,lambda r,b:calls.append(b) or {'answer':'done'});id=str(uuid.uuid4());body={'test':'original'}
   j.submit(id,'/chat',body);j.submit(id,'/chat',body);self.assertRaises(ValueError,j.submit,id,'/chat',{'test':'changed'})
   j=JobStore(path,j.execute);self.assertTrue(j.step());self.assertFalse(j.step());self.assertEqual(len(calls),1)
   self.assertEqual(JobStore(path,j.execute).get(id)['result'],{'answer':'done'})
   with j.db() as db:self.assertIsNone(db.execute('SELECT payload FROM jobs').fetchone()[0])
   j.submit(id,'/chat',body);self.assertFalse(j.step());self.assertEqual(len(calls),1)
 def test_no_retry_after_uncertain_server_restart(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'jobs.db';j=JobStore(path,lambda *a:self.fail('must not execute'));id=str(uuid.uuid4());j.submit(id,'/chat',{})
   with j.db() as db:db.execute("UPDATE jobs SET state='running'")
   j=JobStore(path,j.execute);self.assertEqual(j.get(id)['state'],'failed');self.assertFalse(j.step())
 def test_queue_limit_and_clear_pending_memory(self):
  with tempfile.TemporaryDirectory() as d:
   seen=[];j=JobStore(Path(d)/'jobs.db',lambda r,b:seen.append(b) or {})
   for _ in range(8):j.submit(str(uuid.uuid4()),'/chat',{'memoryEnabled':True})
   self.assertRaises(QueueFull,j.submit,str(uuid.uuid4()),'/chat',{})
   j.clear_pending_memory();j.step();self.assertFalse(seen[0]['memoryEnabled'])
 def test_authenticated_http_survives_client_disconnect(self):
  with tempfile.TemporaryDirectory() as d:
   s=Server(('127.0.0.1',0),Handler);s.app_token='z'*32;s.model='test';calls=[];s.jobs=JobStore(Path(d)/'jobs.db',lambda r,b:calls.append(b) or {'answer':'done'})
   t=threading.Thread(target=s.serve_forever,daemon=True);t.start();id=str(uuid.uuid4());body={'id':id,'route':'/chat','body':{'context':{},'messages':[{'role':'user','content':'test'}]}}
   def request(method,path,body=None,token=s.app_token):
    c=http.client.HTTPConnection(*s.server_address,timeout=2);c.request(method,path,json.dumps(body) if body else None,{'Authorization':'Bearer '+token});r=c.getresponse();v=(r.status,json.loads(r.read()));c.close();return v
   try:
    self.assertEqual(request('GET','/v1/jobs/'+id,token='wrong')[0],401)
    self.assertEqual(request('POST','/v1/jobs',body)[0],202);self.assertEqual(request('POST','/v1/jobs',body)[0],202);self.assertEqual(calls,[])
    s.jobs.step();self.assertEqual(request('GET','/v1/jobs/'+id)[1]['result'],{'answer':'done'});self.assertEqual(len(calls),1)
    body['route']='/unknown';self.assertEqual(request('POST','/v1/jobs',body)[0],400)
   finally:s.shutdown();s.server_close();t.join()
class Memory(unittest.TestCase):
 def test_optin_replacement_separation_clear_inflight(self):
  with tempfile.TemporaryDirectory() as d:
   m=FoodMemory(Path(d)/'memory.db');b={'context':{'date':'2026-10-08','recentConfirmedMeals':[{'name':'egg'}]},'memoryEnabled':True}
   old=m.enrich('/meal-preview',b);m.remember('/meal-preview',old,Tests().result())
   memo=m.enrich('/chat',b)['context']['foodMemory'];self.assertEqual(memo['confirmedMeals'][0]['name'],'egg');self.assertFalse(memo['previousSuggestions'][0]['suggestion']['confirmed'])
   b['context']['recentConfirmedMeals']=[];self.assertEqual(m.enrich('/chat',b)['context']['foodMemory']['confirmedMeals'],[])
   self.assertNotIn('foodMemory',m.enrich('/chat',{'context':{},'memoryEnabled':False})['context'])
   m.clear();m.remember('/meal-preview',old,Tests().result());self.assertEqual(m.enrich('/chat',b)['context']['foodMemory']['previousSuggestions'],[])
class BridgeQueue(unittest.TestCase):
 def test_busy_retries_only_before_acceptance(self):
  from unittest.mock import patch,Mock
  from types import SimpleNamespace
  import io,urllib.error
  from server import execute,GatewayError
  server=SimpleNamespace(auth_mode='chatgpt',model='test',api_key='test',budget=Mock(),hourly_limit=0,daily_limit=0)
  server.budget.reserve.return_value=None
  response=Mock();response.__enter__=Mock(return_value=io.BytesIO(b'{}'));response.__exit__=Mock(return_value=False)
  def error(code):return urllib.error.HTTPError('http://test',429,'busy',{},io.BytesIO(json.dumps({'error':{'code':code}}).encode()))
  with patch('server.urllib.request.urlopen',side_effect=[error('bridge_busy'),response]) as network,patch('server.time.sleep'),patch('server.parse_response',return_value={'answer':'ok'}):
   self.assertEqual(execute(server,'/chat',{'context':{},'messages':[{'role':'user','content':'test'}]}),{'answer':'ok'});self.assertEqual(network.call_count,2);server.budget.reserve.assert_called_once()
  with patch('server.urllib.request.urlopen',side_effect=error('subscription_sharing_usage_limit_exceeded')) as network,patch('server.time.sleep') as sleep:
   self.assertRaises(GatewayError,execute,server,'/chat',{'context':{},'messages':[{'role':'user','content':'test'}]});self.assertEqual(network.call_count,1);sleep.assert_not_called()
class TemporaryRecovery(unittest.TestCase):
 def test_bounded_recovery_and_no_uncertain_replay(self):
  from unittest.mock import patch,Mock
  from types import SimpleNamespace
  import io,urllib.error
  from server import execute,GatewayError
  server=SimpleNamespace(auth_mode='chatgpt',model='test',api_key='test',budget=Mock(),hourly_limit=0,daily_limit=0)
  server.budget.reserve.return_value=None
  body={'context':{},'messages':[{'role':'user','content':'test'}]}
  def unavailable():return urllib.error.HTTPError('http://test',503,'unavailable',{},io.BytesIO(json.dumps({'error':{'code':'subscription_sharing_usage_unavailable'}}).encode()))
  response=Mock();response.__enter__=Mock(return_value=io.BytesIO(b'{}'));response.__exit__=Mock(return_value=False)
  with patch('server.urllib.request.urlopen',side_effect=[unavailable(),response]) as network,patch('server.time.sleep') as sleep,patch('server.parse_response',return_value={'answer':'ok'}):
   self.assertEqual(execute(server,'/chat',body),{'answer':'ok'});self.assertEqual(network.call_count,2);sleep.assert_called_once_with(2)
  with patch('server.urllib.request.urlopen',side_effect=lambda *a,**k:(_ for _ in ()).throw(unavailable())) as network,patch('server.time.sleep') as sleep:
   self.assertRaises(GatewayError,execute,server,'/chat',body);self.assertEqual(network.call_count,3);self.assertEqual([v.args[0] for v in sleep.call_args_list],[2,4])
  with patch('server.urllib.request.urlopen',side_effect=urllib.error.URLError('uncertain')) as network,patch('server.time.sleep') as sleep:
   self.assertRaises(GatewayError,execute,server,'/chat',body);self.assertEqual(network.call_count,1);sleep.assert_not_called()
if __name__=='__main__':unittest.main()

