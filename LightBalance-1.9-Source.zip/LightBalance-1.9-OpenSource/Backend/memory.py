"""Opt-in single-owner food references; confirmed intake and suggestions stay separate."""
import copy,json,sqlite3
from pathlib import Path
from contextlib import contextmanager
class FoodMemory:
 def __init__(self,path):
  self.path=str(path)
  with self.db() as db:
   db.executescript('CREATE TABLE IF NOT EXISTS memory_epoch(id INTEGER PRIMARY KEY,value INTEGER);INSERT OR IGNORE INTO memory_epoch VALUES(1,0);CREATE TABLE IF NOT EXISTS food_snapshot(id INTEGER PRIMARY KEY,payload TEXT);CREATE TABLE IF NOT EXISTS food_references(id INTEGER PRIMARY KEY AUTOINCREMENT,route TEXT,payload TEXT);')
  Path(path).chmod(0o600)
 @contextmanager
 def db(self):
  connection=sqlite3.connect(self.path,timeout=15)
  try:
   with connection:yield connection
  finally:connection.close()
 def clear(self):
  with self.db() as db:db.executescript('DELETE FROM food_snapshot;DELETE FROM food_references;UPDATE memory_epoch SET value=value+1;')
 def enrich(self,route,body):
  b=copy.deepcopy(body)
  if b.get('memoryEnabled') is not True:return b
  recent=b.get('context',{}).get('recentConfirmedMeals',b.get('recentConfirmedMeals',[]))
  if not isinstance(recent,list) or len(recent)>48 or len(json.dumps(recent))>40000:raise ValueError('invalid_food_memory')
  with self.db() as db:
   # A complete phone snapshot replaces prior facts, reflecting edits/deletions.
   db.execute('INSERT INTO food_snapshot VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(json.dumps(recent,ensure_ascii=False),))
   b['_memoryEpoch']=db.execute('SELECT value FROM memory_epoch').fetchone()[0]
   refs=[{'route':r[0],'suggestion':json.loads(r[1])} for r in db.execute('SELECT route,payload FROM food_references ORDER BY id DESC LIMIT 8')]
  memory={'confirmedMeals':recent,'previousSuggestions':refs,'rule':'仅confirmedMeals是已确认摄入；previousSuggestions未确认，不当作已吃、不照搬旧份量。重复食物可参考旧营养值，但需核对品牌、标签、生熟重和份量；新标签和实际确认优先。缺记录不表示没吃。'}
  if route in ['/meal-preview','/chat']:b['context']['foodMemory']=memory
  else:b['foodMemory']=memory
  return b
 def remember(self,route,body,result):
  if body.get('memoryEnabled') is not True or route not in ['/meal-preview','/chat']:return
  # No image, credential, full user note, or body measurements enter reference memory.
  result=({'answer':result['answer'][:1500]} if route=='/chat' else {'name':result['name'],'items':[{'name':i['name'],'per100g':i['per100g']} for i in result['items'][:10]]})
  reference={'date':body.get('context',{}).get('date'),'result':result,'confirmed':False}
  raw=json.dumps(reference,ensure_ascii=False)
  if len(raw)>6000:return
  with self.db() as db:
   if body.get('_memoryEpoch')!=db.execute('SELECT value FROM memory_epoch').fetchone()[0]:return
   db.execute('INSERT INTO food_references(route,payload) VALUES(?,?)',(route,raw))
   db.execute('DELETE FROM food_references WHERE id NOT IN (SELECT id FROM food_references ORDER BY id DESC LIMIT 8)')
