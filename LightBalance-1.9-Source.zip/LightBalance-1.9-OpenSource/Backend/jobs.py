"""Single-owner durable inference queue. No logging of prompts or credentials."""
import hashlib,json,sqlite3,threading,time,uuid
from pathlib import Path
from contextlib import contextmanager

class QueueFull(ValueError):pass
class JobStore:
 def __init__(self,path,execute):
  self.path=str(path);self.execute=execute;self.wake=threading.Event();self.stop=threading.Event()
  Path(path).parent.mkdir(parents=True,exist_ok=True)
  with self.db() as db:
   db.execute('CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,route TEXT,hash TEXT,payload TEXT,state TEXT,result TEXT,error TEXT,created REAL)')
   # A server crash leaves uncertain upstream work. Never automatically bill again.
   db.execute("UPDATE jobs SET state='failed',payload=NULL,error='服务器重启时分析中断；未自动重新调用模型。' WHERE state='running'")
  Path(path).chmod(0o600)
 @contextmanager
 def db(self):
  connection=sqlite3.connect(self.path,timeout=15)
  try:
   with connection:yield connection
  finally:connection.close()
 def submit(self,id,route,body):
  if not isinstance(id,str):raise ValueError('invalid_job_id')
  if str(uuid.UUID(id))!=id:raise ValueError('invalid_job_id')
  payload=json.dumps(body,sort_keys=True,ensure_ascii=False,allow_nan=False);digest=hashlib.sha256((route+payload).encode()).hexdigest()
  with self.db() as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT hash FROM jobs WHERE id=?',(id,)).fetchone()
   if row:
    if row[0]!=digest:raise ValueError('job_id_conflict')
   else:
    if db.execute("SELECT count(*) FROM jobs WHERE state IN ('queued','running')").fetchone()[0]>=8:raise QueueFull('任务较多，请稍后再提交。')
    db.execute('INSERT INTO jobs VALUES(?,?,?,?,?,NULL,NULL,?)',(id,route,digest,payload,'queued',time.time()))
  self.wake.set();return self.get(id)
 def clear_pending_memory(self):
  with self.db() as db:
   db.execute('BEGIN IMMEDIATE')
   for id,raw in db.execute("SELECT id,payload FROM jobs WHERE state='queued'").fetchall():
    body=json.loads(raw);body['memoryEnabled']=False
    db.execute('UPDATE jobs SET payload=? WHERE id=?',(json.dumps(body,ensure_ascii=False),id))
 def get(self,id):
  with self.db() as db:row=db.execute('SELECT state,result,error FROM jobs WHERE id=?',(id,)).fetchone()
  if not row:return None
  return {'id':id,'state':row[0],'result':json.loads(row[1]) if row[1] else None,'error':row[2]}
 def step(self):
  with self.db() as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute("SELECT id,route,payload FROM jobs WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
   if not row:return False
   db.execute("UPDATE jobs SET state='running' WHERE id=?",(row[0],))
  try:
   result=self.execute(row[1],json.loads(row[2]));result=json.dumps(result,ensure_ascii=False,allow_nan=False);state='completed';error=None
  except Exception as exc:
   result=None;state='failed';error=str(exc) if getattr(exc,'public',False) else '分析未完成，请稍后重新提交。'
  with self.db() as db:db.execute('UPDATE jobs SET state=?,result=?,error=?,payload=NULL WHERE id=?',(state,result,error,row[0]))
  return True
 def start(self):
  def run():
   while not self.stop.is_set():
    if not self.step():self.wake.wait(2);self.wake.clear()
  self.thread=threading.Thread(target=run,daemon=True);self.thread.start()
 def close(self):self.stop.set();self.wake.set();self.thread.join(timeout=5)
