import SwiftUI
import Charts
import PhotosUI

extension Color {
    static let forest = Color(red: 0.15, green: 0.32, blue: 0.26)
    static let canvas = Color(red: 0.96, green: 0.96, blue: 0.93)
    static let lime = Color(red: 0.82, green: 0.91, blue: 0.63)
    static let ink = Color(red: 0.16, green: 0.21, blue: 0.19)
}
func number(_ value: Double) -> String { value.formatted(.number.grouping(.never).precision(.fractionLength(0...1)).locale(Locale(identifier: "en_US_POSIX"))) }

struct Panel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View { VStack(alignment: .leading, spacing: 16) { content }.padding(20).frame(maxWidth: .infinity, alignment: .leading).background(.white, in: RoundedRectangle(cornerRadius: 24)) }
}
struct SectionLabel: View {
    var title: String
    var subtitle: String = ""
    var body: some View {
        HStack { Text(title).font(.title3.bold()); Spacer(); Text(subtitle).font(.caption).foregroundStyle(.secondary) }
    }
}
struct EmptyHint: View {
    var icon: String
    var title: String
    var detail: String
    var body: some View {
        VStack(spacing: 10) { Image(systemName: icon).font(.system(size: 30)).foregroundStyle(Color.forest); Text(title).font(.headline); Text(detail).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center) }.frame(maxWidth: .infinity).padding(.vertical, 24)
    }
}
struct ContentView: View {
    @EnvironmentObject var store: AppStore
    @State private var settings = false
    @State private var showingStorageError = false
    @State private var onboarding = false
    var body: some View {
        TabView {
            shell(title: "轻衡", subtitle: "吃得从容，练得扎实。") { TodayView() }.tabItem { Label("今天", systemImage: "sun.max") }
            shell(title: "饮食", subtitle: "每一餐，都是向目标靠近。") { MealsView() }.tabItem { Label("饮食", systemImage: "fork.knife") }
            shell(title: "训练", subtitle: "保住力量，也保住好状态。") { TrainingView() }.tabItem { Label("训练", systemImage: "dumbbell") }
            shell(title: "趋势", subtitle: "看见变化，不被一天的数字左右。") { TrendsView() }.tabItem { Label("趋势", systemImage: "chart.xyaxis.line") }
        }.tint(.forest).foregroundStyle(Color.ink)
        .sheet(isPresented: $settings) { SettingsView() }
        .onAppear { showingStorageError = store.storageError != nil; onboarding = store.needsOnboarding && store.storageError == nil }
        .fullScreenCover(isPresented:$onboarding){NavigationStack { PersonalPlanView(onboarding:true) }.interactiveDismissDisabled()}
        .onChange(of: store.storageError) { _, value in showingStorageError = value != nil }
        .alert("存储异常", isPresented: $showingStorageError) { Button("知道了", role: .cancel) {} } message: { Text(store.storageError ?? "") }
    }
    func shell<V: View>(title: String, subtitle: String, @ViewBuilder content: () -> V) -> some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(alignment: .top) {
                        Text(title).font(.largeTitle.bold())
                        Spacer()
                        NavigationLink {AIWorkView()} label:{Image(systemName:"sparkles").padding(10)}.accessibilityLabel("AI 任务与记忆")
                        Button { settings = true } label: { Image(systemName: "slider.horizontal.3").padding(13).background(.white, in: Circle()) }.accessibilityLabel("计划与设置")
                    }
                    HStack {
                        let day = Plan.cycleDay(store.selectedDate, start: store.data.startDate)
                        Text(day < 1 ? "周期前" : day > 28 ? "第 \(day) 天 · 持续记录" : "DAY \(day) / 28").font(.caption.bold()).tracking(1.5)
                        Spacer()
                        DatePicker("记录日期", selection: $store.selectedDate, in: ...Date(), displayedComponents: .date).labelsHidden().datePickerStyle(.compact)
                    }
                    content()
                }.padding(20).frame(maxWidth: 600).frame(maxWidth: .infinity)
            }.background(Color.canvas).toolbar(.hidden, for: .navigationBar)
        }
    }
}
struct TodayView: View {
    @EnvironmentObject var store: AppStore
    @State private var modeSheet = false
    @State private var mealSheet = false
    @State private var bodySheet = false
    var body: some View {
        let day = store.day
        let target = store.target(day.mode)
        VStack(spacing: 20) {
            VStack(alignment: .leading, spacing: 24) {
                HStack {
                    Label(store.data.modeTitle(day.mode), systemImage: day.mode.symbol).font(.headline)
                    Spacer()
                    Button { modeSheet = true } label: { HStack(spacing: 4) { Text("计划变了"); Image(systemName: "arrow.triangle.2.circlepath") }.font(.caption.bold()).padding(10).foregroundStyle(.white).background(.white.opacity(0.13), in: Capsule()) }
                }
                HStack(spacing: 24) {
                    ZStack {
                        Circle().stroke(.white.opacity(0.15), lineWidth: 11)
                        Circle().trim(from: 0, to: min(1, day.total.calories / target.calories)).stroke(Color.lime, style: StrokeStyle(lineWidth: 11, lineCap: .round)).rotationEffect(.degrees(-90))
                        VStack(spacing: 3) { Text(number(day.total.calories)).font(.system(size: 36, weight: .medium, design: .rounded)); Text("已摄入 kcal").font(.caption).foregroundStyle(.white.opacity(0.7)) }
                    }.frame(width: 140, height: 140).accessibilityElement(children: .combine)
                    VStack(alignment: .leading, spacing: 7) {
                        Text(target.calories == 0 ? "尚未建立目标" : day.total.calories > target.calories ? "超出参考目标" : "今日剩余").font(.caption).foregroundStyle(.white.opacity(0.7))
                        Text(target.calories == 0 ? "—" : number(abs(target.calories - day.total.calories))).font(.system(size: 34, weight: .semibold, design: .rounded))
                        Text("kcal / 目标 \(number(target.calories))").font(.caption)
                        Text(day.mode.subtitle).font(.caption).padding(.horizontal, 10).padding(.vertical, 6).background(.white.opacity(0.12), in: Capsule())
                    }
                }
                HStack { macro("蛋白质", value: day.total.protein, target: target.protein); Spacer(); macro("碳水", value: day.total.carbs, target: target.carbs); Spacer(); macro("脂肪", value: day.total.fat, target: target.fat) }
            }.padding(24).foregroundStyle(.white).background(LinearGradient(colors: [.forest, Color(red: 0.22, green: 0.43, blue: 0.35)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
            Panel {
                Label("下一餐，怎么安排", systemImage: "sparkles").font(.headline).foregroundStyle(Color.forest)
                Text(nextMeal(day)).font(.subheadline).lineSpacing(5)
                Text("已记录的餐食不会因切换日型而改变。").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 12) {
                Button { mealSheet = true } label: { Label("记录一餐", systemImage: "plus").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 18).background(Color.forest, in: RoundedRectangle(cornerRadius: 18)).foregroundStyle(.white) }
                Button { bodySheet = true } label: { Label("身体记录", systemImage: "scalemass").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 18).background(.white, in: RoundedRectangle(cornerRadius: 18)) }
            }
            Panel {
                SectionLabel(title: "今日节奏", subtitle: store.data.personalProfile == nil ? "8000–10000 步" : "按个人安排")
                HStack { stat("体重", value: day.weight.map { number($0) + " kg" } ?? "待记录"); Spacer(); stat("步数", value: day.steps.map(String.init) ?? "待记录"); Spacer(); stat("训练", value: "\(day.workouts.filter(\.countsForSummary).count) 次") }
                Divider()
                Text("\(day.meals.count) 餐已记录 · 蛋白质还需 \(number(Plan.remaining(target.protein, eaten: day.total.protein))) g").font(.subheadline).foregroundStyle(.secondary)
            }
            WeekBudgetView()
        }.sheet(isPresented: $modeSheet) { ModeView() }.sheet(isPresented: $mealSheet) { MealEditor() }.sheet(isPresented: $bodySheet) { BodyEditor() }
    }
    func macro(_ title: String, value: Double, target: Double) -> some View {
        VStack(alignment: .leading, spacing: 7) { Text(title).font(.caption).foregroundStyle(.white.opacity(0.7)); Text("\(number(value))").font(.headline) + Text(target > 0 ? " / \(number(target)) g" : " g").font(.caption) }
    }
    func stat(_ title: String, value: String) -> some View { VStack(alignment: .leading, spacing: 8) { Text(title).font(.caption).foregroundStyle(.secondary); Text(value).font(.headline) } }
    func nextMeal(_ day: DayRecord) -> String {
        guard store.target(day.mode).calories > 0 else { return "尚未建立饮食目标，可以先记录真实摄入，再在设置中让模型建立个人计划。" }
        let protein = number(Plan.remaining(store.target(day.mode).protein, eaten: day.total.protein))
        if day.mode == .flexible { return "机动日优先保证蛋白质，还需约 \(protein) g。按你设置的餐数安排，记录真实摄入，周末再看整体预算。" }
        if day.total.calories >= store.target(day.mode).calories { return "今天已达到参考热量。下一餐按饥饿感正常吃，优先蛋白质和蔬菜；不要用挨饿补偿，看一周的整体趋势。" }
        return "剩余约 \(number(Plan.remaining(store.target(day.mode).calories, eaten: day.total.calories))) kcal；蛋白质还需 \(protein) g，碳水还剩约 \(number(Plan.remaining(store.target(day.mode).carbs, eaten: day.total.carbs))) g。\(day.mode == .low ? "蛋白质照常，主食适量。" : "把主食安排在训练前后那一餐。")"
    }
}
struct WeekBudgetView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        let dates = Plan.weekDates(containing: store.selectedDate, start: store.data.startDate)
        let records = dates.map { store.record(for: $0) }
        let consumed = records.reduce(0) { $0 + $1.total.calories }
        Panel {
            SectionLabel(title: "本周预算", subtitle: "以 Day 1 起算")
            HStack(alignment: .firstTextBaseline) { Text(number(consumed)).font(.system(size: 28, weight: .semibold, design: .rounded)); Text("/ \(number(store.data.weeklyBudget)) kcal").font(.subheadline).foregroundStyle(.secondary) }
            if store.data.weeklyBudget > 0 { ProgressView(value: min(consumed / store.data.weeklyBudget, 1)).tint(.forest) } else { Text("尚未建立周预算，先记录实际摄入。").font(.caption) }
            HStack(spacing: 0) {
                ForEach(dates, id: \.self) { date in
                    let record = store.record(for: date)
                    VStack(spacing: 7) { Image(systemName: record.mode.symbol).font(.caption).frame(width: 30, height: 30).background(record.hasData ? Color.lime : Color.canvas, in: Circle()); Text(date.formatted(.dateTime.weekday(.narrow))).font(.caption2).foregroundStyle(.secondary) }.frame(maxWidth: .infinity)
                }
            }
            Text("\(records.filter { !$0.meals.isEmpty }.count) / 7 天有饮食记录 · 未记录不代表零摄入").font(.caption).foregroundStyle(.secondary)
        }
    }
}
struct ModeView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack { List {
            Section { Text("跟着实际安排走。切换后，只更新目标和剩余额度，保留已经吃下的每一餐。").font(.subheadline).foregroundStyle(.secondary) }
            ForEach(DayMode.allCases) { mode in
                Button { store.update { $0.mode = mode }; dismiss() } label: {
                    HStack(spacing: 14) { Image(systemName: mode.symbol).frame(width: 24); VStack(alignment: .leading, spacing: 6) { Text(store.data.modeTitle(mode) + " · " + mode.subtitle).font(.headline); Text(store.targetText(mode)).font(.caption).foregroundStyle(.secondary) }; Spacer(); if store.day.mode == mode { Image(systemName: "checkmark.circle.fill") } }.padding(.vertical, 10)
                }
            }
        }.navigationTitle("今天的安排").toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }.tint(.forest) }
    }
}
struct MealsView: View {
    @EnvironmentObject var store: AppStore
    @State private var adding = false
    @State private var editing: Meal?
    var body: some View {
        VStack(spacing: 20) {
            Panel {
                SectionLabel(title: store.data.modeTitle(store.day.mode), subtitle: "每日计划 \(store.data.mealsPerDay ?? 2) 餐 · 可另记加餐")
                Text(store.targetText(store.day.mode)).font(.subheadline).foregroundStyle(.secondary)
                HStack { Label("\(number(store.day.total.calories)) kcal", systemImage: "flame"); Spacer(); Text("蛋白质 \(number(store.day.total.protein)) g") }.font(.headline)
            }
            NavigationLink { FoodChatView() } label: { Label("余额怎么吃 · AI 聊天", systemImage: "bubble.left.and.bubble.right").font(.headline) }
            Button { adding = true } label: { Label("记录餐食与照片", systemImage: "plus.circle.fill").font(.headline).frame(maxWidth: .infinity).padding(18).background(Color.forest, in: RoundedRectangle(cornerRadius: 18)).foregroundStyle(.white) }
            if store.day.meals.isEmpty { Panel { EmptyHint(icon: "fork.knife", title: "从今天的第一餐开始", detail: "记录食物、营养估算值和照片\n午餐、晚餐，也可以加一份加餐") } }
            ForEach(store.day.meals) { meal in
                Button { editing = meal } label: { Panel {
                    HStack(alignment: .top) {
                        if let photo = meal.photo, let image = UIImage(data: photo) { Image(uiImage: image).resizable().scaledToFill().frame(width: 72, height: 72).clipShape(RoundedRectangle(cornerRadius: 15)) }
                        VStack(alignment: .leading, spacing: 7) { Text(meal.kind).font(.caption).foregroundStyle(.secondary); Text(meal.name).font(.headline); Text("\(number(meal.nutrition.calories)) kcal").font(.title3.bold()).foregroundStyle(Color.forest) }
                        Spacer(); Label("编辑",systemImage:"pencil").font(.caption.bold()).foregroundStyle(Color.forest)
                    }
                    HStack { Text("蛋白质 \(number(meal.nutrition.protein)) g"); Spacer(); Text("碳水 \(number(meal.nutrition.carbs)) g"); Spacer(); Text("脂肪 \(number(meal.nutrition.fat)) g") }.font(.caption).foregroundStyle(.secondary)
                    if let lower = meal.lower, let upper = meal.upper { Text("估算区间 \(number(lower))–\(number(upper)) kcal").font(.caption).foregroundStyle(.secondary) }
                    if !meal.note.isEmpty { Text(meal.note).font(.caption).foregroundStyle(.secondary) }
                } }.buttonStyle(.plain)
            }
            Text("照片用于回看与校准。营养值由你填写或确认，烹调用油、酱料与份量会影响估算。").font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)
        }.sheet(isPresented: $adding) { MealEditor() }.sheet(item: $editing) { MealEditor(meal: $0) }
    }
}
struct MealEditor: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    var meal: Meal?
    @State private var kind = ""
    @State private var name = ""
    @State private var calories = ""
    @State private var protein = ""
    @State private var carbs = ""
    @State private var fat = ""
    @State private var lower = ""
    @State private var upper = ""
    @State private var note = ""
    @State private var photos: [FoodPhoto] = []
    @State private var foodSelection: [PhotosPickerItem] = []
    @State private var labelSelection: [PhotosPickerItem] = []
    @State private var showCamera = false
    @State private var cameraRole = "food"
    @State private var photoError: String?
    @State private var confirmUpload = false
    @ObservedObject private var ai=AIWorkCenter.shared
    @State private var showPreviousAnalysis=false
    var isAnalyzing:Bool {ai.active(draftKey)}
    @State private var preview: FoodPreview?
    @State private var grams: [String] = []
    @State private var adopted = false
    @State private var analysisError: String?
    @State private var initialized = false
    @State private var restoring = false
    @State private var finished = false
    @State private var requestID = UUID()
    var draftKey: String { "meal-"+DraftStorage.dayKey(store.selectedDate)+"-"+(meal?.id.uuidString ?? "new") }
    var draftSnapshot: MealDraft { .init(fields:["kind":kind,"name":name,"calories":calories,"protein":protein,"carbs":carbs,"fat":fat,"lower":lower,"upper":upper,"note":note],photos:photos,preview:preview,grams:grams,adopted:adopted) }
    func persistDraft() { guard initialized,!restoring,!finished else{return};do{try DraftStorage.save(draftSnapshot,key:draftKey)}catch{photoError="草稿未能保存："+error.localizedDescription} }
    func restore(_ draft:MealDraft){restoring=true;let f=draft.fields;kind=f["kind"] ?? "午餐";name=f["name"] ?? "";calories=f["calories"] ?? "";protein=f["protein"] ?? "";carbs=f["carbs"] ?? "";fat=f["fat"] ?? "";lower=f["lower"] ?? "";upper=f["upper"] ?? "";note=f["note"] ?? "";photos=draft.photos;preview=draft.preview;grams=draft.grams;adopted=draft.adopted;if !adopted,lower.isEmpty,upper.isEmpty,let range=preview?.intakeRange(grams:grams){lower=number(range.0);upper=number(range.1)};DispatchQueue.main.async{restoring=false} }

    var valid: Bool {
        !kind.isEmpty && !name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && [calories,protein,carbs,fat].allSatisfy { validNumber($0).map{$0<=20000} == true } &&
        IntakeRange.valid(lower:lower,upper:upper,calories:Double(calories) ?? 0) && (preview == nil || (adopted && validAmounts))
    }
    var actualTotal: Nutrition {
        guard let preview,grams.count == preview.items.count else{return Nutrition()}
        return preview.items.indices.reduce(Nutrition()){ $0+preview.items[$1].nutrition(grams:Double(grams[$1]) ?? 0) }
    }
    var validAmounts: Bool { !grams.isEmpty && grams.allSatisfy{validNumber($0).map{$0<=5000} == true} && actualTotal.calories>0 && actualTotal.calories<=20000 }
    var body: some View {
        NavigationStack { Form {
            mealSelection
            mealReference
            photoAnalysis
            portionSections
            intakeSection
            rangeSection
        }.navigationTitle(meal == nil ? "餐前分析与摄入" : "编辑实际摄入").navigationBarTitleDisplayMode(.inline)
            .toolbar{ToolbarItem(placement:.cancellationAction){Button("取消"){dismiss()}};ToolbarItem(placement:.confirmationAction){Button("确认摄入并保存"){save()}.disabled(!valid || isAnalyzing)}}
        }.tint(.forest).keyboardDone()
            .alert("发送照片与本日饮食参考数据？",isPresented:$confirmUpload){Button("取消",role:.cancel){};Button("发送并分析"){analyze()}}message:{Text(FoodService.consent)}
            .sheet(isPresented:$showCamera){CameraPhotoPicker{image in append(image,role:cameraRole)}}
            .onChange(of:ai.revision){_,_ in refreshAnalysis()}
            .alert("载入上次分析？",isPresented:$showPreviousAnalysis){Button("取消",role:.cancel){};Button("载入"){loadAnalysis()}}message:{Text("结果基于当时的照片和备注。若已更换食物，请重新分析；实际摄入仍需确认。")}
            .onDisappear{persistDraft()}
             .onChange(of:kind){old,new in if initialized && !restoring && old != new && preview != nil{invalidate()}}
            .onChange(of:grams){_,_ in if initialized,!restoring,let preview,adopted,validAmounts{adopt(preview)}}
            .onChange(of:DraftStorage.encoded(draftSnapshot)){_,_ in persistDraft()}
            .onAppear{ai.attach(store);guard !initialized else{return};initialized=true;if let cached=DraftStorage.load(MealDraft.self,key:draftKey){restore(cached);return};restoring=true;DispatchQueue.main.async{restoring=false};if let meal{kind=meal.kind;name=meal.name;calories=number(meal.nutrition.calories);protein=number(meal.nutrition.protein);carbs=number(meal.nutrition.carbs);fat=number(meal.nutrition.fat);lower=meal.lower.map(number) ?? "";upper=meal.upper.map(number) ?? "";note=meal.note;if let raw=meal.analysisData,let result=try? JSONDecoder().decode(FoodPreview.self,from:raw).validated(),let amounts=meal.actualGrams,amounts.count==result.items.count{preview=result;grams=amounts;adopted=true};if let photo=meal.photo{photos=[FoodPhoto(data:photo,role:"food")]};for (i,data) in (meal.extraPhotos ?? []).enumerated(){photos.append(FoodPhoto(data:data,role:(meal.extraPhotoRoles ?? []).indices.contains(i) ? meal.extraPhotoRoles![i] : "food"))}}}
            .task(id:foodSelection){await load(foodSelection,role:"food");foodSelection=[]}
            .task(id:labelSelection){await load(labelSelection,role:"label");labelSelection=[]}
    }

    @ViewBuilder var mealSelection:some View {
            Section("先选择餐次") {
                Picker("本次记录",selection:$kind){Text("请选择").tag("");ForEach(["早餐","午餐","晚餐","加餐","饮品","其他"],id:\.self){Text($0).tag($0)}}
                if kind.isEmpty{Text("先选餐次，再添加照片或手动填写。").font(.caption).foregroundStyle(.secondary)}
            }
    }
    @ViewBuilder var mealReference:some View {
            Section(kind == "饮品" ? "饮品摄入参考" : "吃之前 · 先看份量") {
                let context=FoodContext.make(data:store.data,day:store.day,excluding:meal?.id,mealKind:kind)
                (Text((context["mealReferenceCalories"] as? Double).map { "本餐参考 "+number($0)+" kcal" } ?? (["饮品","加餐","其他"].contains(kind) ? "按全天余额参考，不分配正餐额度" : "尚未建立本餐参考额度")) + Text(" · 每日计划 \(store.data.mealsPerDay ?? 2) 餐")).font(.caption).foregroundStyle(.secondary)
                Text("参考额度，不要求吃满；确认实际份量后才记账。").font(.caption).foregroundStyle(.secondary)
            }
    }
    @ViewBuilder var photoAnalysis:some View {
            Section("食物与营养标签 · 最多6张") {
                ForEach(photos) { image in
                    HStack { if let ui=UIImage(data:image.data){Image(uiImage:ui).resizable().scaledToFit().frame(width:90,height:90)};Text(image.role=="food" ? "待吃食物" : "营养成分表");Spacer();Button(role:.destructive){photos.removeAll{$0.id==image.id};invalidate()} label:{Image(systemName:"trash")} }
                }
                PhotosPicker(selection:$foodSelection,maxSelectionCount:6,matching:.images){Label("添加待吃食物照片",systemImage:"photo.on.rectangle")}.disabled(kind.isEmpty || photos.count>=6)
                PhotosPicker(selection:$labelSelection,maxSelectionCount:6,matching:.images){Label("添加营养成分表",systemImage:"doc.text.viewfinder")}.disabled(kind.isEmpty || photos.count>=6)
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    Button{cameraRole="food";showCamera=true}label:{Label("拍摄食物",systemImage:"camera.fill")}.disabled(kind.isEmpty || photos.count>=6)
                    Button{cameraRole="label";showCamera=true}label:{Label("拍摄营养标签",systemImage:"viewfinder")}.disabled(kind.isEmpty || photos.count>=6)
                }
                TextField("份量、油酱、标签对应食物、过敏或偏好",text:$note,axis:.vertical).onChange(of:note){_,_ in if initialized && !restoring { invalidate() }}
                if let photoError{Text(photoError).foregroundStyle(.red).font(.caption)}
                Button{confirmUpload=true}label:{if isAnalyzing{ProgressView("正在分析餐前份量…")}else{Label("计算热量并建议吃多少",systemImage:"sparkles")}}.disabled(kind.isEmpty || !photos.contains{$0.role=="food"} || isAnalyzing)
                if ai.latest(draftKey)?.result != nil {Button("载入上次分析结果"){showPreviousAnalysis=true}}
                NavigationLink("AI 任务与饮食记忆"){AIWorkView()}
                NavigationLink("识别与模型配置"){VisionSettingsView()}
                if let analysisError{Text(analysisError).foregroundStyle(.red).font(.caption)}
            }
    }
    @ViewBuilder var portionSections:some View {
            if let preview {
                Section("餐前分析 · 尚未记账") {
                    Text(preview.assessmentText).font(.headline)
                    Text("全部现有食物约 \(number(preview.availableTotal.calories)) kcal")
                    if let range=preview.intakeRange(grams:preview.items.map{number($0.availableGrams)}) {Text("估算范围 \(number(range.0))–\(number(range.1)) kcal").font(.caption)}
                    Text(preview.explanation)
                    Text(preview.uncertainty).font(.caption).foregroundStyle(.secondary)
                }
                Section("核对你实际吃下的部分") {
                    Button("按建议份量预填 · 仍需核对实际摄入") { grams = preview.items.map { number($0.recommendedGrams) }; adopted = false }
                    ForEach(preview.items.indices,id:\.self){i in
                        VStack(alignment:.leading,spacing:6){
                            Text(preview.items[i].name+(preview.items[i].available ? "" : " · 建议另备")).font(.headline)
                            Text("现有约 \(number(preview.items[i].availableGrams)) g；建议 \(number(preview.items[i].recommendedGrams)) g").font(.caption)
                            Text(preview.items[i].note).font(.caption).foregroundStyle(.secondary)
                            HStack{Text("实际吃了 g");TextField("0 = 未吃",text:Binding(get:{grams.indices.contains(i) ? grams[i] : "0"},set:{if grams.indices.contains(i){grams[i]=$0}})).keyboardType(.decimalPad).multilineTextAlignment(.trailing)}
                        }
                    }
                    Text("未吃的项目改为0，补充食物只有实际吃了才填写。克数和营养为估计，可依据称重或标签修正。").font(.caption)
                    Text("实际部分合计约 \(number(actualTotal.calories)) kcal · 蛋白质 \(number(actualTotal.protein)) g")
                    Button("确认实际份量，填入摄入表单"){adopt(preview)}.disabled(!validAmounts)
                }
            }
    }
    @ViewBuilder var intakeSection:some View {
            Section("实际摄入 · 可手动填写") {
                if preview != nil { Button("改为手动记录，不采用 AI 建议") { invalidate() } }
                TextField("食物名称 / 内容",text:$name)
                numeric("热量 kcal",text:$calories);numeric("蛋白质 g",text:$protein);numeric("碳水 g",text:$carbs);numeric("脂肪 g",text:$fat)
            }
    }
    @ViewBuilder var rangeSection:some View {
            Section("可选 · 摄入估算区间"){
                numeric("最低 kcal",text:$lower,placeholder:"可留空");numeric("最高 kcal",text:$upper,placeholder:"可留空")
                if !lower.isEmpty || !upper.isEmpty { Button("清空区间"){lower="";upper=""} }
                Text("可留空；最低不得高于最高。AI 区间随确认的实际份量计算，属于估算。").font(.caption).foregroundStyle(.secondary)
                if !IntakeRange.valid(lower:lower,upper:upper,calories:Double(calories) ?? 0){Text("请输入有效非负数，最低不得高于最高（最多20000 kcal）。").font(.caption).foregroundStyle(.red)}
                if let low=Double(lower),let high=Double(upper),let value=Double(calories),(value<low || value>high){Text("表单热量在区间外，请核对；仍可保存。").font(.caption).foregroundStyle(.orange)}
                if preview != nil && !adopted { Text("请先确认上方实际份量，或选择手动记录，再保存。").font(.caption).foregroundStyle(.orange) }
            }
    }
    func invalidate(){requestID=UUID();preview=nil;grams=[];adopted=false;analysisError=nil}
    func append(_ image:UIImage,role:String){
        guard photos.count<6 else{photoError="最多6张照片，请先移除一张。";return}
        guard let jpeg=FoodImageEncoder.jpeg(image) else{photoError="无法处理照片，请重新拍摄。";return}
        photos.append(.init(data:jpeg,role:role));invalidate();photoError=nil
    }
    func load(_ items:[PhotosPickerItem],role:String) async {
        for item in items {guard !Task.isCancelled else{return};do{if let data=try await item.loadTransferable(type:Data.self),let image=UIImage(data:data){append(image,role:role)}else{photoError="无法读取照片。"}}catch{photoError="照片读取失败，请重试。"}}
    }
    func analyze(){
        let images=photos;let sentNote=note;let context=FoodContext.make(data:store.data,day:store.day,excluding:meal?.id,mealKind:kind)
        invalidate();persistDraft();ai.attach(store)
        ai.start(key:draftKey,title:"餐前分析 · "+store.selectedDate.formatted(date:.abbreviated,time:.omitted),kind:"meal",date:store.selectedDate,signature:AIInputSignature.make(draftSnapshot)){try JSONEncoder().encode(await FoodService.preview(images:images,note:sentNote,context:context))}
    }
    func loadAnalysis(){guard let raw=ai.latest(draftKey)?.result,let result=try? JSONDecoder().decode(FoodPreview.self,from:raw).validated() else{return};preview=result;grams=result.items.map{number($0.recommendedGrams)};if let range=result.intakeRange(grams:grams){lower=number(range.0);upper=number(range.1)};adopted=false;persistDraft()}
    func refreshAnalysis(){
        guard initialized,let job=ai.latest(draftKey) else{return}
        if job.state=="failed"{analysisError=job.error}
        if job.delivered,let cached=DraftStorage.load(MealDraft.self,key:draftKey),cached.fields==draftSnapshot.fields,cached.photos.map(\.id)==photos.map(\.id),preview==nil {restore(cached)}
    }
    func adopt(_ preview:FoodPreview){let total=actualTotal;name=preview.name;calories=number(total.calories);protein=number(total.protein);carbs=number(total.carbs);fat=number(total.fat);if let range=preview.intakeRange(grams:grams){lower=number(range.0);upper=number(range.1)}else{lower="";upper=""};adopted=true}
    func numeric(_ label:String,text:Binding<String>,placeholder:String="0")->some View{HStack{Text(label);TextField(placeholder,text:text).keyboardType(.decimalPad).multilineTextAlignment(.trailing)}}
    func save(){
        guard valid else{return}
        let first=photos.firstIndex{$0.role=="food"};let main=first.map{photos[$0].data};let extra=photos.enumerated().filter{$0.offset != first}.map(\.element)
        let detail=note
        let next=Meal(id:meal?.id ?? UUID(),kind:kind,name:name,nutrition:Nutrition(calories:Double(calories)!,protein:Double(protein)!,fat:Double(fat)!,carbs:Double(carbs)!),lower:Double(lower.trimmingCharacters(in:.whitespacesAndNewlines)),upper:Double(upper.trimmingCharacters(in:.whitespacesAndNewlines)),note:detail,photo:main,extraPhotos:extra.isEmpty ? nil : extra.map(\.data),extraPhotoRoles:extra.isEmpty ? nil : extra.map(\.role),analysisData:adopted ? preview.flatMap{try? JSONEncoder().encode($0)} : nil,actualGrams:adopted ? grams : nil)
        store.update{day in if let i=day.meals.firstIndex(where:{$0.id==next.id}){day.meals[i]=next}else{day.meals.append(next)}}
        if store.storageError==nil{finished=true;DraftStorage.remove(draftKey);dismiss()}
    }
}
func validNumber(_ text: String) -> Double? { guard let value = Double(text), value.isFinite, value >= 0 else { return nil }; return value }
