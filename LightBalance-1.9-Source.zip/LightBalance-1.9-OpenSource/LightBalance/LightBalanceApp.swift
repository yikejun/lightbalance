import SwiftUI

@main struct LightBalanceApp: App {
    @StateObject private var store = AppStore()
    @ObservedObject private var ai=AIWorkCenter.shared
    @Environment(\.scenePhase) private var scenePhase
    init(){
        #if !LIGHTBALANCE_USER_API
        UserDefaults.standard.register(defaults:["foodMemoryEnabled":true])
        #endif
    }
    var body: some Scene {
        WindowGroup { ContentView().environmentObject(store).preferredColorScheme(.light).buttonStyle(ActionButtonStyle())
                .task(id: store.syncRevision) {
                    guard store.data.weeklyCoachEnabled == true else { return }
                    do { try await Task.sleep(nanoseconds: 1_000_000_000); try Task.checkCancellation(); try await WeeklyService.sync(store.data) } catch { /* The weekly page exposes sync status and supports retry. */ }
                }
                .task(id: scenePhase) {
                    if scenePhase == .active {ai.attach(store)}
                    guard scenePhase == .active, store.data.healthAccessRequested == true, HealthKitReader.available, Date().timeIntervalSince(store.data.healthCache?.refreshedAt ?? .distantPast) > 60 else { return }
                    do { let cache = try await HealthKitReader().fetch(sleepSource: store.data.healthSleepSource); store.saveHealthCache(cache) } catch { /* Explicit health refresh shows detailed errors. */ }
                }
                .onAppear {
                    #if targetEnvironment(macCatalyst)
                    for scene in UIApplication.shared.connectedScenes {
                        if let windowScene = scene as? UIWindowScene {
                            windowScene.sizeRestrictions?.minimumSize = CGSize(width: 390, height: 700)
                            windowScene.sizeRestrictions?.maximumSize = CGSize(width: 540, height: 960)
                        }
                    }
                    #endif
                } }
    }
}
