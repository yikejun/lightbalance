import Foundation

struct ExerciseDefinition: Identifiable {
    var name: String
    var muscle: String
    var pattern: String
    var equipment: String
    var timed: Bool = false
    var advanced: Bool = false
    var id: String { name }
}
struct PlannedExercise: Codable, Identifiable {
    var id = UUID()
    var name: String
    var sets: Int = 3
    var reps: Int = 10
}
struct TrainingPlan: Codable, Identifiable {
    var id = UUID()
    var name: String
    var exercises: [PlannedExercise]
}
enum ExerciseLibrary {
    static let all: [ExerciseDefinition] = [
        .init(name: "杠铃卧推", muscle: "胸", pattern: "水平推", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "上斜杠铃卧推", muscle: "胸", pattern: "水平推", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "下斜杠铃卧推", muscle: "胸", pattern: "水平推", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "窄握杠铃卧推", muscle: "胸", pattern: "水平推", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "哑铃卧推", muscle: "胸", pattern: "水平推", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "上斜哑铃卧推", muscle: "胸", pattern: "水平推", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "下斜哑铃卧推", muscle: "胸", pattern: "水平推", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "哑铃地板卧推", muscle: "胸", pattern: "水平推", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "哑铃挤压卧推", muscle: "胸", pattern: "水平推", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "哑铃飞鸟", muscle: "胸", pattern: "孤立", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "上斜哑铃飞鸟", muscle: "胸", pattern: "孤立", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "坐姿推胸", muscle: "胸", pattern: "水平推", equipment: "器械", timed: false, advanced: false),
        .init(name: "上斜推胸机", muscle: "胸", pattern: "水平推", equipment: "器械", timed: false, advanced: false),
        .init(name: "史密斯卧推", muscle: "胸", pattern: "水平推", equipment: "器械", timed: false, advanced: false),
        .init(name: "史密斯上斜卧推", muscle: "胸", pattern: "水平推", equipment: "器械", timed: false, advanced: false),
        .init(name: "绳索夹胸", muscle: "胸", pattern: "孤立", equipment: "绳索 / 弹力带", timed: false, advanced: false),
        .init(name: "高位绳索夹胸", muscle: "胸", pattern: "孤立", equipment: "绳索 / 弹力带", timed: false, advanced: false),
        .init(name: "低位绳索夹胸", muscle: "胸", pattern: "孤立", equipment: "绳索 / 弹力带", timed: false, advanced: false),
        .init(name: "蝴蝶机夹胸", muscle: "胸", pattern: "孤立", equipment: "绳索 / 弹力带", timed: false, advanced: false),
        .init(name: "弹力带夹胸", muscle: "胸", pattern: "孤立", equipment: "绳索 / 弹力带", timed: false, advanced: false),
        .init(name: "标准俯卧撑", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "跪姿俯卧撑", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "上斜俯卧撑", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "下斜俯卧撑", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "宽距俯卧撑", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "双杠臂屈伸", muscle: "胸", pattern: "水平推", equipment: "自重", timed: false, advanced: false),
        .init(name: "高位下拉", muscle: "背", pattern: "垂直拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "窄握高位下拉", muscle: "背", pattern: "垂直拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "反握高位下拉", muscle: "背", pattern: "垂直拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "单臂高位下拉", muscle: "背", pattern: "垂直拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "辅助引体向上", muscle: "背", pattern: "垂直拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "正握引体向上", muscle: "背", pattern: "垂直拉", equipment: "自重", timed: false, advanced: false),
        .init(name: "反握引体向上", muscle: "背", pattern: "垂直拉", equipment: "自重", timed: false, advanced: false),
        .init(name: "中立握引体向上", muscle: "背", pattern: "垂直拉", equipment: "自重", timed: false, advanced: false),
        .init(name: "负重引体向上", muscle: "背", pattern: "垂直拉", equipment: "自重", timed: false, advanced: false),
        .init(name: "杠铃俯身划船", muscle: "背", pattern: "水平拉", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "潘德雷划船", muscle: "背", pattern: "水平拉", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "T杠划船", muscle: "背", pattern: "水平拉", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "反握杠铃划船", muscle: "背", pattern: "水平拉", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "单臂哑铃划船", muscle: "背", pattern: "水平拉", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "双臂哑铃划船", muscle: "背", pattern: "水平拉", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "胸托哑铃划船", muscle: "背", pattern: "水平拉", equipment: "哑铃", timed: false, advanced: false),
        .init(name: "坐姿绳索划船", muscle: "背", pattern: "水平拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "单臂绳索划船", muscle: "背", pattern: "水平拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "胸托划船机", muscle: "背", pattern: "水平拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "高位划船机", muscle: "背", pattern: "水平拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "低位划船机", muscle: "背", pattern: "水平拉", equipment: "器械", timed: false, advanced: false),
        .init(name: "反向划船", muscle: "背", pattern: "水平拉", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "悬吊划船", muscle: "背", pattern: "水平拉", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "弹力带划船", muscle: "背", pattern: "水平拉", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "弹力带下拉", muscle: "背", pattern: "水平拉", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "直臂下拉", muscle: "背", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "哑铃上拉", muscle: "背", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "背部伸展", muscle: "背", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "反向挺身", muscle: "背", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "站姿杠铃肩推", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "坐姿杠铃肩推", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "坐姿哑铃肩推", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "站姿哑铃肩推", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "阿诺德推举", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "单臂哑铃肩推", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "地雷杆推举", muscle: "肩", pattern: "垂直推", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "肩推机", muscle: "肩", pattern: "垂直推", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "史密斯肩推", muscle: "肩", pattern: "垂直推", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "弹力带肩推", muscle: "肩", pattern: "垂直推", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "派克俯卧撑", muscle: "肩", pattern: "垂直推", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "倒立俯卧撑", muscle: "肩", pattern: "垂直推", equipment: "器械 / 自重", timed: false, advanced: true),
        .init(name: "哑铃侧平举", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "绳索侧平举", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "侧平举机", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "弹力带侧平举", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "哑铃前平举", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "绳索前平举", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "俯身反向飞鸟", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "反向蝴蝶机", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "绳索反向飞鸟", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "面拉", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "弹力带拉开", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "肩袖外旋", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "肩袖内旋", muscle: "肩", pattern: "孤立", equipment: "哑铃 / 绳索", timed: false, advanced: false),
        .init(name: "杠铃背蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "杠铃前蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "泽奇深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "箱式深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "杠铃", timed: false, advanced: false),
        .init(name: "高脚杯深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "哑铃深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "保加利亚分腿蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "哑铃弓步蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "反向弓步蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "行走弓步蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "台阶上步", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "侧弓步", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "哑铃 / 壶铃", timed: false, advanced: false),
        .init(name: "腿举", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "器械", timed: false, advanced: false),
        .init(name: "哈克深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "器械", timed: false, advanced: false),
        .init(name: "史密斯深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "器械", timed: false, advanced: false),
        .init(name: "腰带深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "器械", timed: false, advanced: false),
        .init(name: "腿屈伸", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "器械", timed: false, advanced: false),
        .init(name: "自重深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: false),
        .init(name: "分腿蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: false),
        .init(name: "自重弓步蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: false),
        .init(name: "单腿坐站", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: false),
        .init(name: "手枪深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: true),
        .init(name: "靠墙静蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: true, advanced: false),
        .init(name: "西班牙深蹲", muscle: "腿前侧", pattern: "蹲 / 单腿", equipment: "自重", timed: false, advanced: false),
        .init(name: "传统硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "相扑硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "六角杠硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "罗马尼亚硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "哑铃罗马尼亚硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "单腿罗马尼亚硬拉", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "早安式", muscle: "腿后侧", pattern: "髋铰链", equipment: "杠铃 / 哑铃", timed: false, advanced: true),
        .init(name: "坐姿腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "俯卧腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "站姿腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "北欧腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: true),
        .init(name: "滑盘腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "健身球腿弯举", muscle: "腿后侧", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "杠铃臀推", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "臀推机", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "史密斯臀推", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "绳索后踢腿", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "绳索拉臀", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "髋外展机", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "髋内收机", muscle: "臀", pattern: "髋伸 / 外展", equipment: "杠铃 / 器械", timed: false, advanced: false),
        .init(name: "臀桥", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "单腿臀桥", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "弹力带臀桥", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "蚌式开合", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "侧卧抬腿", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "弹力带侧向走", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "四点跪姿后踢腿", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "消防栓式", muscle: "臀", pattern: "髋伸 / 外展", equipment: "自重 / 弹力带", timed: false, advanced: false),
        .init(name: "站姿提踵", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "坐姿提踵", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "腿举机提踵", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "单腿提踵", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "哑铃提踵", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "胫骨前肌抬脚", muscle: "小腿", pattern: "孤立", equipment: "器械 / 自重", timed: false, advanced: false),
        .init(name: "杠铃弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "EZ杠弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "哑铃交替弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "锤式弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "上斜哑铃弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "牧师凳弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "集中弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "反向弯举", muscle: "二头", pattern: "孤立", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "绳索弯举", muscle: "二头", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "绳索锤式弯举", muscle: "二头", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "高位绳索弯举", muscle: "二头", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "弯举机", muscle: "二头", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "弹力带弯举", muscle: "二头", pattern: "孤立", equipment: "绳索 / 器械", timed: false, advanced: false),
        .init(name: "仰卧臂屈伸", muscle: "三头", pattern: "孤立", equipment: "哑铃 / 杠铃", timed: false, advanced: false),
        .init(name: "哑铃颈后臂屈伸", muscle: "三头", pattern: "孤立", equipment: "哑铃 / 杠铃", timed: false, advanced: false),
        .init(name: "单臂哑铃颈后臂屈伸", muscle: "三头", pattern: "孤立", equipment: "哑铃 / 杠铃", timed: false, advanced: false),
        .init(name: "哑铃后踢", muscle: "三头", pattern: "孤立", equipment: "哑铃 / 杠铃", timed: false, advanced: false),
        .init(name: "EZ杠颈后臂屈伸", muscle: "三头", pattern: "孤立", equipment: "哑铃 / 杠铃", timed: false, advanced: false),
        .init(name: "绳索下压", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "直杆下压", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "反握下压", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "绳索过顶臂屈伸", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "弹力带下压", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "窄距俯卧撑", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "凳上臂屈伸", muscle: "三头", pattern: "孤立", equipment: "绳索 / 自重", timed: false, advanced: false),
        .init(name: "腕弯举", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "反向腕弯举", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "哑铃耸肩", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "杠铃耸肩", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "握力器", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: false, advanced: false),
        .init(name: "农夫行走", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: true, advanced: false),
        .init(name: "单侧提箱行走", muscle: "前臂 / 斜方肌", pattern: "孤立 / 搬运", equipment: "杠铃 / 哑铃", timed: true, advanced: false),
        .init(name: "平板支撑", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: true, advanced: false),
        .init(name: "侧平板支撑", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: true, advanced: false),
        .init(name: "死虫式", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "鸟狗式", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "卷腹", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "反向卷腹", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "仰卧抬腿", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "悬垂举膝", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "悬垂举腿", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "登山式", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "俄罗斯转体", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "仰卧交替触踝", muscle: "核心", pattern: "抗伸展 / 屈曲", equipment: "自重", timed: false, advanced: false),
        .init(name: "健腹轮", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: false, advanced: false),
        .init(name: "绳索卷腹", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: false, advanced: false),
        .init(name: "腹肌训练机", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: false, advanced: false),
        .init(name: "帕洛夫抗旋转推", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: true, advanced: false),
        .init(name: "绳索伐木", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: false, advanced: false),
        .init(name: "健身球平板支撑", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: true, advanced: false),
        .init(name: "哥本哈根侧支撑", muscle: "核心", pattern: "抗伸展 / 抗旋转", equipment: "器械 / 绳索", timed: true, advanced: false),
        .init(name: "壶铃摆动", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: false),
        .init(name: "壶铃高脚杯蹲推", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: false),
        .init(name: "土耳其起立", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "杠铃翻举", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "高翻", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "杠铃抓举", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "哑铃抓举", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "推举", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: true),
        .init(name: "杠铃蹲推", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: false, advanced: false),
        .init(name: "战绳", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: true, advanced: false),
        .init(name: "雪橇推", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: true, advanced: false),
        .init(name: "雪橇拉", muscle: "全身", pattern: "复合 / 爆发", equipment: "壶铃 / 杠铃", timed: true, advanced: false),
    ]
    static var muscles: [String] { Array(Set(all.map(\.muscle))).sorted() }
    static var equipment: [String] { Array(Set(all.map(\.equipment))).sorted() }
    static func find(_ name: String) -> ExerciseDefinition? { all.first { $0.name == name } }
    static let templates: [TrainingPlan] = [
        plan("全身 A · 器械优先", ["腿举", "坐姿推胸", "高位下拉", "坐姿绳索划船", "哑铃侧平举", "平板支撑"]),
        plan("全身 B · 哑铃 / 杠铃", ["罗马尼亚硬拉", "保加利亚分腿蹲", "上斜哑铃卧推", "单臂哑铃划船", "坐姿哑铃肩推", "锤式弯举"]),
        plan("上肢", ["哑铃卧推", "高位下拉", "坐姿绳索划船", "哑铃侧平举", "绳索弯举", "绳索下压"]),
        plan("下肢", ["高脚杯深蹲", "哑铃罗马尼亚硬拉", "腿举", "坐姿腿弯举", "杠铃臀推", "站姿提踵"]),
        plan("推 · 胸肩三头", ["杠铃卧推", "上斜哑铃卧推", "坐姿哑铃肩推", "哑铃侧平举", "绳索下压"]),
        plan("拉 · 背二头", ["高位下拉", "胸托哑铃划船", "坐姿绳索划船", "面拉", "哑铃交替弯举"]),
        plan("居家 · 自重 / 弹力带", ["自重深蹲", "标准俯卧撑", "弹力带划船", "单腿臀桥", "弹力带侧平举", "死虫式"]),
        plan("仅哑铃", ["高脚杯深蹲", "哑铃罗马尼亚硬拉", "哑铃卧推", "单臂哑铃划船", "哑铃侧平举", "哑铃提踵"])
    ]
    static func plan(_ name: String, _ exercises: [String]) -> TrainingPlan {
        TrainingPlan(name: name, exercises: exercises.map { PlannedExercise(name: $0, sets: 3, reps: find($0)?.timed == true ? 30 : 10) })
    }
}
enum TrainingAssessment {
    static func summary(records: [DayRecord], ending: Date) -> [String] {
        let end = Calendar.current.startOfDay(for: ending)
        let start = Calendar.current.date(byAdding: .day, value: -6, to: end)!
        let week = records.filter { $0.date >= start && $0.date <= end }
        let workouts = week.flatMap(\.workouts).filter{ $0.isStrength && $0.countsForSummary }
        let sets = workouts.flatMap(\.sets).filter(\.working)
        guard !sets.isEmpty else { return ["过去 7 天还没有力量工作组记录。先记录实际训练，再评估。"] }
        var output = ["过去 7 天：\(workouts.count) 次力量训练，\(sets.count) 个工作组。热身组不计入。"]
        var counts: [String: Int] = [:]
        for set in sets { if let muscle = ExerciseLibrary.find(set.exercise)?.muscle { counts[muscle, default: 0] += 1 } }
        if !counts.isEmpty { output.append("主要肌群组数：" + counts.keys.sorted().map { "\($0) \(counts[$0]!)" }.joined(separator: " · ") + "。复合动作只计主要肌群，辅助肌群也会参与。") }
        let missing = ["胸", "背", "腿前侧", "腿后侧"].filter { counts[$0] == nil }
        if !missing.isEmpty { output.append("目前未记录到：" + missing.joined(separator: "、") + "。可检查计划是否覆盖推、拉、蹲和髋铰链；不是每次都要练全身。") }
        let unknown = sets.filter { ExerciseLibrary.find($0.exercise) == nil }.count
        if unknown > 0 { output.append("\(unknown) 组自定义或旧版合并动作未归入肌群，已保留原始记录。") }
        let effort = sets.compactMap(\.rir)
        if effort.filter({ $0 <= 1 }).count > effort.count / 2 && !effort.isEmpty { output.append("已填写余力的组中，超过一半接近力竭。结合疲劳和动作稳定性安排恢复，不必每组都力竭。") }
        output.append("这些是训练记录提示，不是动作质量或增肌效果评分；时长不用于猜测力量训练热量。")
        return output
    }
    static func comparisons(workout: Workout, records: [DayRecord], date: Date) -> [String] {
        let cutoff = Calendar.current.date(byAdding: .day, value: -60, to: date)!
        let previous = records.filter { $0.date < Calendar.current.startOfDay(for: date) && $0.date >= cutoff }.sorted { $0.date > $1.date }
        var lines: [String] = []
        for name in Array(Set(workout.sets.filter(\.working).map(\.exercise))).sorted() {
            let current = workout.sets.filter { $0.exercise == name && $0.working }
            guard current.allSatisfy({ $0.seconds == nil }), let history = previous.first(where: { $0.workouts.flatMap(\.sets).contains { $0.exercise == name && $0.working } }) else { continue }
            let old = history.workouts.flatMap(\.sets).filter { $0.exercise == name && $0.working && $0.seconds == nil }
            let shared = current.filter { set in old.contains { $0.weight == set.weight && ($0.loadMode ?? "外部负重") == (set.loadMode ?? "外部负重") } }
            guard let selected = shared.max(by: { $0.weight < $1.weight }) else { continue }
            let now = current.filter { $0.weight == selected.weight && ($0.loadMode ?? "外部负重") == (selected.loadMode ?? "外部负重") }.map(\.reps).max()!
            let before = old.filter { $0.weight == selected.weight && ($0.loadMode ?? "外部负重") == (selected.loadMode ?? "外部负重") }.map(\.reps).max()!
            let label = now > before ? "增加" : now < before ? "减少" : "持平"
            let loadLabel = selected.loadMode == "自重" ? "自重（未校正体重变化）" : "同负重 \(selected.weight.formatted()) kg"
            lines.append("\(name)：\(loadLabel)，最佳单组 \(before) → \(now) 次（\(label)）。比较 \(history.date.formatted(date: .abbreviated, time: .omitted))；余力、器械和动作幅度不同会影响结果。")
        }
        return lines.isEmpty ? ["暂无同动作、同负重方式的历史对照。"] : lines
    }
}

enum TrainingPreferences {
    static func equipment(_ profile:PersonalProfile)->[String] {
        let text=(profile.fields["equipment"] ?? "").lowercased()
        // Free text remains authoritative after a user edits the previous checklist.
        if let explicit=profile.fields["equipmentChoices"],explicit.split(separator:"|").joined(separator:"、")==profile.fields["equipment"] {return explicit.split(separator:"|").map(String.init)}
        return ExerciseLibrary.equipment.filter { item in
            text.contains(item.lowercased()) || item == "自重" && (text.contains("徒手") || text.contains("bodyweight")) || item == "哑铃" && text.contains("dumbbell") || item == "杠铃" && text.contains("barbell") || item == "弹力带" && text.contains("band")
        }
    }
    static func available(_ data:AppData)->Set<String> {
        if let p=data.personalProfile,!((p.fields["equipment"] ?? "").isEmpty){return Set(equipment(p))}
        return Set(data.coachProfile?.equipment ?? [])
    }
    static func matches(_ exercise:ExerciseDefinition,data:AppData)->Bool {available(data).contains(exercise.equipment)}
}

enum TrainingSplit: String, CaseIterable, Identifiable {
    case automatic, fullBody, upperLower, pushPull, pushPullLegs, fourBodyParts, fiveBodyParts, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .automatic: return "不指定 · 让 AI 推荐"
        case .fullBody: return "全身训练 · 一分法"
        case .upperLower: return "上下肢 · 二分法"
        case .pushPull: return "推 / 拉 · 二分法（含腿）"
        case .pushPullLegs: return "推 / 拉 / 腿 · 三分法"
        case .fourBodyParts: return "胸 / 背 / 肩和核心 / 腿 · 四分法"
        case .fiveBodyParts: return "胸 / 背 / 肩 / 腿 / 手臂 · 五分法"
        case .custom: return "自定义分化"
        }
    }
    static func selected(_ profile: PersonalProfile?) -> TrainingSplit {
        TrainingSplit(rawValue: profile?.fields["trainingSplit"] ?? "") ?? .automatic
    }
    func groups(profile: PersonalProfile? = nil) -> [String] {
        switch self {
        case .automatic: return []
        case .fullBody: return ["全身"]
        case .upperLower: return ["上肢", "下肢和核心"]
        case .pushPull: return ["推（含蹲）", "拉（含髋铰链）"]
        case .pushPullLegs: return ["推", "拉", "腿和核心"]
        case .fourBodyParts: return ["胸", "背", "肩和核心", "腿"]
        case .fiveBodyParts: return ["胸", "背", "肩", "腿和核心", "手臂"]
        case .custom:
            let text = profile?.fields["customSplit"] ?? ""
            return text.components(separatedBy: CharacterSet(charactersIn: "、/／;；\n"))
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        }
    }
    var guidance: String {
        switch self {
        case .automatic: return "可留空。AI 根据经验、每周天数、时长、目标和恢复推荐。"
        case .fullBody: return "每次覆盖全身，可用不同动作侧重；不要求每次安排全部动作。"
        case .upperLower: return "分为上肢与下肢，不等于每周只练两天；可安排上 / 下重复循环。"
        case .pushPull: return "按动作模式分两课，蹲类进入推、髋铰链进入拉；腿部仍需完整覆盖。"
        case .pushPullLegs: return "推含胸肩三头，拉含背二头，腿课覆盖下肢；三课循环不等于必须一周三练或六练。"
        case .fourBodyParts: return "保留胸、背、肩和核心、腿四课；三头可配胸、二头可配背。AI 核对胸肩重叠负荷、各肌群频次和恢复。"
        case .fiveBodyParts: return "五课按部位分开。若训练天数不足，AI 会解释合并或跨周轮换的选择，不强行增加天数。"
        case .custom: return "用“、”或“/”分隔每课，例如：胸、背、肩和核心、腿。可在补充说明填写顺序与安排。"
        }
    }
}
extension ExerciseDefinition {
    // Navigation tags describe programming choices, not an exact measure of muscle stimulus.
    var relatedMuscles: [String] {
        var result = [muscle]
        if muscle == "胸" && pattern == "水平推" { result += ["肩", "三头"] }
        if muscle == "背" && (pattern.contains("拉") || pattern.contains("划")) { result += ["二头", "肩"] }
        if muscle == "肩" && pattern.contains("推") { result += ["三头"] }
        if ["腿前侧", "腿后侧"].contains(muscle) && pattern != "孤立" { result += ["臀", "核心"] }
        return Array(Set(result)).sorted()
    }
    var rearShoulder: Bool {muscle == "肩" && (name.contains("反向") || name == "面拉" || name == "弹力带拉开")}
    func splitGroups(_ split: TrainingSplit, profile: PersonalProfile? = nil) -> [String] {
        let lower = ["腿前侧", "腿后侧", "臀", "小腿"].contains(muscle)
        let upper = ["胸", "背", "肩", "二头", "三头", "前臂 / 斜方肌"].contains(muscle)
        switch split {
        case .automatic: return []
        case .fullBody: return ["全身"]
        case .upperLower: return upper ? ["上肢"] : lower || muscle == "核心" ? ["下肢和核心"] : ["上肢", "下肢和核心"]
        case .pushPull:
            if rearShoulder {return ["拉（含髋铰链）"]}
            if muscle == "肩" && name.contains("肩袖") {return split.groups()}
            if ["胸", "肩", "三头", "腿前侧", "小腿"].contains(muscle) { return ["推（含蹲）"] }
            if ["背", "二头", "前臂 / 斜方肌", "腿后侧", "臀"].contains(muscle) { return ["拉（含髋铰链）"] }
            return split.groups()
        case .pushPullLegs:
            if rearShoulder {return ["拉"]}
            if muscle == "肩" && name.contains("肩袖") {return ["推","拉"]}
            if lower || muscle == "核心" { return ["腿和核心"] }
            return ["胸", "肩", "三头"].contains(muscle) ? ["推"] : upper ? ["拉"] : split.groups()
        case .fourBodyParts:
            if lower { return ["腿"] }
            if ["胸", "三头"].contains(muscle) { return ["胸"] }
            if ["背", "二头", "前臂 / 斜方肌"].contains(muscle) { return ["背"] }
            if ["肩", "核心"].contains(muscle) { return ["肩和核心"] }
            return split.groups()
        case .fiveBodyParts:
            if lower || muscle == "核心" { return ["腿和核心"] }
            if ["二头", "三头", "前臂 / 斜方肌"].contains(muscle) { return ["手臂"] }
            return upper ? [muscle] : split.groups()
        case .custom:
            return split.groups(profile: profile).filter { group in
                group.contains(muscle) || group.contains("全身") || lower && (group.contains("腿") || group.contains("下肢")) || upper && group.contains("上肢") || ["二头", "三头", "前臂 / 斜方肌"].contains(muscle) && group.contains("手臂") || ["胸", "肩", "三头"].contains(muscle) && group.contains("推") || ["背", "二头"].contains(muscle) && group.contains("拉")
            }
        }
    }
}

struct ExerciseSetGroup: Identifiable {
    var id:String {name}
    var name:String
    var sets:[ExerciseSet]
    static func make(_ sets:[ExerciseSet])->[ExerciseSetGroup] {
        var result:[ExerciseSetGroup]=[]
        for set in sets {
            let name=set.exercise.trimmingCharacters(in:.whitespacesAndNewlines)
            if let index=result.firstIndex(where:{$0.name==name}){result[index].sets.append(set)}
            else{result.append(.init(name:name,sets:[set]))}
        }
        return result
    }
}
