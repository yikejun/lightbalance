import SwiftUI
import Security

enum VisionCredentials {
    private static let service = "com.personal.LightBalance.vision"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "gateway", kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ token: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "gateway"]
        let attributes: [String: Any] = [kSecValueData as String: Data(token.utf8), kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        var status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound { status = SecItemAdd(query.merging(attributes) { _, new in new } as CFDictionary, nil) }
        guard status == errSecSuccess else { throw VisionError.message("无法保存访问令牌，请检查设备钥匙串。") }
    }
}
enum SecureConfigDraft {
    static func query(_ account:String)->[String:Any] { [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.personal.LightBalance.configuration-drafts",kSecAttrAccount as String:account] }
    static func read(_ account:String)->[String:String]? { var q=query(account);q[kSecReturnData as String]=true;q[kSecMatchLimit as String]=kSecMatchLimitOne;var value:CFTypeRef?;guard SecItemCopyMatching(q as CFDictionary,&value)==errSecSuccess,let bytes=value as? Data else{return nil};return try? JSONDecoder().decode([String:String].self,from:bytes) }
    static func save(_ value:[String:String],account:String) throws { let q=query(account);let attrs:[String:Any]=[kSecValueData as String:try JSONEncoder().encode(value),kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly];var status=SecItemUpdate(q as CFDictionary,attrs as CFDictionary);if status==errSecItemNotFound{status=SecItemAdd(q.merging(attrs){_,new in new} as CFDictionary,nil)};guard status==errSecSuccess else{throw VisionError.message("配置草稿未保存到钥匙串。") } }
    static func clear(_ account:String){SecItemDelete(query(account) as CFDictionary)}
}
#if LIGHTBALANCE_USER_API
enum APIKeyStore {
    private static let service = "com.personal.LightBalance.user-api"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "openai", kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ key: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "openai"]
        let attributes: [String: Any] = [kSecValueData as String: Data(key.utf8), kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        var status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound { status = SecItemAdd(query.merging(attributes) { _, new in new } as CFDictionary, nil) }
        guard status == errSecSuccess else { throw VisionError.message("API Key 未能保存到钥匙串。") }
    }
    static func remove() throws {
        let status = SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "openai"] as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw VisionError.message("API Key 未能移除。") }
    }
}
enum VisionService {
    static let isAvailable = true
    static let unavailableReason = "请先配置模型供应商及自己的 API Key。"
    static var consentMessage:String { "所选资料由手机直接发送到你配置的模型服务（"+(URL(string:UserAPIRequest.base)?.host ?? "未配置")+"），使用你自己的 API Key 并按供应商计费。照片需要支持图片输入的模型；建议确认后才记账。" }
    static func analyze(photo: Data, note: String) async throws -> MealEstimate {
        let model = UserDefaults.standard.string(forKey: "userAPIModel") ?? "gpt-4.1-mini"
        return try JSONDecoder().decode(MealEstimate.self, from: await UserAPIClient.complete(payload: UserAPIRequest.meal(photo: photo, note: note, model: model))).validated()
    }
}
struct VisionSettingsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var key = ""
    @State private var saved = false
    @State private var model = "gpt-4.1-mini"
    @State private var base="https://api.openai.com/v1"
    @State private var apiProtocol="responses"
    @State private var outputMode="json_schema"
    var apiDraft:[String:String]{["key":key,"model":model,"base":base,"protocol":apiProtocol,"outputMode":outputMode]}
    @State private var initialized = false
    @State private var message: String?
    var body: some View {
        Form {
            Section("模型服务 · 使用自己的 API") {
                Text("API 独立计费，ChatGPT Plus 不包含 API 额度。")
                SecureField(saved ? "已保存；留空保留当前 Key" : "填写自己的 API Key", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                TextField("API Base URL，例如 https://服务地址/v1",text:$base).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Picker("接口协议",selection:$apiProtocol){Text("Responses").tag("responses");Text("Chat Completions · 兼容接口").tag("chat")}
                if apiProtocol=="chat"{Picker("结构化输出",selection:$outputMode){Text("JSON Schema · 严格结构").tag("json_schema");Text("JSON Object · 本机校验").tag("json_object")}}
                TextField("模型名称", text: $model).textInputAutocapitalization(.never).autocorrectionDisabled()
                Text("Key 只保存在此设备钥匙串，不随记录导出，也不上传开发者服务器。配置输入草稿也只存在钥匙串；点击保存后才启用。可配置非 OpenAI 的兼容接口；原生 Anthropic / Gemini 协议未直接支持。照片模型需支持图片；计划和周报需返回完整 JSON。供应商功能不同，不能保证所有模型都兼容。").font(.caption).foregroundStyle(.secondary)
                Link("创建 API Key", destination: URL(string: "https://platform.openai.com/api-keys")!)
                Link("查看 API 用量", destination: URL(string: "https://platform.openai.com/usage")!)
            }
            Section {
                Text(VisionService.consentMessage).font(.caption)
                Text("照片仍需你确认才上传，估算结果需确认才写入记录。此版本不会自动转用开发者账户或 Plus 服务。").font(.caption)
                Button("保存 API 配置") {
                    do {
                        let entered = key.trimmingCharacters(in: .whitespacesAndNewlines)
                        let destination=try UserAPIRequest.endpoint(base:base,apiProtocol:apiProtocol)
                        let previous=try UserAPIRequest.endpoint(base:UserAPIRequest.base,apiProtocol:UserAPIRequest.apiProtocol)
                        guard destination.host==previous.host || !entered.isEmpty else{throw VisionError.message("更换服务地址时，请输入此供应商的 Key，避免把旧 Key 发给另一家服务。")}
                        try UserAPIRequest.validate(key: entered.isEmpty ? APIKeyStore.read() : entered, model: model)
                        if !entered.isEmpty { try APIKeyStore.save(entered) }
                        UserDefaults.standard.set(base,forKey:"userAPIBaseURL");UserDefaults.standard.set(base,forKey:"userAPIKeyEndpoint");UserDefaults.standard.set(apiProtocol,forKey:"userAPIProtocol");UserDefaults.standard.set(outputMode,forKey:"userAPIOutputMode")
                        UserDefaults.standard.set(model, forKey: "userAPIModel"); SecureConfigDraft.clear("user-api");key = ""; saved = true; dismiss()
                    } catch { message = error.localizedDescription }
                }
                Button("移除此设备的 API Key", role: .destructive) {
                    do { try APIKeyStore.remove(); SecureConfigDraft.clear("user-api"); key = ""; saved = false; message = "已移除，后续调用需要重新配置。" } catch { message = error.localizedDescription }
                }.disabled(!saved)
                if let message { Text(message).font(.caption).foregroundStyle(.secondary) }
            }
        }.navigationTitle("我的 API").keyboardDone().onAppear {guard !initialized else{return};initialized=true;saved = !APIKeyStore.read().isEmpty; model = UserDefaults.standard.string(forKey: "userAPIModel") ?? "gpt-4.1-mini";base=UserAPIRequest.base;apiProtocol=UserAPIRequest.apiProtocol;outputMode=UserAPIRequest.outputMode;if let draft=SecureConfigDraft.read("user-api"){key=draft["key"] ?? "";model=draft["model"] ?? model;base=draft["base"] ?? base;apiProtocol=draft["protocol"] ?? apiProtocol;outputMode=draft["outputMode"] ?? outputMode} }
        .onChange(of:DraftStorage.encoded(apiDraft)){_,_ in guard initialized else{return};do{try SecureConfigDraft.save(apiDraft,account:"user-api")}catch{message=error.localizedDescription}}
    }
}
#else
enum VisionService {
    static let isAvailable = true
    static let unavailableReason = "请先配置识别服务。"
    static let consentMessage = "所选餐食照片和备注将发送到你配置的个人识别服务，再由 OpenAI 分析。其他记录不会发送。识别会消耗该服务关联账户的额度。"
    static func analyze(photo: Data, note: String) async throws -> MealEstimate {
        guard let url = URL(string: UserDefaults.standard.string(forKey: "visionEndpoint") ?? ""), url.scheme == "https", url.host != nil, url.user == nil, url.password == nil, url.query == nil, url.fragment == nil else { throw VisionError.message("请先在计划与设置中配置 HTTPS 识别服务。") }
        let token = VisionCredentials.read()
        guard !token.isEmpty else { throw VisionError.message("请先配置个人识别服务访问令牌。") }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 200
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["photo_base64": photo.base64EncodedString(), "note": note])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse else { throw VisionError.message("服务返回无效，请重试。") }
        guard response.statusCode == 200 else {
            let error = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw VisionError.message(error?["error"] as? String ?? "识别失败，请稍后重试。")
        }
        return try JSONDecoder().decode(MealEstimate.self, from: data).validated()
    }
}
struct VisionSettingsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var endpoint = ""
    @State private var initialized = false
    @State private var token = ""
    @State private var error: String?
    var body: some View {
        Form {
            Section("个人照片识别服务") {
                TextField("https://你的服务域名/analyze", text: $endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                SecureField("服务访问令牌", text: $token).textInputAutocapitalization(.never).autocorrectionDisabled()
                Text("个人版沿用你自己的服务授权。这里的令牌不是 ChatGPT 登录，也不要把它分享给朋友。输入草稿同样仅保存在此设备钥匙串，点击保存后才作为连接配置使用。").font(.caption).foregroundStyle(.secondary)
            }
            Section {
                Text(VisionService.consentMessage).font(.subheadline)
                Button("保存识别配置") {
                    let text = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard let url = URL(string: text), url.scheme == "https", url.host != nil, url.user == nil, url.password == nil, url.query == nil, url.fragment == nil, token.count >= 32 else { error = "请使用 HTTPS 地址和至少 32 字符的服务访问令牌。"; return }
                    do { try VisionCredentials.save(token); UserDefaults.standard.set(text, forKey: "visionEndpoint"); dismiss() } catch { self.error = error.localizedDescription }
                }
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
            }
        }.navigationTitle("个人识别配置").keyboardDone().onAppear {guard !initialized else{return};initialized=true;endpoint = UserDefaults.standard.string(forKey: "visionEndpoint") ?? "https://your-server.example/analyze"; token = VisionCredentials.read();if let draft=SecureConfigDraft.read("gateway"){endpoint=draft["endpoint"] ?? endpoint;token=draft["token"] ?? token} }
        .onChange(of:DraftStorage.encoded(["endpoint":endpoint,"token":token])){_,_ in guard initialized else{return};do{try SecureConfigDraft.save(["endpoint":endpoint,"token":token],account:"gateway")}catch{self.error=error.localizedDescription}}
    }
}

#endif
