import SwiftUI
import UIKit
import PhotosUI

struct FoodChatView: View {
    @EnvironmentObject var store: AppStore
    @State private var messages: [FoodChatMessage] = []
    @State private var draft = ""
    @ObservedObject private var ai=AIWorkCenter.shared
    var busy:Bool {ai.active(draftKey)}
    @State private var error: String?
    @State private var consent = false
    @State private var allowed = false
    @State private var initialized = false
    @State private var consumedJob:UUID?
    var draftKey: String { "chat-"+DraftStorage.dayKey(store.selectedDate) }
    var cached: ChatDraft { .init(messages:messages,text:draft) }
    func persist(){guard initialized else{return};do{try DraftStorage.save(cached,key:draftKey)}catch{self.error="对话草稿未保存："+error.localizedDescription}}
    func restore(){if let value=DraftStorage.load(ChatDraft.self,key:draftKey){messages=value.messages;draft=value.text}else{messages=[];draft=""};initialized=true}

    var body: some View {
        VStack(spacing:0) {
            VStack(alignment:.leading,spacing:5) {
                Text(store.selectedDate.formatted(date:.abbreviated,time:.omitted)).font(.headline)
                Text(store.target(store.day.mode).calories>0 ? "参考余额 \(number(store.target(store.day.mode).calories-store.day.total.calories)) kcal · 蛋白质还差 \(number(max(0,store.target(store.day.mode).protein-store.day.total.protein))) g" : "尚未建立个人营养目标，已记录摄入仍会保留")
                    .font(.caption).foregroundStyle(.secondary)
                NavigationLink("食堂菜单 / 现有食材"){FoodSupplyView()}
                Text("建议不自动记账").font(.caption).foregroundStyle(.secondary)
            }.frame(maxWidth:.infinity,alignment:.leading).padding().background(Color.canvas)
            ScrollViewReader { proxy in ScrollView {
                VStack(alignment:.leading,spacing:14) {
                    if messages.isEmpty { Text("告诉我你手头有什么食物、饮食偏好和过敏信息，我会根据记录后的余额建议份量。").foregroundStyle(.secondary).padding() }
                    ForEach(messages) { message in
                        Text(message.content).textSelection(.enabled).padding().frame(maxWidth:.infinity,alignment:message.role=="user" ? .trailing : .leading).background(message.role=="user" ? Color.forest.opacity(0.1) : Color.canvas,in:RoundedRectangle(cornerRadius:16)).id(message.id)
                    }
                    if busy { ProgressView("正在准备建议…") }
                    if let error { Text(error).foregroundStyle(.red).font(.caption) }
                }.padding()
            }.onChange(of:messages.count) { _,_ in if let id=messages.last?.id { proxy.scrollTo(id,anchor:.bottom) } } }
            HStack(alignment:.bottom) {
                TextField("例如：剩500千卡，有米饭和鸡蛋",text:$draft,axis:.vertical).lineLimit(1...5)
                Button("发送") { if allowed { send() } else { consent=true } }.disabled(busy || draft.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || draft.count>2000)
            }.padding().background(.white)
        }.keyboardDone().navigationTitle("吃什么 · AI 助手").navigationBarTitleDisplayMode(.inline)
            .toolbar { NavigationLink { VisionSettingsView() } label: { Image(systemName:"gearshape") } }
            .alert("发送饮食资料与对话？",isPresented:$consent) { Button("取消",role:.cancel){};Button("同意并发送"){allowed=true;send()} } message:{Text(FoodService.consent)}
            .onChange(of:ai.revision){_,_ in if let job=ai.latest(draftKey),job.delivered,consumedJob != job.id{restore();consumedJob=job.id};error=ai.latest(draftKey)?.state=="failed" ? ai.latest(draftKey)?.error : nil}
            .onAppear { ai.attach(store);guard !initialized else{return};restore() }
            .onChange(of:DraftStorage.encoded(cached)){_,_ in persist()}
            .onChange(of:store.selectedDate) { _,_ in initialized=false;restore();error=nil;allowed=false }
            .onDisappear { persist() }
    }
    func send() {
        let text=draft.trimmingCharacters(in:.whitespacesAndNewlines);guard !busy,!text.isEmpty,text.count<=2000 else{return}
        messages.append(.init(role:"user",content:text));draft="";error=nil;persist()
        let sent=messages;let context=FoodContext.make(data:store.data,day:store.day);ai.attach(store)
        ai.start(key:draftKey,title:"饮食聊天 · "+store.selectedDate.formatted(date:.abbreviated,time:.omitted),kind:"chat",date:store.selectedDate){let answer=try await FoodService.chat(messages:sent,context:context);return try JSONSerialization.data(withJSONObject:["answer":answer])}
    }

}
struct CameraPhotoPicker: UIViewControllerRepresentable {
    var completed: (UIImage)->Void
    @Environment(\.dismiss) var dismiss
    func makeUIViewController(context:Context)->UIImagePickerController {
        let picker=UIImagePickerController();picker.sourceType = .camera;picker.delegate=context.coordinator;return picker
    }
    func updateUIViewController(_ uiViewController:UIImagePickerController,context:Context) {}
    func makeCoordinator()->Coordinator { Coordinator(self) }
    final class Coordinator:NSObject,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        let parent:CameraPhotoPicker
        init(_ parent:CameraPhotoPicker){self.parent=parent}
        func imagePickerControllerDidCancel(_ picker:UIImagePickerController){parent.dismiss()}
        func imagePickerController(_ picker:UIImagePickerController,didFinishPickingMediaWithInfo info:[UIImagePickerController.InfoKey:Any]) {if let image=info[.originalImage] as? UIImage {parent.completed(image)};parent.dismiss()}
    }
}


struct FoodSupplyView:View {
    @EnvironmentObject var store:AppStore
    @Environment(\.dismiss) var dismiss
    @ObservedObject private var ai=AIWorkCenter.shared
    @State private var menu=""
    @State private var ingredients=""
    @State private var notes=""
    @State private var photos:[FoodPhoto]=[]
    @State private var selection:[PhotosPickerItem]=[]
    @State private var initialized=false
    @State private var saved=false
    @State private var consent=false
    @State private var error:String?
    let key="food-supply"
    var draft:FoodSupplyDraft{.init(menu:menu,ingredients:ingredients,notes:notes,photos:photos)}
    var busy:Bool{ai.active(key)}
    var batchJobs:[AIWork]{guard let latest=ai.latest(key) else{return []};return ai.jobs.filter{$0.key==key && $0.batchGroup==latest.batchGroup}}
    var results:[String]{batchJobs.compactMap{job in job.result.flatMap{try? JSONDecoder().decode(FoodChatAnswer.self,from:$0).answer}}}
    func persist(){guard initialized,!saved else{return};do{try DraftStorage.save(draft,key:key)}catch{self.error="菜单草稿未保存。"}}
    var body:some View {
        Form {
            Section("食堂菜单") {
                TextField("填写菜名、供应日期或餐次",text:$menu,axis:.vertical).lineLimit(3...12)
                PhotosPicker(selection:$selection,maxSelectionCount:nil,matching:.images){Label("上传菜单照片",systemImage:"menucard")}
                ForEach(photos){photo in HStack{if let image=UIImage(data:photo.data){Image(uiImage:image).resizable().scaledToFit().frame(width:64,height:64)};Text("菜单照片");Spacer();Button(role:.destructive){photos.removeAll{$0.id==photo.id}}label:{Image(systemName:"trash")}}}
                Button{consent=true}label:{if busy{ProgressView("正在读取菜单…")}else{Label("AI 读取照片中的菜单",systemImage:"sparkles")}}.disabled(photos.isEmpty || busy || notes.count>2000)
                Text("已选 \(photos.count) 张 · 自动分批处理，每批最多6张").font(.caption).foregroundStyle(.secondary)
                if !batchJobs.isEmpty{Text("已完成 \(batchJobs.filter{$0.state=="completed"}.count)/\(batchJobs.count) 批").font(.caption)}
                if batchJobs.contains(where:{$0.state=="failed" && $0.failureAcknowledged != true}),batchJobs.contains(where:{$0.pending}) {
                    Button("继续剩余批次"){ai.continueSupply(batchJobs.first?.batchGroup)}
                    Text("已完成结果保留，失败批次不会自动再次调用。").font(.caption).foregroundStyle(.secondary)
                }
                ForEach(batchJobs){job in DisclosureGroup(job.title+" · "+job.status){if let raw=job.result,let value=try? JSONDecoder().decode(FoodChatAnswer.self,from:raw){Text(value.answer).textSelection(.enabled)};if let message=job.error{Text(message).foregroundStyle(.red)}}}
                if !results.isEmpty{Button("合并已完成结果到菜单，再核对"){menu=results.joined(separator:"\n\n")}}

            }
            Section("现有食材") {TextField("例如：鸡蛋2个、熟米饭200g、牛奶250ml",text:$ingredients,axis:.vertical).lineLimit(3...10)}
            Section("备注与限制") {TextField("过敏、忌口、器械或烹饪条件",text:$notes,axis:.vertical);Text("保存后供余量推荐参考，请更新当天供应。菜单不是实际摄入。").font(.caption).foregroundStyle(.secondary)}
            if menu.count>60000{Text("菜单文字超过本次推荐容量，请按日期或食堂分开保存；批次识别结果仍保留。").foregroundStyle(.orange)}
            if let error{Text(error).foregroundStyle(.red)}
            if ai.latest(key)?.state=="failed",let message=ai.latest(key)?.error{Text(message).foregroundStyle(.red)}
            Button("保存菜单与食材"){
                store.saveFoodSupply(.init(menu:menu,ingredients:ingredients,notes:notes,updatedAt:Date()))
                if store.storageError==nil{saved=true;DraftStorage.remove(key);dismiss()}else{error=store.storageError}
            }.disabled(menu.count>60000 || ingredients.count>6000 || notes.count>2000)
        }.navigationTitle("菜单与现有食材").keyboardDone()
        .alert("发送菜单照片？",isPresented:$consent){Button("取消",role:.cancel){};Button("发送并识别"){
            persist();ai.attach(store)
            do{try ai.startSupply(images:photos,note:notes,date:store.selectedDate)}catch{self.error=error.localizedDescription}
        }}message:{Text(FoodService.destinationNotice+"仅发送所选菜单照片和备注，自动分批调用模型。图片越多，耗时和费用可能越高；每批结果保留，需核对保存。")}
        .onAppear{ai.attach(store);guard !initialized else{return};if let value=DraftStorage.load(FoodSupplyDraft.self,key:key){menu=value.menu;ingredients=value.ingredients;notes=value.notes;photos=value.photos}else if let value=store.data.foodSupply{menu=value.menu;ingredients=value.ingredients;notes=value.notes};initialized=true}
        .onChange(of:DraftStorage.encoded(draft)){_,_ in persist()}.onDisappear{persist()}
        .task(id:selection){for item in selection{do{if let data=try await item.loadTransferable(type:Data.self),let image=UIImage(data:data),let jpeg=FoodImageEncoder.jpeg(image){photos.append(.init(data:jpeg,role:"menu"))}}catch{self.error="菜单照片读取失败。"}};selection=[]}
    }
}
