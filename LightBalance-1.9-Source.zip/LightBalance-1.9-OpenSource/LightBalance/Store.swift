import SwiftUI

// The UUID must be issued by the backend after verified sign-in, never derived
// from an email or an unverified OAuth callback. Nil retains local guest data.
enum AccountStorage {
    static func recordsURL(root: URL, accountID: UUID?) -> URL {
        guard let accountID else { return root.appendingPathComponent("records.json") }
        return root.appendingPathComponent("accounts", isDirectory: true)
            .appendingPathComponent(accountID.uuidString.lowercased(), isDirectory: true)
            .appendingPathComponent("records.json")
    }
}

@MainActor final class AppStore: ObservableObject {
    @Published private(set) var data: AppData
    @Published var storageError: String?
    @Published var syncRevision = UUID()
    @Published var selectedDate = Calendar.current.startOfDay(for: Date())
    private let fileURL: URL
    init(storageURL: URL? = nil, accountID: UUID? = nil, storageRoot: URL? = nil) {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("LightBalance", isDirectory: true)
        fileURL = storageURL ?? AccountStorage.recordsURL(root: storageRoot ?? directory, accountID: accountID)
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: fileURL.path) {
                data = try JSONDecoder().decode(AppData.self, from: Data(contentsOf: fileURL))
            } else { data = AppData() }
        } catch {
            data = AppData()
            storageError = "无法读取记录：\(error.localizedDescription)。原文件已保留，请先导出或检查存储，避免覆盖。"
        }
        if storageError == nil { migratePlanHistory() }
        if storageError == nil, let cache=data.healthCache, data.healthWorkoutSync != false { importHealthWorkouts(cache.workouts) }
    }
    var day: DayRecord { record(for: selectedDate) }
    func defaultMode(for date:Date)->DayMode {
        let index=(Calendar.current.component(.weekday,from:date)+5)%7
        if let modes=data.activeWeekModes,modes.count==7,let mode=DayMode(rawValue:modes[index]) {return mode}
        return Plan.defaultMode(for:date)
    }
    func record(for date: Date) -> DayRecord {
        data.records.first { Calendar.current.isDate($0.date, inSameDayAs: date) } ?? DayRecord(date: Calendar.current.startOfDay(for: date), mode: defaultMode(for: date))
    }
    func update(_ action: (inout DayRecord) -> Void) {
        var next = data
        if let index = next.records.firstIndex(where: { Calendar.current.isDate($0.date, inSameDayAs: selectedDate) }) {
            action(&next.records[index])
        } else {
            var day = record(for: selectedDate)
            action(&day)
            next.records.append(day)
        }
        persist(next)
    }
    func settings(start: Date, waist: Double?, budget: Double, weight: Double? = nil, bodyFat: Double? = nil, mealsPerDay: Int? = nil) {
        var next = data
        next.startDate = Calendar.current.startOfDay(for: start)
        if let weight, weight.isFinite, weight > 0, weight <= 500 { next.initialWeight = weight }
        if let bodyFat, bodyFat.isFinite, bodyFat > 0, bodyFat <= 75 { next.initialBodyFat = bodyFat }
        if let mealsPerDay, (1...8).contains(mealsPerDay) { next.mealsPerDay = mealsPerDay }
        next.initialWaist = waist
        next.weeklyBudget = budget
        persist(next)
    }
    var needsOnboarding: Bool { data.onboardingCompleted != true && data.personalProfile == nil && data.records.isEmpty && data.coachProfile?.goal == nil }
    func targetText(_ mode: DayMode) -> String { data.nutritionTargets == nil ? mode.range : data.nutritionTargets?[mode.rawValue].map { numberForTarget($0) } ?? "尚未建立目标" }
    private func numberForTarget(_ n: Nutrition) -> String { String(Int(n.calories))+" kcal · 蛋白质 "+String(Int(n.protein))+" g" }
    func target(_ mode: DayMode) -> Nutrition { data.nutritionTargets?[mode.rawValue] ?? (data.nutritionTargets == nil ? mode.target : Nutrition()) }
    func savePersonalProfile(_ profile: PersonalProfile) {
        guard profile.complete else { return }
        var next = data; next.personalProfile = profile; next.onboardingCompleted = true
        if data.records.isEmpty && data.coachProfile?.goal == nil && data.personalProfile == nil { next.nutritionTargets = [:]; next.trainingPlans = []; next.weeklyBudget = 0; next.initialBodyFat = 0 }
        next.initialWeight = Double(profile.fields["weight"]!)!
        if let fat = Double(profile.fields["bodyFat"] ?? ""), fat > 0, fat <= 75 { next.initialBodyFat = fat }
        if let waist = Double(profile.fields["waist"] ?? ""), waist > 0, waist <= 300 { next.initialWaist = waist }
        next.mealsPerDay = Int(profile.fields["meals"] ?? "") ?? 2
        next.coachProfile = CoachProfile(goal: profile.fields["goal"], healthyAdult: profile.fields["restriction"] == "无" && profile.fields["pregnancy"] == "否" ? true : nil, medicalRestriction: profile.fields["restriction"] == "无" ? false : profile.fields["restriction"] == "有" ? true : nil, equipment: TrainingPreferences.equipment(profile), availableMinutes: Int(profile.fields["minutes"] ?? ""))
        persist(next)
    }
    func migratePlanHistory() {
        var next=data;var changed=false
        if next.personalPlanHistory == nil {
            next.personalPlanHistory=next.personalProposal.map{[PersonalPlanEntry(createdAt:$0.createdAt ?? Date(),proposal:$0)]} ?? [];changed=true
        }
        if next.planVersions == nil {next.planVersions=[];changed=true}
        if changed {persist(next)}
    }
    func savePersonalProposal(_ proposal: PersonalProposal) {
        var next=data;next.personalProposal=proposal
        next.personalPlanHistory=(next.personalPlanHistory ?? [])+[PersonalPlanEntry(createdAt:proposal.createdAt ?? Date(),proposal:proposal)]
        persist(next)
    }
    private func preserveCurrentVersion(_ next: inout AppData) {
        guard !(next.trainingPlans ?? []).isEmpty || next.nutritionTargets != nil else{return}
        if !(next.planVersions ?? []).contains(where:{$0.includesNutrition && $0.matches(next)}) {
            next.planVersions=(next.planVersions ?? [])+[PlanVersion.capture(next,title:"切换前的计划",origin:"saved")]
        }
    }
    private func applyPersonalValues(_ proposal:PersonalProposal,to next:inout AppData,entryID:UUID?) {
        next.trainingPlans=proposal.plans;next.nutritionTargets=proposal.targets;next.weeklyBudget=proposal.weeklyBudget
        next.personalSchedule=proposal.schedule;next.personalAcceptedHash=proposal.baseHash;next.activeDiet=proposal.diet;next.activeWeekModes=proposal.weekModes
        var version=PlanVersion.capture(next,title:"个人 AI 计划",origin:"personal");version.personalEntryID=entryID
        if let old=next.planVersions?.first(where:{$0.personalEntryID==entryID && entryID != nil && $0.matches(next)}) {next.activePlanVersionID=old.id}
        else {next.planVersions=(next.planVersions ?? [])+[version];next.activePlanVersionID=version.id}
    }
    func switchPersonalPlan(_ id:UUID) -> Bool {
        guard storageError == nil,let entry=data.personalPlanHistory?.first(where:{$0.id==id}),let profile=data.personalProfile,
              entry.proposal.status=="ready",(try? entry.proposal.validated(profile:profile)) != nil else{return false}
        var next=data;preserveCurrentVersion(&next);applyPersonalValues(entry.proposal,to:&next,entryID:id);persist(next);return storageError == nil
    }
    func switchPlanVersion(_ id:UUID) -> Bool {
        guard storageError == nil,let v=data.planVersions?.first(where:{$0.id==id}),let profile=data.personalProfile,
              profile.complete,profile.fields["restriction"]=="无",profile.fields["pregnancy"]=="否",
              !v.plans.isEmpty,v.plans.count<=14,Set(v.plans.map(\.id)).count==v.plans.count,v.plans.allSatisfy({!$0.name.isEmpty && !$0.exercises.isEmpty && $0.exercises.count<=20 && Set($0.exercises.map(\.id)).count==$0.exercises.count && $0.exercises.allSatisfy{!$0.name.isEmpty && (1...12).contains($0.sets) && (1...300).contains($0.reps)}}) else{return false}
        if v.includesNutrition, let entryID=v.personalEntryID {
            guard let entry=data.personalPlanHistory?.first(where:{$0.id==entryID}), (try? entry.proposal.validated(profile:profile)) != nil else{return false}
        }
        if let reportID=v.weeklyReportID {
            guard let report=data.weeklyAPIReports?.first(where:{$0.id==reportID}),validWeeklyHistory(report),DraftStorage.encoded(v.plans)==DraftStorage.encoded(report.payload?.proposedPlans ?? []) else{return false}
        }
        var next=data;preserveCurrentVersion(&next);next.trainingPlans=v.plans
        if v.includesNutrition {next.nutritionTargets=v.targets;next.weeklyBudget=v.weeklyBudget;next.personalSchedule=v.schedule;next.activeDiet=v.diet;next.activeWeekModes=v.weekModes}
        else {next.personalSchedule=nil}
        next.activePlanVersionID=v.id;persist(next);return storageError == nil
    }
    func applyPersonalProposal(_ proposal: PersonalProposal, currentHash: String) -> Bool {
        guard storageError == nil, proposal.status == "ready", proposal.baseHash == currentHash, currentHash == PersonalPlanFingerprint.hash(data), let profile = data.personalProfile, (try? proposal.validated(profile:profile)) != nil else { return false }
        var next=data;preserveCurrentVersion(&next);let entryID=next.personalPlanHistory?.last(where:{$0.proposal.baseHash==proposal.baseHash && $0.proposal.createdAt==proposal.createdAt})?.id;applyPersonalValues(proposal,to:&next,entryID:entryID);persist(next)
        return storageError == nil
    }
    func saveFoodSupply(_ supply: FoodSupply) { var next=data;next.foodSupply=supply;persist(next) }
    func savePlan(_ plan: TrainingPlan) {
        var next = data
        var plans = next.trainingPlans ?? []
        if let index = plans.firstIndex(where: { $0.id == plan.id }) { plans[index] = plan }
        else { plans.append(plan) }
        next.trainingPlans = plans
        persist(next)
    }
    func removePlan(_ id: UUID) {
        var next = data
        next.trainingPlans = (next.trainingPlans ?? []).filter { $0.id != id }
        persist(next)
    }
    func saveCoachProfile(_ profile: CoachProfile) {
        var next = data; next.coachProfile = profile; persist(next)
    }
    func saveProfessionalReview(reviewer: String, qualification: String, conclusion: String, note: String) {
        guard !reviewer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !qualification.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        var next = data
        next.professionalReviews = (next.professionalReviews ?? []) + [.init(date: Date(), reviewer: reviewer, qualification: qualification, conclusion: conclusion, note: note, plans: data.trainingPlans ?? [])]
        persist(next)
    }
    func acceptCoachChange(_ change: CoachChange, at date: Date) -> Bool {
        let current = CoachPolicy.evaluate(data: data, at: date)
        guard Calendar.current.isDateInToday(date), storageError == nil, current.changes.contains(change),
              let pi = data.trainingPlans?.firstIndex(where: { $0.id == change.planID }),
              let ei = data.trainingPlans?[pi].exercises.firstIndex(where: { $0.id == change.exerciseID }),
              data.trainingPlans?[pi].exercises[ei].reps == change.before else { return false }
        var next = data
        next.trainingPlans?[pi].exercises[ei].reps = change.after
        next.coachDecisions = (next.coachDecisions ?? []) + [.init(date: date, change: change, policyVersion: CoachPolicy.version, evidenceVersion: CoachEvidenceLibrary.version, sourceIDs: current.sourceIDs, facts: current.facts, sourceSnapshot: CoachEvidenceLibrary.sources.filter { current.sourceIDs.contains($0.id) })]
        persist(next)
        return storageError == nil
    }
    func saveWeeklyAPIReport(_ report: WeeklyReport) {
        cacheWeeklyReports([report])
    }
    func cacheWeeklyReports(_ reports:[WeeklyReport]) {
        var next=data;var saved=next.weeklyAPIReports ?? []
        for report in reports {if let i=saved.firstIndex(where:{$0.id==report.id}) {saved[i]=report}else{saved.append(report)}}
        next.weeklyAPIReports=saved.sorted{$0.snapshotAt > $1.snapshotAt};if DraftStorage.encoded(next.weeklyAPIReports) != DraftStorage.encoded(data.weeklyAPIReports){persist(next)}
    }
    func markWeeklyAPIReport(_ reportID: String, choice: String) {
        var next = data
        if let i = next.weeklyAPIReports?.firstIndex(where: { $0.id == reportID }) {
            next.weeklyAPIReports?[i].state = choice == "accept" ? "accepted" : "kept"; next.weeklyAPIReports?[i].decision = choice; persist(next)
        }
    }
    private func validWeeklyHistory(_ r:WeeklyReport) -> Bool {
        guard ["awaiting_choice","accepted","kept"].contains(r.state),let p=r.payload,p.recommendation=="adjust",
              let profile=data.personalProfile,profile.complete,profile.fields["restriction"]=="无",profile.fields["pregnancy"]=="否",
              !p.sourceIDs.isEmpty,Set(p.sourceIDs).isSubset(of:Set(CoachEvidenceLibrary.sources.map(\.id))),
              !p.proposedPlans.isEmpty,p.proposedPlans.count<=14,Set(p.proposedPlans.map(\.id)).count==p.proposedPlans.count,
              p.proposedPlans.allSatisfy({!$0.name.isEmpty && !$0.exercises.isEmpty && $0.exercises.count<=20 && Set($0.exercises.map(\.id)).count==$0.exercises.count && $0.exercises.allSatisfy{ExerciseLibrary.find($0.name) != nil && (1...12).contains($0.sets) && (1...300).contains($0.reps)}}) else{return false}
        return true
    }
    func switchWeeklyReport(_ id:String) -> Bool {
        guard storageError == nil,let r=data.weeklyAPIReports?.first(where:{$0.id==id}),validWeeklyHistory(r),let p=r.payload else{return false}
        var next=data;preserveCurrentVersion(&next);next.trainingPlans=p.proposedPlans;next.personalSchedule=nil
        if let old=next.planVersions?.first(where:{$0.weeklyReportID==id && $0.matches(next)}){next.activePlanVersionID=old.id}
        else {var v=PlanVersion.capture(next,title:"周报 "+r.week+" 的训练方案",origin:"weekly",includesNutrition:false);v.weeklyReportID=id;next.planVersions=(next.planVersions ?? [])+[v];next.activePlanVersionID=v.id}
        persist(next);return storageError == nil
    }
    func setWeeklyCoachEnabled(_ enabled: Bool) { var next = data; next.weeklyCoachEnabled = enabled; persist(next) }
    func applyWeeklyPlans(_ report: WeeklyReport) -> Bool {
        guard storageError == nil, WeeklySnapshot.applicable(report, to: data), let payload = report.payload else { return false }
        var next=data;preserveCurrentVersion(&next);next.trainingPlans=payload.proposedPlans;next.weeklyAcceptedReport=report.week;next.personalSchedule=nil
        var version=PlanVersion.capture(next,title:"周报 "+report.week+" 的训练方案",origin:"weekly",includesNutrition:false);version.weeklyReportID=report.id
        next.planVersions=(next.planVersions ?? [])+[version];next.activePlanVersionID=version.id;persist(next)
        return storageError == nil
    }
    func markHealthAuthorizationRequested() { var next = data; next.healthAccessRequested = true; persist(next) }
    func saveHealthCache(_ cache: HealthCache) { var next = data; next.healthCache = cache; persist(next); if data.healthWorkoutSync != false { importHealthWorkouts(cache.workouts) }; if data.healthAutoFill == true { for day in cache.days { importHealthDay(day) } } }
    func setHealthWorkoutSync(_ enabled: Bool) { var next=data;next.healthWorkoutSync=enabled;persist(next);if enabled,let cache=data.healthCache{importHealthWorkouts(cache.workouts)} }
    func importHealthWorkouts(_ workouts: [HealthWorkout]) {
        guard !workouts.isEmpty else{return}
        var next=data
        var accepted: [HealthWorkout] = []
        for h in workouts.sorted(by:{$0.start == $1.start ? $0.id.uuidString < $1.id.uuidString : $0.start < $1.start}) {
            guard h.minutes.isFinite,h.minutes>0,h.minutes<=1440,h.end>h.start else{continue}
            if HealthMath.possiblyDuplicate(h,in:accepted){continue};accepted.append(h)
            let date=Calendar.current.startOfDay(for:h.start)
            if !next.records.contains(where:{Calendar.current.isDate($0.date,inSameDayAs:date)}){next.records.append(DayRecord(date:date,mode:defaultMode(for:date)))}
            let di=next.records.firstIndex(where:{Calendar.current.isDate($0.date,inSameDayAs:date)})!
            if let wi=next.records[di].workouts.firstIndex(where:{$0.healthWorkoutID==h.id}) {
                if next.records[di].workouts[wi].healthCategoryEdited != true, next.records[di].workouts[wi].trainingType == "其他",h.category != "其他" {next.records[di].workouts[wi].trainingType=h.category}
                if next.records[di].workouts[wi].healthNameEdited != true, WorkoutSemantic.generic(next.records[di].workouts[wi].kind) || next.records[di].workouts[wi].kind == "间歇训练" {next.records[di].workouts[wi].kind=WorkoutSemantic.displayName(h.name)}
                next.records[di].workouts[wi].healthSource=h.source
                next.records[di].workouts[wi].startedAt=h.start;next.records[di].workouts[wi].endedAt=h.end
                // Retain user edits and actual sets; Health has no set-by-set load/RIR.
            } else {
                let candidate=next.records[di].workouts.first { $0.healthWorkoutID == nil && (($0.isStrength && h.category == "力量") || (!$0.isStrength && h.category == "有氧")) && abs(Double($0.minutes)-h.minutes) <= max(5,h.minutes*0.2) }
                next.records[di].workouts.append(Workout(id:h.id,kind:WorkoutSemantic.displayName(h.name),minutes:max(1,Int(h.minutes.rounded())),trainingType:h.category,healthWorkoutID:h.id,healthSource:h.source,startedAt:h.start,endedAt:h.end,healthDuplicateOf:candidate?.id))
            }
        }
        if DraftStorage.encoded(next) != DraftStorage.encoded(data){persist(next)}
    }
    func resolveHealthDuplicate(_ id: UUID, merge: Bool) {
        var next=data
        guard let di=next.records.firstIndex(where:{$0.workouts.contains(where:{$0.id==id})}),let wi=next.records[di].workouts.firstIndex(where:{$0.id==id}),let other=next.records[di].workouts[wi].healthDuplicateOf else{return}
        let imported=next.records[di].workouts[wi]
        if merge,let mi=next.records[di].workouts.firstIndex(where:{$0.id==other}) {
            next.records[di].workouts[mi].healthWorkoutID=imported.healthWorkoutID;next.records[di].workouts[mi].healthSource=imported.healthSource;next.records[di].workouts[mi].startedAt=imported.startedAt;next.records[di].workouts[mi].endedAt=imported.endedAt
            next.records[di].workouts.remove(at:wi)
        } else { next.records[di].workouts[wi].healthDuplicateOf=nil;next.records[di].workouts[wi].healthIndependent=true }
        persist(next)
    }
    func setHealthAutoFill(_ enabled: Bool) { var next = data; next.healthAutoFill = enabled; persist(next); if enabled, let cache = data.healthCache { for day in cache.days { importHealthDay(day) } } }
    func setHealthSleepSource(_ source: String?) { var next = data; next.healthSleepSource = source; persist(next) }
    func clearHealthCache() { var next = data; next.healthCache = nil; next.healthSleepSource = nil; next.healthAccessRequested = false; persist(next) }
    func importHealthDay(_ health: HealthDay) {
        var next = data
        var day = record(for: health.date)
        var imported = Set(day.healthImportedFields ?? [])
        func accepts(_ field: String, blank: Bool) -> Bool { blank || imported.contains(field) }
        if accepts("weight", blank: day.weight == nil), let v = health.values["weight"]?.value, v.isFinite, v > 0, v <= 500 { day.weight = v; imported.insert("weight") }
        if accepts("bodyFat", blank: day.bodyFat == nil), let v = health.values["bodyFat"]?.value, v.isFinite, v > 0, v <= 75 { day.bodyFat = v; imported.insert("bodyFat") }
        if accepts("waist", blank: day.waist == nil), let v = health.values["waist"]?.value, v.isFinite, v > 0, v <= 300 { day.waist = v; imported.insert("waist") }
        if accepts("steps", blank: day.steps == nil), let v = health.values["steps"]?.value, v.isFinite, v >= 0, v <= 200000 { day.steps = Int(v.rounded()); imported.insert("steps") }
        if accepts("sleep", blank: day.recovery?.sleepHours == nil), let v = health.values["sleep"]?.value, v.isFinite, v >= 0, v <= 24 {
            if day.recovery == nil { day.recovery = RecoveryRecord() }; day.recovery?.sleepHours = v; imported.insert("sleep")
        }
        day.healthImportedFields = imported.isEmpty ? nil : imported.sorted()
        if let i = next.records.firstIndex(where: { Calendar.current.isDate($0.date, inSameDayAs: health.date) }) { next.records[i] = day }
        else { next.records.append(day) }
        persist(next)
    }
    private func persist(_ next: AppData) {
        guard storageError == nil else { return }
        do {
            #if os(iOS)
            if next.healthCache != nil {
                var directory = fileURL.deletingLastPathComponent()
                var flags = URLResourceValues(); flags.isExcludedFromBackup = true
                try directory.setResourceValues(flags)
            }
            try JSONEncoder().encode(next).write(to: fileURL, options: [.atomic, .completeFileProtection])
            #else
            try JSONEncoder().encode(next).write(to: fileURL, options: .atomic)
            #endif
            data = next; syncRevision = UUID()
        } catch { storageError = "记录未能保存：\(error.localizedDescription)" }
    }
    func export() throws -> URL {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let exportDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("LightBalanceExport-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: exportDirectory, withIntermediateDirectories: true)
        let url = exportDirectory.appendingPathComponent("轻衡记录.json")
        try encoder.encode(data).write(to: url, options: .atomic)
        return url
    }
}
